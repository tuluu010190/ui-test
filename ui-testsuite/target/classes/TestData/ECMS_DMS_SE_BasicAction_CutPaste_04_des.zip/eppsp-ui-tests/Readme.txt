Selenium UI Tests for JBoss EPP-SP 5.x
--------------------------------------

Maven profiles:


* server-lifecycle 

    This profile uses maven-cargo-plugin to start and stop installed EPP-SP instance.

    Expected input properties: 
        container.home - path to the container installation (jboss-as folder)
        active.config - active jboss server config ("default")



* selenium 

    This profile uses maven-surefire-plugin to run Selenium UI tests against a started EPP-SP instance.

    General options:

        target.url - URL of running EPP-SP instance, default=http://localhost:8080

        portal.path - context path in the portal, default=/ecmdemo/public/classic

        method - list of test methods to be run, separated by collons; use wildcard
                 character "*" to identify methods (eg *CE*,*FB*,*Search*);
                 default=*

                    
    Selenium options:

        selenium.browser - browser to be used for Selenium testing (check out Selenium
                     docs for the list of supported browsers)
                     default=*firefox

        selenium.speed - delay in ms between Selenium commands, default=300

        selenium.timeout - timeout in ms for Selenium commands, default=30000

        selenium.host and selenium.port - host and port of the Selenium RC server;
                                    default=localhost:6666


     The maven-surefire-plugin generates test reports in target/surefire-reports directory.

* https

  Activates https mode for Firefox & EPP-SP.