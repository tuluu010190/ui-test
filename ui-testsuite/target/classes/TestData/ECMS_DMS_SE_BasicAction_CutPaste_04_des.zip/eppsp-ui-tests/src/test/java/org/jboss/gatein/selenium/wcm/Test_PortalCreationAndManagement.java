package org.jboss.gatein.selenium.wcm;

import java.util.Map;
import org.jboss.gatein.selenium.AbstractWCMTestCase;
import static org.jboss.gatein.selenium.WCMCommonHelper.*;
import static org.jboss.gatein.selenium.common.CommonHelper.*;
import static org.jboss.gatein.selenium.portal.PortalHelper.*;
import org.jboss.gatein.selenium.wcm.content.ContentExplorer.DocumentWorkspace;
import org.jboss.gatein.selenium.wcm.content.ContentExplorer.DrivesArea;
import org.jboss.gatein.selenium.wcm.content.ContentExplorer.Navigation;
import org.testng.annotations.Test;
import static org.testng.Assert.assertTrue;

/**
 *
 * @author tkyjovsk
 */
public class Test_PortalCreationAndManagement extends AbstractWCMTestCase{

    @Test(enabled = true)
    public void test_Portal_CreateDeleteAndVerifyDrives() throws Exception {
        goToACMEPortal();
//        openPortal(true);
        signInAsRoot();

        String siteName = "portal"+generateTimeStampSuffix();
        goToSite();
        createNewPortal(siteName, "English", "Default", "On Demand", 
            true, null, "Platform/Administrators", "*");
        pause(3000);
        
//        
//        PortalManagement.addPortal(siteName, "English", "Default",
//                "label=On Demand", true, null, "Platform/Administrators", "*");

        goToPage("//div[contains(., 'Content Manager')]", new String[]{ELEMENT_LINK_GROUP, ELEMENT_LINK_CONTENT_EXPLORER});
        DrivesArea.verifyDrivePresence(siteName+"-category", true); // (category drive)
//        Navigation.openDrive(DRIVE_SITES_MANAGEMENT);
        Navigation.showDrives();
        Navigation.browse(siteName);
        
        DocumentWorkspace.verifyItemPresent("categories");
        DocumentWorkspace.verifyItemPresent("css");
        DocumentWorkspace.verifyItemPresent("documents");
        DocumentWorkspace.verifyItemPresent("js");
        DocumentWorkspace.verifyItemPresent("links");
        DocumentWorkspace.verifyItemPresent("medias");
        DocumentWorkspace.verifyItemPresent("web contents");
        
        open(getPortalUrl()+"/private/"+siteName);
//        waitForAndGetElement("//a[contains(.,'Home')]");
        assertTrue(isElementPresent("//a[contains(.,'Home')]"));
        
        open(getPortalUrl()+"/private/acme"); // temporary workaround for JBEPP-
//        PortalManagement.deletePortal(siteName);     //
        deletePortal(siteName);
        
        goToPage("//div[contains(., 'Content Manager')]", new String[]{ELEMENT_LINK_GROUP, ELEMENT_LINK_CONTENT_EXPLORER});
        DrivesArea.verifyDrivePresence(siteName+"-category", false); // (category drive)
//        Navigation.openDrive(DRIVE_SITES_MANAGEMENT);
        Navigation.showDrives();
        DocumentWorkspace.verifyItemNotPresent(siteName);
        
    }
}
