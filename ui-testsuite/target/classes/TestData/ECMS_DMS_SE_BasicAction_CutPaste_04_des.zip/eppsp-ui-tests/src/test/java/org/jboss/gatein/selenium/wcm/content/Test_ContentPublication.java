package org.jboss.gatein.selenium.wcm.content;

import java.util.Date;
import org.jboss.gatein.selenium.AbstractWCMTestCase;
import static org.jboss.gatein.selenium.WCMCommonHelper.*;
import org.jboss.gatein.selenium.wcm.content.ContentExplorer.ContentManagement;
import static org.jboss.gatein.selenium.wcm.content.ContentExplorer.goToACMECategoryFolder;
import static org.jboss.gatein.selenium.wcm.content.Publication.*;
import static org.jboss.gatein.selenium.wcm.presentation.SCV.checkSCVPresentWithContent;
import org.testng.annotations.Test;
import static org.testng.Assert.assertTrue;

/**
 *
 * @author Tomas Kyjovsky <tkyjovsk at redhat dot com>
 */
public class Test_ContentPublication extends AbstractWCMTestCase {

    public static void test_PublicationLifecycle() {
    }

    // FIXME test_Pub_TestPublicWebContent
    @Test(groups = {"broken"}, enabled = false)
    public static void test_Pub_TestPublicWebContent() throws Exception {

        goToACMEPortal();

        signInAsRoot();

        String title = "SNF_WCM_15_" + new Date().getTime();

        addDocumentAndPublish(title);

        addSCVPortletWithContent(title, false, "News");

        switchPortalToPublishedMode();

        checkSCVPresentWithContent(title, title);

        goToPage("//div[contains(., 'Content Manager')]", new String[]{ELEMENT_LINK_GROUP,ELEMENT_LINK_CONTENT_EXPLORER});

        goToACMECategoryFolder();

        ContentManagement.deleteItem(title);

    }

    @Test(groups = {"broken"}, enabled = true)
    // FIXME test_Pub_TestUnpublishedWebContent
    public static void test_Pub_TestUnpublishedWebContent() throws Exception {

        goToACMEPortal();

        signInVerified("root", "gtn");

        String title = "SNF_WCM_16_" + new Date().getTime();

        addDocumentAndPublish(title);

        addSCVPortletWithContent(title, false, "News");

        switchPortalToPublishedMode();

        checkSCVPresentWithContent(title, title);

        saveAsDraftEditedDocument(title);

        goToACMEPortalPage("news");

        switchPortalToEditMode();

//        checkSCVPresentWithDraft(title + "-Edit", "Main content of " + title + "-Edit");
        assertTrue(isElementPresent("//p[contains(., 'Summary of "+title+"-Edit')]"));

        switchPortalToPublishedMode();

        checkSCVPresentWithContent(title, title);

        goToPage("//div[contains(., 'Content Manager')]", new String[]{ELEMENT_LINK_GROUP, ELEMENT_LINK_CONTENT_EXPLORER});

        goToACMECategoryFolder();

        ContentManagement.deleteItem(title);

    }
}
