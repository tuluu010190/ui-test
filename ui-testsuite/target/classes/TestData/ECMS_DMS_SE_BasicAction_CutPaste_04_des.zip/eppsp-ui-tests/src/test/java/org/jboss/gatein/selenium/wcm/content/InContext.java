package org.jboss.gatein.selenium.wcm.content;

import org.jboss.gatein.selenium.wcm.content.type.WebContent;
import org.jboss.gatein.selenium.wcm.content.type.Content;
import static org.jboss.gatein.selenium.wcm.content.Publication.*;
import static org.jboss.gatein.selenium.WCMCommonHelper.*;
import static org.jboss.gatein.selenium.common.CommonHelper.*;
import static org.jboss.gatein.selenium.testng.TestLogger.*;
import static org.jboss.gatein.selenium.wcm.content.ContentExplorer.*;

/**
 *
 * @author mgottval
 */
public class InContext {

    public static final String ADD_CONTENT_TEMPLATE = "//a[@class='AddContentIcon' and contains(@href, '${portletTitle}')]";
    public static final String MANAGE_CONTENT_TEMPLATE = "//a[@class='ManageContentIcon' and contains(@href, '${portletTitle}')]";
    public static final String EDIT_CONTENT_TEMPLATE = "//a[@class='EditContentIcon' and contains(@href, '${portletTitle}') and contains(@href, '${contentTitle}')]";
    public static final String PUBLISH_CONTENT = "//div[@id='UIPage']//div[contains(@id,'UICLVPortlet')]//p[contains(.,'${summary}')]/../../../../..//div[@class='EdittingContent']//a[@class='FastPublishIcon']";
    public static final String EDIT_CONTENT = "//div[@id='UIPage']//div[@id='UICLVPortlet']//p[contains(.,'${summary}')]/../../../../..//div[@class='EdittingContent']//a[@class='EditContentIcon']";
    public static final String BACK_TO_BUTTON = "//a[@class='URLBackToButton']";
    public static final String CONTENT_TO_MANAGE = "//div[@id='UIPage']//div[contains(@id,'UICLVPortlet')]//p[contains(.,'${summary}')]";
    
    public static final String PORTLET = "//div[@class='CLV']//div[@class='TitleBarM' and contains(.,'${portletTitle}')]";
    
    public static String getLocatorPortlet(String portletTitle) {
        return PORTLET.replace("${portletTitle}", portletTitle);
    }
    
    public static String getLocatorAddContent(String portletTitle) {
        return ADD_CONTENT_TEMPLATE.replace("${portletTitle}", portletTitle);
    }
    
    public static String getLocatorEditContent(String portletTitle, String contentTitle) {
        return EDIT_CONTENT_TEMPLATE.replace("${portletTitle}", portletTitle).replace("${contentTitle}", contentTitle);
    }
    
    public static String getLocatorManageContent(String portletTitle) {
        return MANAGE_CONTENT_TEMPLATE.replace("${portletTitle}", portletTitle);
    }
    
//    public static void addContentInContext(Content document, String location) throws Exception {
//        
//        switchPortalToEditMode();        
//        
//        waitForAndGetElement(getLocatorAddContent(location));
//        
//        addContentIntoContext(document, getLocatorAddContent(location));         
//    }
    
    public static void addContentInContextNews(Content document, String location) throws Exception {
        
        switchPortalToEditMode();        
        pause(3600);
//        mouseOverAndClick(getLocatorPortlet("Top News"), "//div[@id='ACMEParameterized']"+getLocatorAddContent(location));
        mouseOver(getLocatorPortlet("Top News"), true);
        click("//div[@id='ACMEParameterized']"+getLocatorAddContent(location));
        
        addContentIntoContext(document, getLocatorAddContent(location));         
        pause(3600);
    }
    
    public static void editContentInContext(String title) throws Exception {
        
        waitForAndGetElement("//div[contains(@title,'"+title+"')]");
        doubleClickOnElement("//div[contains(@title,'"+title+"')]");

        
        editContent(new WebContent(title+"-Edit", "Main content of "+title+"-Edit", "Summary of "+title+"-Edit", "CSS", "JS"));
        
        waitForAndGetElement(BACK_TO_BUTTON);
        
        click(BACK_TO_BUTTON);               
    }
    
    //Selenium
//    public static void manageContentInContext(String location) throws Exception {
//        
//        switchPortalToEditMode();        
//        
//        waitForAndGetElement(getLocatorManageContent(location));
//        
//        click(getLocatorManageContent(location));         
//    }

    public static void manageContentInContextNews(String location) throws Exception {
        
        switchPortalToEditMode();        
        
//        mouseOverAndClick(getLocatorPortlet("Top News"), "//div[@id='ACMEParameterized']"+getLocatorManageContent(location));
        mouseOver(getLocatorPortlet("Top News"), false);
        click("//div[@id='ACMEParameterized']"+getLocatorManageContent(location));
    }
    
    
      //Selenium
//    public static void inContextEditting(String location, String contentTitle, Content document) throws Exception {
//        
//        switchPortalToEditMode();        
//        
//        waitForAndGetElement(getLocatorEditContent(location, contentTitle));
//        
//        click(getLocatorEditContent(location, contentTitle));  
//        
//        DocumentWorkspace.fillUpdateForm(document);
//        
//        DocumentWorkspace.saveAndClose();
//        
//        waitForAndGetElement(BACK_TO_BUTTON);
//        
//        click(BACK_TO_BUTTON); 
//        
//        
//    }
    
    public static void inContextEdittingNews(String location, String contentTitle, Content document) throws Exception {
        
        switchPortalToEditMode();        
        
//       mouseOverAndClick(CONTENT_TO_MANAGE.replace("${summary}", contentTitle+" summary"), EDIT_CONTENT.replace("${summary}", contentTitle+" summary"));
        
        mouseOver(CONTENT_TO_MANAGE.replace("${summary}", contentTitle+" summary"), false);
        click(EDIT_CONTENT.replace("${summary}", contentTitle+" summary"));
        
        DocumentWorkspace.fillUpdateForm(document);
        
        DocumentWorkspace.saveAndClose();
        
        waitForAndGetElement(BACK_TO_BUTTON);
        
        click(BACK_TO_BUTTON); 
        
        
    }
    
    
    
    public static void inContextPublish(String summary) throws Exception {
        
//        mouseOverAndClick(CONTENT_TO_MANAGE.replace("${summary}", summary), PUBLISH_CONTENT.replace("${summary}", summary));
        mouseOver(CONTENT_TO_MANAGE.replace("${summary}", summary), false);
        click(PUBLISH_CONTENT.replace("${summary}", summary));
        
    }
    
    //Selenium
//     public static void inContextPublish(String summary) throws Exception {
//        
//        waitForAndGetElement(PUBLISH_CONTENT.replace("${summary}", summary));
//        click(PUBLISH_CONTENT.replace("${summary}", summary));
//    }
       
//    public static void inContentEditting(String content) throws Exception {
//        waitForElementPresentAndDblClick("//div[@id='UIPage']//div[@id='UICLVPortlet']//div[contains(.,'" + content + "')]");
//        waitForElementPresentAndClick("//textarea[contains(@id, newText) and .='"+content+"']");
//        waitForElementPresentAndType("//textarea[contains(@id, newText) and .='"+content+"']", "Lorem ipsum");
//        waitForAndGetElement("//a[@class='AcceptButton']");
//        click("//a[@class='AcceptButton']");
//    }
    
    public static void deleteRemainigFilesInNews(String name) throws Exception {
        
        while (isElementPresent("//a[contains(@title, '"+name+"')]")) {
            ContentManagement.deleteItem(name);
        }
    }
    
}
