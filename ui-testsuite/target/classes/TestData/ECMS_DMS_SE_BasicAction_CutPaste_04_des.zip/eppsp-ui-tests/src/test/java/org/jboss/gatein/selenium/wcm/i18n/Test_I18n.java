package org.jboss.gatein.selenium.wcm.i18n;

import org.jboss.gatein.selenium.AbstractWCMTestCase;
import static org.jboss.gatein.selenium.WCMCommonHelper.*;
import static org.jboss.gatein.selenium.common.CommonHelper.*;
import org.jboss.gatein.selenium.wcm.content.ContentExplorer.ActionBar;
import org.jboss.gatein.selenium.wcm.content.ContentExplorer.ContentManagement;
import org.jboss.gatein.selenium.wcm.content.ContentExplorer.TreeExplorerWorkspace;
import static org.jboss.gatein.selenium.wcm.content.ContentExplorer.goToACMECategoryFolder;
import static org.jboss.gatein.selenium.wcm.content.ContentSelector.browseTree;
import static org.jboss.gatein.selenium.wcm.content.ContentSelector.selectItem;
import static org.jboss.gatein.selenium.wcm.i18n.translationManagement.addTranslatedContent;
import static org.jboss.gatein.selenium.wcm.wcmadministration.EditView.addTranslationIntoWcmView;
import static org.testng.Assert.assertTrue;
import org.testng.annotations.Test;
/**
 *
 * @author Tomas Kyjovsky <tkyjovsk at redhat dot com>
 */
public class Test_I18n extends AbstractWCMTestCase {
    
    public static final String PATH_NODE_ADD_ITEM = POPUP_LOCATOR_TEMPLATE.replace("{popupTitle}","Symlink Manager")+"//img[@title='Add Item']";
    public static final String SAVE_BUTTON = POPUP_LOCATOR_TEMPLATE.replace("{popupTitle}","Symlink Manager")+"//a[.='Save']";
    public static final String RELATION = "//div[contains(@class,'UISelectContent')]//div[contains(@class,'ItemIcon DefaultIcon RelationIcon')]/..";
    public static final String FILE_EXPLORER = "//div[contains(@class,'UISelectContent')]//div[contains(@class,'ItemIcon DefaultIcon ExplorerIcon')]/..";
    
    @Test(enabled=true)
    public void test_I18n () throws Exception {
        
        String title = "WCM_CS"+generateTimeStampSuffix()+" en";
        
        goToACMEPortal();
        
        signInAsRoot();

        goToPage("//div[contains(., 'Manage ECM Main Functions')]", new String[]{ELEMENT_LINK_GROUP, ELEMENT_LINK_CONTENT_ADMINISTRATION});
        
        addTranslationIntoWcmView("WCM View");
        
        goToPage("//div[contains(., 'Content Manager')]", new String[]{ELEMENT_LINK_GROUP, ELEMENT_LINK_CONTENT_EXPLORER});
        goToACMECategoryFolder();
        TreeExplorerWorkspace.clickItem("ACME News 1");
        
        ActionBar.addTranslation(); // ?? in contentExplorer
        waitForElementPresentAndClick(PATH_NODE_ADD_ITEM);
        waitForElementPresentAndClick("//div[@id='BreadcumbsContainer']//a[.='General Drives']");
        browseTree("General Drives","acme-category");
        selectItem("ACME News 2");
        pause(6000);
        
              
//        goToAdministration();
//        
//        addTranslationIntoWcmView("WCM View");
        
        goToPage("//div[contains(., 'Content Manager')]", new String[]{ELEMENT_LINK_GROUP, ELEMENT_LINK_CONTENT_EXPLORER});

        addTranslatedContent(title);
        
//        goToACMECategoryFolder();
        
        TreeExplorerWorkspace.clickItem(title);

        waitForElementPresentAndClick(RELATION);

        pause(2600);
        
        assertTrue(isElementPresent("//div[@class='SideBarContent']//div[contains(@class, 'UIViewRelationList')]//div[contains(.,'"+title+" cs')]"));
        
        waitForElementPresentAndClick(FILE_EXPLORER);
        
        ContentManagement.deleteItem(title);
        
        ContentManagement.deleteItem(title+" cs");
        
        goToPage("//div[contains(., 'Manage ECM Main Functions')]", new String[]{ELEMENT_LINK_GROUP, ELEMENT_LINK_CONTENT_ADMINISTRATION});
        
        addTranslationIntoWcmView("WCM View");
    }
    
}
