package org.jboss.gatein.selenium.wcm.content;

//import org.jboss.gatein.selenium.PortalTest;
import org.jboss.gatein.selenium.AbstractWCMTestCase;
import static org.jboss.gatein.selenium.testng.TestLogger.info;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import static org.jboss.gatein.selenium.WCMCommonHelper.*;
import static org.jboss.gatein.selenium.common.CommonHelper.*;
import static org.jboss.gatein.selenium.testng.TestLogger.*;
/**
 * @author Tomas Kyjovsky <tkyjovsk at redhat dot com>
 */
public class Test_ContentSearch extends AbstractWCMTestCase {

    public static final String SEARCH_BOX = "//div[@id='siteSearchBox']//input[@name='keyword']";
    public static final String SEARCH_RESULT = "//div[@id='UISearchResult']";
    public static final String SEARCH_ITEM = SEARCH_RESULT + "//div[@class='SearchItem']";
    public static final String SEARCH_ITEM_TEMPLATE = SEARCH_ITEM + "//a[.='${itemTitle}']";

    @DataProvider
    public static Object[][] provideSearch() {
        return new Object[][]{
//                    {"classic", "Leverage", new String[]{ // in title
//                        "Leverage your portal investment", }},
//                    {"classic", "Switch", new String[]{ // in content
//                        "Leverage your portal investment", }},
//                    {"classic", "Site Publisher", new String[]{ // in illustration description
//                        "Easy, intuitive site authoring", 
//                        "Evolve at your own pace", 
//                        "Manage multiple websites, all in one place", 
//                    }},
                    {"classic", "--NONSENSE-KEYWORD--", new String[]{}},
                    {"acme", "News", new String[]{
                        "ACME News 1", 
                        "ACME News 2", 
                        "ACME News 3",
                        "ACME News 4"}},
                    {"acme", "Event", new String[]{
                        "ACME Event 1", 
                        "ACME Event 2", 
                        "ACME Event 3",
                        "ACME Event 4"}},
                    {"acme", "News 1",
                        new String[]{"ACME News 1"}},
                    {"acme", "Event 3",
                        new String[]{"ACME Event 3"}},
                    {"acme", "News 5",
                        new String[]{}},
                    {"acme", "Event 5",
                        new String[]{}},
                    {"acme", "--NONSENSE-KEYWORD--",
                        new String[]{}},
        };
        
    }

    @Test(enabled = true, dataProvider = "provideSearch")
    public static void test_QuickSearch(String site, String keyword, String[] resultItems) throws Exception {
        goToPortal("ecmdemo", site, false);
        quickSearchKeyword(keyword);
        checkResultsForKeyword(resultItems);
    }

    public static void quickSearchKeyword(String keyword) throws Exception {

        info("quick search: \""+keyword+"\"");
        waitForElementPresentAndType(SEARCH_BOX, keyword);
        keyPressNativeOnElement(SEARCH_BOX, "RETURN");
        
    }
    
    /**
     * 
     * @param keyword
     * @param resultItems The list of required result items for this keyword.
     */
    public static void checkResultsForKeyword(String[] resultItems) throws Exception {

        if (resultItems == null || resultItems.length == 0) {

            info("verify result is empty");
            waitForAndGetElement(SEARCH_RESULT);
            waitForElementNotPresent(SEARCH_ITEM); // there should be no result items

        } else {
            for (String item : resultItems) {
                info("verify result present: "+item+"");
                waitForAndGetElement(SEARCH_ITEM_TEMPLATE.replace("${itemTitle}", item));
            }
        }
    }

}

