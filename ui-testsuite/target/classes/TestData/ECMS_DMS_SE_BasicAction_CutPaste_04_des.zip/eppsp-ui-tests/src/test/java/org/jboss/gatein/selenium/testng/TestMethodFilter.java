package org.jboss.gatein.selenium.testng;

import org.apache.commons.lang.StringUtils;

import org.testng.IAnnotationTransformer;
import org.testng.annotations.ITestAnnotation;

import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import org.apache.log4j.Logger;

/**
 *
 * @author Tomas Kyjovsky <tkyjovsk at redhat dot com>
 */
public class TestMethodFilter implements IAnnotationTransformer {
    private String filter = null;
    
    private static Logger log = Logger.getLogger(TestMethodFilter.class);

    public TestMethodFilter() {
        filter = System.getProperty("method", "*");    // backwards compat.

        if (System.getProperties().containsKey("filter")) {
            filter = System.getProperty("filter", "*");
        }

        log.info("TestMethodFilter: " + filter);
    }

    /**
     * Enables only those methods that match the string(s) provided in the "method" property.
     *
     * Each matched method name includes the canonical name of its declaring class as a prefix
     * so it is also possible to select methods by package or class name substrings.
     *
     * Examples:
     *
     *  -Dmethod=*nameSubstring
     *  -Dmethod=*nameSubstring1*,*nameSubstring2*,...
     *
     */
    @SuppressWarnings("unchecked")
    @Override
    public void transform(ITestAnnotation annotation, Class testClass, Constructor testConstructor, Method testMethod) {
        String[] selectedMethods = filter.split(",");

        if (testMethod != null) {
            String  methodName = testMethod.getDeclaringClass().getCanonicalName() + "." + testMethod.getName();
            boolean match      = false;

            for (String selectedMethod : selectedMethods) {
                selectedMethod = StringUtils.replace(selectedMethod, "*", ".*");

                if (methodName.matches(selectedMethod)) {
                    match = true;

                    break;
                }
            }

            annotation.setEnabled(annotation.getEnabled() && match || annotation.getAlwaysRun());

            if (annotation.getEnabled()) {
                log.info("ENABLED : " + methodName);
            }
        }
    }
}
