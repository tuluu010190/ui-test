package org.jboss.gatein.selenium.wcm.content;

import java.util.Date;
import org.jboss.gatein.selenium.AbstractWCMTestCase;
import static org.jboss.gatein.selenium.WCMCommonHelper.*;
import static org.jboss.gatein.selenium.common.CommonHelper.*;
import static org.jboss.gatein.selenium.testng.TestLogger.info;
import static org.jboss.gatein.selenium.wcm.content.ContentExplorer.*;
import org.jboss.gatein.selenium.wcm.content.type.*;
import static org.testng.Assert.assertFalse;
import static org.testng.Assert.assertTrue;
import org.testng.annotations.Test;

/**
 *
 * @author tkyjovsk
 */
public class Test_ContentManagement extends AbstractWCMTestCase {

    private static final String MOVED_CONTENT = "//div[contains(@onmousedown, 'target_copy')]/../..//a[contains(@title, '${title}')]";
    private static final String RENAMED_CONTENT = "//div[contains(@onmousedown, 'target_move')]/../..//a[contains(@title, '${title}')]";
    
    public void test_CopyMoveRename_Item(Content document) throws Exception {
        
        String title = "SNF_WCM_16_"+new Date().getTime();
               
        goToACMEPortal();
        signInVerified("root", "gtn");
        goToPage("//div[contains(., 'Content Manager')]", new String[]{ELEMENT_LINK_GROUP, ELEMENT_LINK_CONTENT_EXPLORER});
        goToTestFolder(title);

        addFolderIfMissing("target_copy", false);
        addFolderIfMissing("target_move", false);
        addFolderIfMissing("source", true);

        // create document
        addItem(document);

        Navigation.browseUp();
        DocumentWorkspace.verifyItemPresent(document.getTitle());

        // copy & paste
        info("copy & paste");
        ContentManagement.copyItem(document.getTitle());
        ContentManagement.paste("target_copy");

        // check if copied
        info("check if copied");
        DocumentWorkspace.verifyItemPresent(document.getTitle());
        Navigation.browseUp();
        Navigation.browse("target_copy");
        Navigation.browse(document.getTitle());
        DocumentWorkspace.verifyDisplayedContent(document);

        // cut & paste (move)
        info("cut & paste");
        Navigation.browseUp();
        ContentManagement.cutItem(document.getTitle());
        ContentManagement.paste("target_move");

        // check if moved
        info("check if moved");
//        DocumentWorkspace.verifyItemNotPresent(document.getTitle());
        assertFalse(isElementPresent(MOVED_CONTENT.replace("${title}", document.getTitle())));
        Navigation.browseUp();
        Navigation.browse("target_move");
        Navigation.browse(document.getTitle());
        DocumentWorkspace.verifyDisplayedContent(document);
        Navigation.browseUp();

        // rename
        info("rename");
        String newName = "_renamed";
        ContentManagement.renameItem(document.getTitle(), document.getTitle()+newName, document.getTitle()+newName);
        
        // check if renamed
//        DocumentWorkspace.verifyItemNotPresent(document.getTitle());
//        DocumentWorkspace.verifyItemPresent(document.getTitle() + newName);
//        assertTrue(isElementNotPresent(RENAMED_CONTENT.replace("${title}", document.getTitle())));
        assertTrue(isElementPresent(RENAMED_CONTENT.replace("${title}", document.getTitle()+ newName)));
        
        goToPage("//div[contains(., 'Content Manager')]", new String[]{ELEMENT_LINK_GROUP, ELEMENT_LINK_CONTENT_EXPLORER});
        
        ContentManagement.deleteItem(title);
        signOut();
    }

    @Test
    public void test_CopyMoveRename_Folder() throws Exception {
        test_CopyMoveRename_Item(Folder.generateUnique());
    }

    @Test
    public void test_CopyMoveRename_Article() throws Exception {
        test_CopyMoveRename_Item(Article.generateUnique());
    }

    @Test
    public void test_CopyMoveRename_File() throws Exception {
        test_CopyMoveRename_Item(File.generateUnique());
    }

    @Test
    public void test_CopyMoveRename_WebContent() throws Exception {
        test_CopyMoveRename_Item(WebContent.generateUnique());
    }
}
