package org.jboss.gatein.selenium.wcm.content;

import static org.jboss.gatein.selenium.WCMCommonHelper.*;
import static org.jboss.gatein.selenium.common.CommonHelper.*;
import static org.jboss.gatein.selenium.testng.TestLogger.*;
import org.jboss.gatein.selenium.wcm.content.type.Content;
import org.jboss.gatein.selenium.wcm.content.type.Folder;
import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

/**
 * 
 * Convenience class for performing operations in ContentExplorer portlet.
 *
 * @author Tomas Kyjovsky <tkyjovsk at redhat dot com>
 */
public class ContentExplorer {

    public static final String LOCATOR = "//div[@id='UIJCRExplorer']";
    public static final String CONTROL = "//div[@id='UIWorkingArea']";
    public static final String DRIVE_SITES_MANAGEMENT = "Sites Management";
    public static final String DRIVE_COLLABORATION = "collaboration";
    public static final String ECM_CONTEXT_MENU = "//div[@id='ECMContextMenu']";
    public static final String BACK_TO_BUTTON = "//a[@class='URLBackToButton']";
    public static final String DOCUMENT_EDITING = "//div[@id='UIActionBar']//a[.='Edit']";

    public static class ActionBar {

        public static String LOCATOR = ContentExplorer.CONTROL + "//div[@id='UIActionBar']";

        public static class Tabs {

            public static final String PUBLICATION = "Publication";
            public static final String COLLABORATION = "Collaboration";
            public static final String SYSTEM = "System";
        }

        public static class Actions {

            public static final String ADD_FOLDER = "New Folder";
            public static final String ADD_CATEGORY = "Add Category";
            public static final String ADD_CONTENT = "New Content";
            public static final String EDIT_DOCUMENT = "Edit";
            public static final String ADD_TRANSLATION = "Add Translation";
            public static final String ADD_PERMISSIONS = "Permissions";
        }

        public static void invokeAction(String actionTitle) throws Exception {

            debug("Action from action bar: " + actionTitle + "");
          //  waitForElementPresentAndClick(LOCATOR + "//a[.='" + actionTitle + "']");
            waitForElementPresentAndClick(LOCATOR + "//a[.='" + actionTitle + "']");
        }
        
        //Selenium
//        public static void invokeAction(String tabTitle, String actionTitle) throws Exception {
//
//            debug("Action from action bar: " + tabTitle + " - " + actionTitle + "");
//            waitForElementPresentAndClick(LOCATOR + "//div[@class='UITab']//a[.='" + tabTitle + "']");
//            pause(2000);
//            waitForElementPresentAndClick(LOCATOR + "//a[.='" + actionTitle + "']");
//
//        }

        public static void invokeAction(String tabTitle, String actionTitle) throws Exception {
            
            debug("Action from action bar: " + tabTitle + " - " + actionTitle + "");
            waitForElementPresentAndClick(LOCATOR + "//div[@class='UITab']//a[.='" + tabTitle + "']");
            pause(2000);
            if (isVisible(LOCATOR + "//div[@id='IconListHideElement']")) {
                waitForElementPresentAndClick(LOCATOR + "//div[@id='IconListHideElement']");
            }
            pause(1000);
            if (isElementPresent(LOCATOR + "//div[@id='ListHideContainer']//a[.='" + actionTitle + "']")) {
          //   if   (isVisible(LOCATOR + "//div[@id='ListHideContainer']")){
                waitForElementVisible(LOCATOR + "//div[@id='ListHideContainer']//a[.='" + actionTitle + "']");
                click(LOCATOR + "//div[@id='ListHideContainer']//a[.='" + actionTitle + "']");
            } else {
                waitForElementPresentAndClick(LOCATOR + "//a[.='" + actionTitle + "']");
            }
            
        }

        public static void addFolder() throws Exception {
            invokeAction(Tabs.PUBLICATION, Actions.ADD_FOLDER);
        }

        public static void addCategory() throws Exception {
            invokeAction(Actions.ADD_CATEGORY);
        }

        public static void addContent() throws Exception {
            invokeAction(Tabs.PUBLICATION, Actions.ADD_CONTENT);
        }

        public static void editContent() throws Exception {
            invokeAction(Tabs.PUBLICATION, Actions.EDIT_DOCUMENT);
        }

        public static void addTranslation() throws Exception {
            invokeAction(Tabs.PUBLICATION, Actions.ADD_TRANSLATION);
        }
        
        public static void addPermissions() throws Exception {
            invokeAction(Tabs.SYSTEM, Actions.ADD_PERMISSIONS);
        }
    }

    public static class SideBar {

        public static final String LOCATOR = ContentExplorer.LOCATOR + "//div[@id='UIWorkingArea']";
        public static final String DIV_SELECT_CONTENT = LOCATOR + "//div[@class='UISelectContent']";
        public static final String DIV_TITLE = LOCATOR + "//div[@class='Title' and contains(@onclick,'op=Expand')]";
        public static final String LINK_SHOW_DRIVES_AREA = LOCATOR + "//a[@title='Show Drives']";

        public static void selectContent(String itemTitle) throws Exception {
            waitForElementPresentAndClick(DIV_SELECT_CONTENT + "//div[@title='" + itemTitle + "']");
        }

        public static void showDrivesArea() throws Exception {

            //selectContent("File explorer");
//            waitForElementPresentAndClick(LINK_SHOW_DRIVES_AREA);
            waitForAndGetElement(LINK_SHOW_DRIVES_AREA);
            click(LINK_SHOW_DRIVES_AREA);
            waitForAndGetElement(DrivesArea.LOCATOR);
            waitForOperationToFinish();

        }

        public static void browseToRoot() throws Exception {
            waitForElementPresentAndClick(DIV_TITLE);
            waitForOperationToFinish();
        }

        public static class FileExplorer {

            public static String LOCATOR = SideBar.LOCATOR + "//div[@id='UITreeExplorer']";

            public static String getItemLocator(String itemTitle) {
                return LOCATOR + "//div[contains(@class,'Node')]//a[contains(.,'" + itemTitle + "')]";
            }

            public static String getSelectedItemLocator() {
                return LOCATOR + "//div[contains(@class,'SelectedNode')]";
            }

            public static String getParentItemLocator(String itemLocator) throws Exception {
                String loc = itemLocator + "/../../../div[1]/div[1]";
                if (isElementNotPresent(loc)) {
                    loc = DIV_TITLE;
                }
                return loc;
            }

            public static void clickItem(String itemTitle) throws Exception {
                debug("Click item in file explorer: " + itemTitle + "");
                waitForElementPresentAndClick(getItemLocator(itemTitle));
            }

            public static void browse(String... path) throws Exception {
                for (String pathItem : path) {
                    clickItem(pathItem);
                    waitForOperationToFinish();
                }
            }

            public static void browseUp() throws Exception {
                String loc = getParentItemLocator(getSelectedItemLocator());
                debug("browsing 1 level up");
                trace(loc);
                waitForElementPresentAndClick(loc);
                waitForOperationToFinish();
            }

            public static void contextActionForItem(String itemTitle, String actionTitle) throws Exception {

                String itemLocator = getItemLocator(itemTitle);

                waitForElementPresentAndClick(itemLocator);
                pause(3600);
                contextMenuOnElement(itemLocator);
                pause(4600);
                String actionLocator = ECM_CONTEXT_MENU + "//a[contains(.,'" + actionTitle + "')]";
                pause(4600);
                waitForElementPresentAndClick(actionLocator);
                pause(3600);
            }
        }
    }

    public static class TreeExplorerWorkspace {

        public static final String LOCATOR = "//div[@id='UITreeExplorer']";
        public static final String LOCATOR_ITEM_TPL = LOCATOR + "//a[contains(@title,'{itemTitle}') and .='{itemTitle}']";

        public static void dblClickItem(String title) throws Exception {

            debug("Click item in doc workspace: " + title + "");
//            waitForElementPresentAndDblClick(getItemLocator(title));
            waitForAndGetElement(getItemLocator(title));
            doubleClickOnElement(getItemLocator(title));
            waitForOperationToFinish();

        }

        public static void clickItem(String title) throws Exception {

            debug("Dbl click item in doc workspace: " + title + "");
            waitForElementPresentAndClick(getItemLocator(title));
            waitForOperationToFinish();

        }

        public static String getItemLocator(String itemTitle) throws Exception {
            String locator_rowView = LOCATOR_ITEM_TPL.replace("{itemTitle}", itemTitle);
            return locator_rowView;
        }
    }

    public static class DocumentWorkspace {

        public static final String LOCATOR = "//div[@id='UIDocumentWorkspace']";
        public static final String BUTTON_SAVE = "//a[contains(@class, 'ActionButton') and .='Save']";
        public static final String BUTTON_CLOSE = "//a[contains(@class, 'ActionButton') and .='Close']";
        public static final String BUTTON_SAVE_AND_CLOSE = "//a[contains(@class, 'ActionButton') and contains(.,'Save & Close')]";
        public static final String JCR_CONTEXT_MENU = "//div[@id='JCRContextMenu']";
        public static final String LOCATOR_ITEM_TPL = LOCATOR + "//div[contains(@class,'RowView') and .//div[.='{itemTitle}']]";

        public static void dblClickItem(String title) throws Exception {

            debug("Dbl click item in doc workspace: " + title + "");
//            String itemLocator = LOCATOR
//                    + "//div[contains(@ondblclick,'" + title.replace(' ', '+') + "')]";
//            waitForElementPresentAndDblClick(getItemLocator(title));
            waitForAndGetElement(getItemLocator(title));
            doubleClickOnElement(getItemLocator(title));
            waitForOperationToFinish();

        }

        public static void browse(String... path) throws Exception {
            for (String pathItem : path) {
                dblClickItem(pathItem);
                waitForOperationToFinish();
            }
        }

        public static String getItemLocator(String itemTitle) throws Exception {
            String locator_rowView = LOCATOR_ITEM_TPL.replace("{itemTitle}", itemTitle);
            return locator_rowView;
        }

        public static String getItemLocator(int index) throws Exception {
            String locator_rowView = LOCATOR + "//div[contains(@class,'Normal')][" + index + "]";
            return locator_rowView;
        }

        public static void verifyItemPresent(String itemTitle) throws Exception {
            verifyItemPresence(itemTitle, true);
        }

        public static void verifyItemNotPresent(String itemTitle) throws Exception {
            verifyItemPresence(itemTitle, false);
        }

        public static void verifyItemPresence(String itemTitle, boolean present) throws Exception {
            debug("Verify item '" + itemTitle + "' is " + (present ? "" : "not ") + "present");
            String locDocument = getItemLocator(itemTitle);
            trace(locDocument);
            waitForAndGetElement(LOCATOR);
            pause(200);
            assertTrue(present
                    ? isElementPresent(locDocument)
                    : isElementNotPresent(locDocument)); // TODO simplify expression
        }

        public static void checkItemStatus(String itemTitle, String status) throws Exception {
            info("Check if item '" + itemTitle + "' has '" + status + "' status");

            String locatorStatus = getItemLocator(itemTitle)
                    + "//div[.='" + status + "' and @title='status']";
            waitForAndGetElement(locatorStatus);
        }

        // FIXME debug context menu in DocumentWorkspace
        public static void contextActionForItem(String itemTitle, String actionTitle) throws Exception {

            String itemLocator = getItemLocator(itemTitle);//+"//div[@class='ColumnName']//div[@class='NodeLabel']";

            waitForElementPresentAndClick(itemLocator);
            //getSelenium().focus(itemLocator);

            debug("item should be selected: " + itemTitle);

            contextMenuOnElement(itemLocator);

            String actionLocator = ECM_CONTEXT_MENU + "//a[contains(.,'" + actionTitle + "')]";
            waitForElementPresentAndClick(actionLocator);
        }

        public static void save() throws Exception {
            waitForElementPresentAndClick("link=Save");
            waitForOperationToFinish();
        }

        public static void saveAndClose() throws Exception {
            waitForElementPresentAndClick(BUTTON_SAVE_AND_CLOSE);
            waitForOperationToFinish();
        }

        public static void close() throws Exception {
            //clickButtonInElement(LOCATOR, BUTTON_CLOSE, false);
            waitForElementPresentAndClick("link=Close");
            waitForOperationToFinish();
        }

//        public static void saveDraftAndClose() throws Exception {
//            save();
//            close();
//        }
//        public static final String LOCATOR_SELECT_TEMPLATE = "//select[@name='selectTemplate']";
        private static void selectTemplate(String contentTypeTitle) throws Exception {
            //waitForElementPresentAndSelect(LOCATOR_SELECT_TEMPLATE, "value=" + contentTypeTitle);

            String locTemplate = "//div[@class='TemplateBox' and .//div[@title='" + contentTypeTitle + "']]";
            waitForElementPresentAndClick(locTemplate);

            pause(1000);
        }

        public static void fillCreateForm(Content document) throws Exception {
            document.fillCreateForm(LOCATOR);
        }

        public static void fillUpdateForm(Content document) throws Exception {
            document.fillUpdateForm(LOCATOR);
        }

        public static void verifyDisplayedContent(Content document) throws Exception {
            document.verifyDisplayedContent(LOCATOR);
        }

        private static boolean isItemPresent(String itemTitle) throws Exception {
            return isElementPresent(getItemLocator(itemTitle));
        }
    }

    public static class DrivesArea {

        public static String LOCATOR = "//div[@id='UIDrivesArea']";
        public static String LINK_DRIVE_TEMPLATE = LOCATOR
                + "//div[@class='Drive']//a[@class='DriveLabel' and @title='${drive}']";

        public static boolean isDrivePresent(String drive) throws Exception {
            return isElementPresent(DrivesArea.LINK_DRIVE_TEMPLATE.replace("${drive}", drive));
        }

        public static void openDrive(String drive) throws Exception {

            String locatorDriveLink = DrivesArea.LINK_DRIVE_TEMPLATE.replace("${drive}", drive);
            waitForElementPresentAndClick(locatorDriveLink);
            waitForAndGetElement(DocumentWorkspace.LOCATOR);

        }
        
        public static void verifyDrivePresence(String drive, boolean present) throws Exception {
            info("Verify drive '" + drive + "' is " + (present ? "" : "not ") + "present");
            SideBar.showDrivesArea();
            assertEquals(DrivesArea.isDrivePresent(drive), present);
        }
    }

    public static class ContentManagement {

        public static final String ACTION_COPY = "Copy";
        public static final String ACTION_CUT = "Cut";
        public static final String ACTION_PASTE = "Paste";
        public static final String ACTION_RENAME = "Rename";
        public static final String ACTION_DELETE = "Delete";
        public static final String POPUP_ADD_FOLDER = POPUP_LOCATOR_TEMPLATE.replace("{popupTitle}","New Folder");
        public static final String POPUP_RENAME = POPUP_LOCATOR_TEMPLATE.replace("{popupTitle}","Rename");
        public static final String POPUP_DELETE = POPUP_LOCATOR_TEMPLATE.replace("{popupTitle}","Confirm Deletion");

        public static void save(String locator) throws Exception {
//            waitForElementPresentAndClick("link=Save");
            clickButtonInElement(locator, "Save", true);
        }

        public static void confirmDelete() throws Exception {
//            waitForElementPresentAndClick("link=OK");
            clickButtonInElement(POPUP_DELETE, "OK", true);
        }

        public static void deleteItem(String itemTitle) throws Exception {
            SideBar.FileExplorer.contextActionForItem(itemTitle, ACTION_DELETE);
            pause(4600);
            confirmDelete();
            pause(4600);
        }

        public static void renameItem(String itemTitle, String newName) throws Exception {
            SideBar.FileExplorer.contextActionForItem(itemTitle, ACTION_RENAME);
//            waitForElementPresentAndType("nameField", newName);
             waitForAndGetElement("nameField");
            type("nameField", newName, false);
            save(POPUP_RENAME);
            waitForOperationToFinish();
        }

        public static void renameItem(String itemTitle, String newName, String newTitle) throws Exception {
            SideBar.FileExplorer.contextActionForItem(itemTitle, ACTION_RENAME);
//            waitForElementPresentAndType("//input[@id='nameField']", newName);
            waitForAndGetElement("//input[@id='nameField']");
            type("//input[@id='nameField']", newName, false);
//            waitForElementPresentAndType("//input[@id='titleField']", newTitle);
             waitForAndGetElement("//input[@id='titleField']");
            type("//input[@id='titleField']", newTitle, false);
            save(POPUP_RENAME);
            waitForOperationToFinish();
        }

        static void copyItem(String itemTitle) throws Exception {
            SideBar.FileExplorer.contextActionForItem(itemTitle, ACTION_COPY);
            waitForOperationToFinish();
        }

        static void cutItem(String itemTitle) throws Exception {
            SideBar.FileExplorer.contextActionForItem(itemTitle, ACTION_CUT);
            waitForOperationToFinish();
        }

        static void paste(String targetFolderTitle) throws Exception {
            SideBar.FileExplorer.contextActionForItem(targetFolderTitle, ACTION_PASTE);
            waitForOperationToFinish();
        }
    }

    public static class Navigation {

        public static void showDrives() throws Exception {
            SideBar.showDrivesArea();
        }

        public static void openDrive(String drive) throws Exception {
            debug("Open drive: " + drive + "");
            showDrives();
            DrivesArea.openDrive(drive);
        }

        public static void browse(String... path) throws Exception {
            browseFileExplorer(path);
        }

        public static void browseDocumentWorkspace(String... path) throws Exception {
            DocumentWorkspace.browse(path);
        }

        public static void browseFileExplorer(String... path) throws Exception {
            SideBar.FileExplorer.browse(path);
        }

        public static void browseUp() throws Exception {
            SideBar.FileExplorer.browseUp();
        }

        public static void browseUp(int levels) throws Exception {
            for (int i = 0; i < levels; i++) {
                browseUp();
            }
        }
    }

    public static void addItem(Content item) throws Exception {
        if (item instanceof Folder) {
            addFolder((Folder) item, true);
        } else {
            addContent(item);
        }
    }

    public static void addContent(Content document) throws Exception {
        ActionBar.addContent();
        DocumentWorkspace.selectTemplate(document.getContentTypeTitle());
        DocumentWorkspace.fillCreateForm(document);
        DocumentWorkspace.saveAndClose();
    }

    public static void addContentIntoContext(Content document, String location) throws Exception {
        //click(location);
        DocumentWorkspace.selectTemplate(document.getContentTypeTitle());
        DocumentWorkspace.fillCreateForm(document);
        DocumentWorkspace.saveAndClose();
        waitForAndGetElement(BACK_TO_BUTTON);
        click(BACK_TO_BUTTON);
    }

    public static void editContent(Content document) throws Exception {
        waitForAndGetElement(DOCUMENT_EDITING);
        click(DOCUMENT_EDITING);
//        DocumentWorkspace.fillCreateForm(document);
        DocumentWorkspace.fillUpdateForm(document);
        DocumentWorkspace.saveAndClose();
    }

    public static void addFolder(Folder folder, boolean browseAfterCreation) throws Exception {
        ActionBar.addFolder();
        folder.fillCreateForm(ContentManagement.POPUP_ADD_FOLDER);
        ContentManagement.save(ContentManagement.POPUP_ADD_FOLDER);
        waitForOperationToFinish();
        if (!folder.getItems().isEmpty()) {
            Navigation.browse(folder.getTitle());
            // add subitems
            for (Content item : folder.getItems()) {
                addItem(item);
                Navigation.browseUp();
            }
            Navigation.browseUp();
        }
        if (browseAfterCreation) {
            Navigation.browse(folder.getTitle());
        }
    }
    
    public static void addFolderForUser(Folder folder, boolean browseAfterCreation) throws Exception {
        ActionBar.invokeAction("New Folder"); 
        folder.fillCreateForm(ContentManagement.POPUP_ADD_FOLDER);
        ContentManagement.save(ContentManagement.POPUP_ADD_FOLDER);
        waitForOperationToFinish();
        if (!folder.getItems().isEmpty()) {
            Navigation.browse(folder.getTitle());
            // add subitems
            for (Content item : folder.getItems()) {
                addItem(item);
                Navigation.browseUp();
            }
            Navigation.browseUp();
        }
        if (browseAfterCreation) {
            Navigation.browse(folder.getTitle());
        }
    }
    
    public static void goToACMEFolder() throws Exception {
        SideBar.showDrivesArea();
        DrivesArea.openDrive(DRIVE_SITES_MANAGEMENT);
        DocumentWorkspace.browse("acme");
    }
    
    public static void goToCollaborationAcmeUserFolder(String title) throws Exception {
        SideBar.showDrivesArea();
        DrivesArea.openDrive(DRIVE_COLLABORATION);
        DocumentWorkspace.browse("sites content", "live", "acme", title);
    }

    public static void goToACMEWebContentsFolder() throws Exception {
        SideBar.showDrivesArea();
        DrivesArea.openDrive(DRIVE_SITES_MANAGEMENT);
        DocumentWorkspace.browse("acme", "web contents");
    }

    public static void goToACMEDocumentsFolder() throws Exception {
        SideBar.showDrivesArea();
        DrivesArea.openDrive(DRIVE_SITES_MANAGEMENT);
        DocumentWorkspace.browse("acme", "documents");
    }

    public static void goToACMECategoryFolder() throws Exception {
        SideBar.showDrivesArea();
        DrivesArea.openDrive(DRIVE_SITES_MANAGEMENT);
        DocumentWorkspace.browse("acme", "categories", "acme");
    }

    public static void addFolderIfMissing(String name, boolean browse) throws Exception {
        if (!DocumentWorkspace.isItemPresent(name)) {
            addFolder(new Folder(name), browse);
        } else {
            if (browse) {
                Navigation.browse(name);
            }
        }
    }

    public static void goToTestFolder(String testName) throws Exception {
        SideBar.showDrivesArea();
        DrivesArea.openDrive(DRIVE_SITES_MANAGEMENT);
        addFolderIfMissing(testName, false);
        Navigation.browse(testName);
    }
}
