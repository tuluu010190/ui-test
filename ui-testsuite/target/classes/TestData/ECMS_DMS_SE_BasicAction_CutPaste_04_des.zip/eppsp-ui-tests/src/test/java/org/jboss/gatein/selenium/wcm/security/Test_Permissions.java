package org.jboss.gatein.selenium.wcm.security;

import org.jboss.gatein.selenium.AbstractWCMTestCase;
import static org.jboss.gatein.selenium.wcm.content.ContentExplorer.*;
import org.jboss.gatein.selenium.wcm.content.type.Folder;
import static org.testng.Assert.assertTrue;
import org.testng.annotations.Test;
import static org.jboss.gatein.selenium.WCMCommonHelper.*;
import static org.jboss.gatein.selenium.testng.TestLogger.*;

/**
 *
 * @author tkyjovsk
 */
public class Test_Permissions extends AbstractWCMTestCase {

    /**
     * sets add node permissions for User, then user adds node
     *
     * @throws Exception
     */
    @Test(enabled = true)
    public void test_folderAddNodeUser() throws Exception {

        String title = "cf_" + generateTimeStampSuffix();
       

        goToACMEPortal();
        //goToPage("//div[contains(., 'Acme Corp')]", new String[]{"Site","acme"} );

        signInAsRoot();

        goToPage("//div[contains(., 'Content Manager')]", new String[]{ELEMENT_LINK_GROUP, ELEMENT_LINK_CONTENT_EXPLORER});
        
        goToACMEFolder();

        addFolder(new Folder(title), true);

        deleteContentPermissions("web-contributors");

        setContentPermissions("james", null, null, true, true, false, false);
        //   setContentPermissions(null, "platform/guests", "*", true, true, false, false);

        signOut();


        signIn("james", "gtn");

        goToPage("//div[contains(., 'Content Manager')]", new String[]{ELEMENT_LINK_GROUP, ELEMENT_LINK_CONTENT_EXPLORER});

        goToCollaborationAcmeUserFolder(title);

        addFolderForUser(new Folder("james"), false);

        assertTrue(isElementPresent(DocumentWorkspace.LOCATOR_ITEM_TPL.replace("{itemTitle}", "james")));

        signOut();

        signInAsRoot();

        goToPage("//div[contains(., 'Content Manager')]", new String[]{ELEMENT_LINK_GROUP, ELEMENT_LINK_CONTENT_EXPLORER});

        goToACMEFolder();

        ContentManagement.deleteItem(title);

    }

    /**
     * sets permissions for member of group, another users from this don't have
     * permissions
     *
     * @throws Exception
     */
//    @Test(enabled = false)
//    public void test_folderGroupAddPermissions() throws Exception {
//
//        String title = "cf_" + generateTimeStampSuffix();
//
//        goToPortal("ecmdemo", "acme", false);
//
//        signInAsRoot();
//
//        goToPage("//div[contains(., 'Content Manager')]", new String[]{ELEMENT_LINK_GROUP, ELEMENT_LINK_CONTENT_EXPLORER});
//
//        goToACMEFolder();
//
//        addFolder(new Folder(title), true);
//
//        deleteContentPermissions("web-contributors");
//
//        // setContentPermissions("james", null, null, true, true, false, false);
//        setContentPermissions(null, "platform/web-contributors", "redactor", true, true, true, true);
//
//signOut();
//
//        signinAsJames();
//
//        goToPage("//div[contains(., 'Content Manager')]", new String[]{ELEMENT_LINK_GROUP, ELEMENT_LINK_CONTENT_EXPLORER});
//
//        goToCollaborationAcmeUserFolder(title);
//
//        addFolderForUser(new Folder("james"), false);
//
//        assertTrue(isElementPresent(DocumentWorkspace.LOCATOR_ITEM_TPL.replace("{itemTitle}", "james")));
//
// signOut();
//
//        signinAsJames();
//
//        goToPage("//div[contains(., 'Content Manager')]", new String[]{ELEMENT_LINK_GROUP, ELEMENT_LINK_CONTENT_EXPLORER});
//
//        goToCollaborationAcmeUserFolder(title);
//
//        ActionBar.invokeAction("New Folder");
//
//        pause(2600);
//
//        assertTrue(isElementPresent("//span[contains(.,'You do not have permission to add a new node.')]"));
//
//   signOut();
//
//        signInAsRoot();
//
//        goToPage("//div[contains(., 'Content Manager')]", new String[]{ELEMENT_LINK_GROUP, ELEMENT_LINK_CONTENT_EXPLORER});
//
//        goToACMEFolder();
//
//        ContentManagement.deleteItem(title);
//
//    }
    /**
     * sets permissions true for user in one group, sets to false for the same
     * user in second group
     *
     * @throws Exception
     */
    @Test(enabled = true)
    public void test_folderTwoGroups() throws Exception {

        String title = "cf_" + generateTimeStampSuffix();

        goToACMEPortal();

        signInVerified("root", "gtn");
    //    signInAsRoot();

        goToPage("//div[contains(., 'Content Manager')]", new String[]{ELEMENT_LINK_GROUP, ELEMENT_LINK_CONTENT_EXPLORER});

        goToACMEFolder();

        addFolder(new Folder(title), true);

        deleteContentPermissions("web-contributors");

        // setContentPermissions("james", null, null, true, true, false, false);
        setContentPermissions(null, "platform/users", "*", true, true, true, true);

        setContentPermissions(null, "platform/web-contributors", "redactor", true, false, false, false);

        signOut();

        signIn("james", "gtn");

        goToPage("//div[contains(., 'Content Manager')]", new String[]{ELEMENT_LINK_GROUP, ELEMENT_LINK_CONTENT_EXPLORER});

        goToCollaborationAcmeUserFolder(title);

        addFolderForUser(new Folder("james"), false);

        assertTrue(isElementPresent(DocumentWorkspace.LOCATOR_ITEM_TPL.replace("{itemTitle}", "james")));

        ContentManagement.deleteItem(title);

        assertTrue(isElementNotPresent(DocumentWorkspace.LOCATOR_ITEM_TPL.replace("{itemTitle}", title)));

    }
}
