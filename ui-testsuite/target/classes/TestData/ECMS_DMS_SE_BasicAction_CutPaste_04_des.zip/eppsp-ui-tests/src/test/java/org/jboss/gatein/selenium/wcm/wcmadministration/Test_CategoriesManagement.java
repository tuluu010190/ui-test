/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package org.jboss.gatein.selenium.wcm.wcmadministration;

import org.jboss.gatein.selenium.AbstractWCMTestCase;
import static org.jboss.gatein.selenium.WCMCommonHelper.*;
import static org.jboss.gatein.selenium.common.CommonHelper.*;
import static org.jboss.gatein.selenium.wcm.content.ContentExplorer.goToACMECategoryFolder;
import static org.jboss.gatein.selenium.wcm.wcmadministration.AdministrationManagement.addCategory;
import static org.testng.Assert.assertTrue;
import org.testng.annotations.Test;

/**
 *
 * @author mgottval
 */
public class Test_CategoriesManagement extends AbstractWCMTestCase {
    
    @Test(groups={"broken"}, enabled=true)
    public void test_manageCategories() throws Exception {
    
    goToACMEPortal();
        
    signInAsRoot();
    
    goToPage("//div[contains(., 'Manage ECM Main Functions')]", new String[]{ELEMENT_LINK_GROUP, ELEMENT_LINK_CONTENT_ADMINISTRATION});
    
    addCategory("acme", "CATEGORY1");
    
    goToPage("//div[contains(., 'Content Manager')]", new String[]{ELEMENT_LINK_GROUP, ELEMENT_LINK_CONTENT_EXPLORER});
    
    goToACMECategoryFolder();
    
    assertTrue(isVisible("//a[contains(@title, 'CATEGORY1') and contains(., 'CATEGORY1')]"));
    
//    addCategoryByDriveManagement("acme-category", "CATEGORY2");
//    
//    goToACMECategoryFolder();
//    
//    assertTrue(isVisible("//a[contains(@title, 'CATEGORY2') and contains(., 'CATEGORY2')]"));
    
    }

    
    
    
}
