/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package org.jboss.gatein.selenium.wcm.wcmadministration;

import static org.jboss.gatein.selenium.WCMCommonHelper.*;
import static org.jboss.gatein.selenium.common.CommonHelper.*;
import static org.jboss.gatein.selenium.testng.TestLogger.*;

/**
 *
 * @author mgottval
 */
public class EditView {

    public static final String CONTENT_PRESENTATION = "//div[@class='TabLabel' and contains(.,'Content Presentation')]";
    public static final String MANAGE_VIEW = "//div[@class='UIVTabContent']//a[contains(., 'Manage View')]";
    public static final String NEXT = "//div[@class='UITabContentContainer']//a[@title='Next Page']";
    public static final String PUBLICATION_VIEW_TAB = POPUP_LOCATOR_TEMPLATE.replace("{popupTitle}","Edit View") + "//a[@title='Publication' and contains(., 'Publication')]";
    public static final String ADD_TRANSLATION = POPUP_LOCATOR_TEMPLATE.replace("{popupTitle}","Edit View") + "//td[.='Add Translation']//..//input[@class='checkbox']";
    public static final String SAVE_BUTTON = POPUP_LOCATOR_TEMPLATE.replace("{popupTitle}","Edit View") + "//a[.='Save']";
    public static final String EDIT_VIEW = "//div[.='${viewName}']//..//..//img[@title='Edit']";

    public static String getLocatorEditView(String viewName) {
        return EDIT_VIEW.replace("${viewName}", viewName);
    }

    public static void addTranslationIntoWcmView(String viewName) throws Exception {

        pause(1000);
        waitForElementPresentAndClick(CONTENT_PRESENTATION);
        pause(1000);

        waitForElementPresentAndClick(MANAGE_VIEW);

        waitForElementPresentAndClick(NEXT);

        waitForElementPresentAndClick(getLocatorEditView(viewName));

        waitForElementPresentAndClick(PUBLICATION_VIEW_TAB);

        waitForElementPresentAndClick(ADD_TRANSLATION);
        pause(3000);
        waitForElementPresentAndClick(SAVE_BUTTON);
        pause(3000);
        waitForElementPresentAndClick(SAVE_BUTTON);
        pause(3000);
    }
}
