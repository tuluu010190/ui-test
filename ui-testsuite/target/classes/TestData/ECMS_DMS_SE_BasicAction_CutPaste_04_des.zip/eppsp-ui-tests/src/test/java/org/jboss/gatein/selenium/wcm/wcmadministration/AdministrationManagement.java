package org.jboss.gatein.selenium.wcm.wcmadministration;


import static org.jboss.gatein.selenium.WCMCommonHelper.*;
import static org.jboss.gatein.selenium.common.CommonHelper.*;
import org.jboss.gatein.selenium.wcm.content.ContentExplorer.ActionBar;
import org.jboss.gatein.selenium.wcm.content.ContentExplorer.Navigation;
/**
 *
 * @author mgottval
 */
public class AdministrationManagement {
    
    
    public static final String MANAGE_CATEGORIES = "//a[contains(.,'Manage Categories')]";
    public static final String EDIT_CATEGORIES = "//div[@title='${portalName}' and .='${portalName}']/../..//img[contains(@title,'Edit Category Tree')]";
    public static final String CATEGORY_ADD = "//img[@title='Add']";
    public static final String ADMIN_INPUT_CATEGORY_NAME = "//input[@id='taxonomyName']";
   // public static final String SAVE_BUTTON = "//a[contains(@class,'ActionButton') and .='Save']";
    public static final String ADMIN_SAVE_BUTTON = "//td[contains(.,'Category Name')]/../../../..//a[contains(@class,'ActionButton') and .='Save']";
    public static final String ADMIN_CLOSE_BUTTON = "//a[.='Close']";
    public static final String ADMIN_LOCATOR = POPUP_LOCATOR_TEMPLATE.replace("{popupTitle}", "Edit Category Tree");
    
    public static final String INPUT_CATEGORY_NAME = "//input[@id='name']";
    public static final String LOCATOR = POPUP_LOCATOR_TEMPLATE.replace("{popupTitle}","Add Category");
    public static final String SAVE_BUTTON = "//a[contains(@class,'ActionButton') and .='Save']";
    
    public static String getLocationEditCategory(String portal) {
        return EDIT_CATEGORIES.replace("${portalName}", portal);
    }
    
    public static void addCategory(String portal, String categoryname) throws Exception {
        goToPage("//div[contains(., 'Manage ECM Main Functions')]", new String[]{ELEMENT_LINK_GROUP, ELEMENT_LINK_CONTENT_ADMINISTRATION});

        waitForAndGetElement(MANAGE_CATEGORIES);

        click(MANAGE_CATEGORIES);

        waitForAndGetElement(getLocationEditCategory(portal));

        click(getLocationEditCategory(portal));

        pause(3600);
        //waitForElementPresentAndClick(LOCATOR+"//div[@title='acme']");//
        //waitForElementPresentAndClick(LOCATOR+"//div[@title='World']/../..//img[@title='Add']");//
        //waitForElementPresentAndClick(CATEGORY_ADD);
        waitForElementPresentAndClick(ADMIN_LOCATOR+CATEGORY_ADD);
        
        
        pause(3600);
        waitForAndGetElement(ADMIN_LOCATOR+ADMIN_INPUT_CATEGORY_NAME);
        type(ADMIN_LOCATOR+ADMIN_INPUT_CATEGORY_NAME, categoryname, false);
        pause(3600);

        waitForElementPresentAndClick(ADMIN_SAVE_BUTTON);
        pause(3600);

        waitForElementPresentAndClick(ADMIN_LOCATOR+ADMIN_CLOSE_BUTTON);
    }
    
    public static void addCategoryByDriveManagement(String drive, String categoryName) throws Exception{
        Navigation.openDrive("acme-category");

        ActionBar.addCategory();

        waitForAndGetElement(LOCATOR+INPUT_CATEGORY_NAME);
        type(LOCATOR+INPUT_CATEGORY_NAME, categoryName, false);
        pause(3600);
        
        waitForElementPresentAndClick(LOCATOR+SAVE_BUTTON);
        
    }
    
}
