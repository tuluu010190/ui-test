//package org.jboss.gatein.selenium.wcm.security;
//
//import static org.jboss.gatein.selenium.CommonCommands.*;
//import static org.jboss.gatein.selenium.portal.CommonWebUI.*;
//import static org.jboss.gatein.selenium.wcm.ECMDemo.*;
//import static org.jboss.gatein.selenium.wcm.content.ContentExplorer.*;
//import org.jboss.gatein.selenium.wcm.content.type.File.Metadata;
//
//
//import org.jboss.gatein.selenium.PortalTest;
//import java.text.SimpleDateFormat;
//import java.util.Date;
//import org.jboss.gatein.selenium.wcm.content.type.File;
//import org.testng.annotations.DataProvider;
//import org.testng.annotations.Test;
//
///**
// *
// * @author Tomas Kyjovsky <tkyjovsk at redhat dot com>
// */
//public class Test_XSS extends PortalTest {
//
//    @DataProvider
//    public Object[][] provideContentTypes() {
//        return new Object[][]{
//                    {"rma:filePlan", "name", "title"}
//                };
//    }
//    private static final SimpleDateFormat sdf = new SimpleDateFormat("yyyy.MM.dd - HH'h'mm'm'");
//
//    // FIXME problems with element locator for created 'contactus' document
//    @Test(groups={"broken"}, enabled=false)
//    public static void test_XSS_SPREDHAT50() throws Exception {
//
//        goToACMEPortalPage("contactus");
//
//        String script = "<script>xss50=1</script>";
//        type("your_nameFieldName", script);
//        type("your_addressFieldName", script);
//        type("your_messageFieldName", script);
//        type("your_email_addressFieldName", script);
//        type("your_phone_numberFieldName", script);
//
//        clickButtonInElement("//form[@id='UIFCCForm']", "Send", true);
//        String docTitle = sdf.format(new Date());
//        info("Doc: " + docTitle);
//        waitForPageToLoad();
//
//        signIn("root", "gtn");
//        goToPage("//div[contains(., 'Content Manager')]", new String[]{ELEMENT_LINK_GROUP, ELEMENT_LINK_CONTENT_EXPLORER});
//        Navigation.openDrive(DRIVE_SITES_MANAGEMENT);
//        SideBar.FileExplorer.browse("acme", "documents");
//        doubleClickOnElement(DocumentWorkspace.getItemLocator(docTitle));
//        waitForOperationToFinish();
//
//        ContentManagement.deleteItem(docTitle);
//
//        if ("1".equals(getSelenium().getEval("window.xss50"))) {
//            fail("Vulnerable to XSS");
//        }
//    }
//    
//    @Test
//    public void test_XSS_File() throws Exception {
//        
//        String script = "<script>xss_file=1</script>";
//        
//        goToACMEPortal();
//        signInAsRoot();
//        goToPage("//div[contains(., 'Content Manager')]", new String[]{ELEMENT_LINK_GROUP, ELEMENT_LINK_CONTENT_EXPLORER});
//        goToACMEDocumentsFolder();
//
//        String name = "xss_file"+generateTimeStampSuffix();
//        File file = new File(name);
//        file.setContent(script);
//        file.getMetadata().setTitle(new String[]{script+" title"});
//        file.getMetadata().setDescription(new String[]{script+" description"});
//        
//        addContent(file);
//        
////        type("title0", script+"title");
////        type("description0", script+"description");
////
////        DocumentWorkspace.saveAndClose();
//        
//        if ("1".equals(getSelenium().getEval("window.xss_file"))) {
//            fail("Content type 'File' is vulnerable to XSS");
//        }
//        
//    }
//
//}
