package org.jboss.gatein.selenium.wcm.content;

import java.io.IOException;
import org.jboss.gatein.selenium.wcm.content.type.WebContent;
import static org.jboss.gatein.selenium.WCMCommonHelper.*;
import static org.jboss.gatein.selenium.common.CommonHelper.*;
import static org.jboss.gatein.selenium.page.PageHelper.*;
import static org.jboss.gatein.selenium.testng.TestLogger.*;
import static org.jboss.gatein.selenium.wcm.presentation.SCV.*;
import static org.jboss.gatein.selenium.wcm.presentation.CLV.*;
import static org.jboss.gatein.selenium.wcm.content.ContentExplorer.*;

/**
 *
 * @author Tomas Kyjovsky <tkyjovsk at redhat dot com>
 */
public class Publication {

    public static final String PORTLET_EDITING = "//div[@id='UIEditingPortlet']";
    public static final String SELECT_EDITING_OPTIONS = PORTLET_EDITING + "//select[@name='EditingOptions']";
    public static final String TITLE_MANAGE_PUBLICATION = "Manage Publication";
    public static final String POPUP_MANAGE_PUBLICATION = POPUP_LOCATOR_TEMPLATE.replace("{popupTitle}", TITLE_MANAGE_PUBLICATION);
    public static final String ACTION_STATUS = "//div[@class='StatusAction']";
//    public static final String LINK_STATUS_TEMPLATE = ACTION_STATUS + "//a[.='${status}']";
    public static final String LINK_STATUS_TEMPLATE = ACTION_STATUS + "//a[5]";
    public static final String STATUS_ENROLLED = ACTION_STATUS + "//a[.='Enrolled']";
    public static final String STATUS_DRAFT = ACTION_STATUS + "//a[.='Draft']";
    public static final String STATUS_PUBLISHED = ACTION_STATUS + "//a[.='Published']";
    public static final String STATUS_OBSOLETE = ACTION_STATUS + "//a[.='Obsolete']";
    public static final String EDIT_PORTLET_SAVE = "//div[@class='HorizontalLayout']//a[.='Save']";
    public static final String EDIT_PORTLET_CLOSE = "//div[@class='HorizontalLayout']//a[.='Close']";

    //Selenium
//    public static void switchPortalToEditMode() {
//
//        info("Switch portal to EDIT mode");
//
//        select(SELECT_EDITING_OPTIONS, "value=Draft");
//
//        pause(1000);
//
//    }
    public static void switchPortalToEditMode() throws IOException {

        info("Switch portal to EDIT mode");

        select(SELECT_EDITING_OPTIONS, "Edit");

        pause(1000);

    }

    //Selenium
//    public static void switchPortalToPublishedMode() {
//
//        info("Switch portal to PUBLISHED mode");
//
//        select(SELECT_EDITING_OPTIONS, "value=Published");
//
//        pause(1000);
//
//    }
    public static void switchPortalToPublishedMode() throws IOException {

        info("Switch portal to PUBLISHED mode");

        select(SELECT_EDITING_OPTIONS, "Published");

        pause(1000);

    }

    public static void selectStatus(String status) throws Exception {

        String locatorLinkStatus = LINK_STATUS_TEMPLATE.replace("${status}", status);

        waitForElementPresentAndClick(locatorLinkStatus);

        clickButtonInElement(POPUP_MANAGE_PUBLICATION, "Close", true);

    }

    public static void addSCVPortletWithContent(String title, Boolean advanced, String page) throws Exception {

        // TODO move from here to test

        goToACMEPortalPage(page);

        goToEditPage();

        selectTabs("Applications", "Content");
//        dragAndDropPortletToPage("Content", "Content Detail");
        dragAndDropToObject("//div[@id='Content/SingleContentViewer']", "//div[@class='UIRowContainer']/div[1]/div", "//div[contains(.,'Content Detail')]");

        editPortlet("Content Detail");

        selectContent(title);

        if (advanced) {
            setAdvancedSCV();
        }

        info("Finish page edit");

        waitForAndGetElement(EDIT_PORTLET_SAVE);

        click(EDIT_PORTLET_SAVE);

        waitForAndGetElement(EDIT_PORTLET_CLOSE);

        click(EDIT_PORTLET_CLOSE);

        finishPageEdit();


    }

    public static void deleteAllPortlets(String page) throws Exception {

        goToACMEPortalPage(page);

        goToEditPage();

        while (isElementPresent("//div[@class='UIRowContainer']//div[contains(@class, 'UIPortlet')]")) {

//            mouseOverAndClick("//div[@class='UIRowContainer']//div[contains(@class, 'UIPortlet')]", "//div[@class='UIRowContainer']//div[contains(@class, 'UIPortlet')]//a[contains(@title,'Delete Portlet')]");
            mouseOver("//div[@class='UIRowContainer']//div[contains(@class, 'UIPortlet')]", false);
            click("//div[@class='UIRowContainer']//div[contains(@class, 'UIPortlet')]//a[contains(@title,'Delete Portlet')]");
            waitForConfirmation("Are you sure you want to delete this portlet?");
        }

        waitForAndGetElement(POPUP_LOCATOR_TEMPLATE.replace("{popupTitle}", "Page Editor"));

        waitForElementPresentAndClick(POPUP_LOCATOR_TEMPLATE.replace("{popupTitle}", "Page Editor") + "//a[@title='Finish']");

    }

    public static void addCLVPortletWithContent(String fileTitle, Boolean advanced, String page) throws Exception {

        // TODO move from here to test

        goToACMEPortalPage(page);

        goToEditPage();
        selectTabs("Applications", "Content");
//        dragAndDropPortletToPage("Content", "Content Detail");
        dragAndDropToObject("//div[@id='Content/ContentListViewerPortlet']", "//div[@class='UIRowContainer']/div[1]/div", "//div[contains(.,'Content List')]");
        pause(3600);

        editPortlet("Content List");

        selectContentFile(fileTitle, advanced, page);

        if (advanced) {
            setAdvanced(page);
        }
        pause(3600);

        info("Finish page edit");

        waitForAndGetElement(EDIT_PORTLET_SAVE);

        click(EDIT_PORTLET_SAVE);

        waitForAndGetElement(EDIT_PORTLET_CLOSE);

        click(EDIT_PORTLET_CLOSE);

        finishPageEdit();

    }

    public static void addDocumentAndPublish(String title) throws Exception {

        goToPage("//div[contains(., 'Content Manager')]", new String[]{ELEMENT_LINK_GROUP, ELEMENT_LINK_CONTENT_EXPLORER});

        goToACMECategoryFolder();

        addItem(new WebContent(title, "Main content of " + title, "Summary of " + title, "CSS", "JS"));

        TreeExplorerWorkspace.dblClickItem(title);

        ActionBar.invokeAction("Publication", "Publications");

        selectStatus("Published");


    }

    public static void changeDocumentStatus(String[] path, String title, String status)
            throws Exception {

        goToPage("//div[contains(., 'Content Manager')]", new String[]{ELEMENT_LINK_GROUP, ELEMENT_LINK_CONTENT_EXPLORER});

        Navigation.openDrive(DRIVE_SITES_MANAGEMENT);

        SideBar.FileExplorer.browse(path);

        DocumentWorkspace.dblClickItem(title);

        ActionBar.invokeAction("Publication", "Publications");

        selectStatus(status);

    }

    public static void saveAsDraftEditedDocument(String title)
            throws Exception {

        goToPage("//div[contains(., 'Content Manager')]", new String[]{ELEMENT_LINK_GROUP, ELEMENT_LINK_CONTENT_EXPLORER});

        goToACMECategoryFolder();

        TreeExplorerWorkspace.clickItem(title);

        editContent(new WebContent("-Edit", "Main content of " + title + "-Edit", "Summary of " + title + "-Edit", "CSS", "JS"));


    }

    public static void changeContentInSCVAndC(String element) throws IOException {

        waitForElementPresentAndClick(element);



    }
}
