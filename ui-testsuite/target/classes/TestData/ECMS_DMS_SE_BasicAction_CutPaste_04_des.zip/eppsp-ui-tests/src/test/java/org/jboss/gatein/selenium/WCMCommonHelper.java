package org.jboss.gatein.selenium;

import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.jboss.gatein.selenium.common.CommonHelper;
import static org.jboss.gatein.selenium.testng.TestLogger.*;
import org.jboss.gatein.selenium.wcm.content.ContentExplorer;
import org.jboss.gatein.selenium.wcm.wcmadministration.AdministrationManagement;
//import static org.jboss.gatein.selenium.testng.TestLogger.trace;
import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.WebDriverWait;

/**
 *
 * @author mgottval
 */
public class WCMCommonHelper extends CommonHelper {

    public static final String ELEMENT_LINK_CONTENT_EXPLORER = "//a[contains(@class, 'ItemIcon DefaultPageIcon') and contains(., 'Content Explorer')]";
    public static final String ELEMENT_LINK_CONTENT_ADMINISTRATION = "//a[contains(@class, 'ItemIcon DefaultPageIcon') and contains(., 'Administration')]";
    public static final String ELEMENT_SELECT_ACCESS_MEMBERSHIP_ITEM = "//a[@class='ItemIcon' and @title='${membership}']";
    public static final String ELEMENT_SELECT_ACCESS_GROUP_ITEM = "//a[contains(@class, 'NodeIcon') and @title='${group}']";
    public static final String POPUP_LOCATOR_TEMPLATE = "//div[contains(@class,'UIPopupWindow') and "
            + ".//*[@class='PopupTitle' and .='{popupTitle}']]";
    public static final String LOCATOR = POPUP_LOCATOR_TEMPLATE.replace("{popupTitle}", "Page Editor");
    public static final String CONTENT_PORTLET = "//div[@class='PortletLayoutDecorator']//div[contains(.,'${portletName}')]";
    public static final String INFO_BAR_EDIT_ICON = "//div[contains(@class,'PortletIcon') and .='${portletName}']/..//a[contains(@title,'Edit Portlet')]";
    public static final String INFO_BAR_DELETE_ICON = "//div[contains(@class,'PortletIcon') and .='${portletName}']/..//a[contains(@title,'Delete Portlet')]";
    public static final String LOCATOR_ACTION = "//div[contains(@class,'UIAction')]";
    public static final String LOCATOR_DIV_TPL = LOCATOR_ACTION + "//div[@onclick and .//a[.='${buttonTitle}']]";
    public static final String LOCATOR_LINK_TPL1 = LOCATOR_ACTION + "//a[contains(@class,'ActionButton') and .//div[@onclick and contains(.,'${buttonTitle}')]]//div[@onclick]";
    public static final String LOCATOR_LINK_TPL2 = LOCATOR_ACTION + "//a[contains(@class,'ActionButton') and .//div[contains(.,'${buttonTitle}')]]";
    public static final String LOCATOR_LINK_TPL3 = LOCATOR_ACTION + "//a[contains(@class,'ActionButton') and contains(.,'${buttonTitle}')]";

    public static void waitForElementPresentAndClick(final String element) {
        setUp();
        waitForAndGetElement(element);
        click(element);
    }

    public static boolean isVisible(final String element) throws IOException {
        setUp();

        try {
            WebElement webElement = webDriver.findElement(By.xpath(element));
            return webElement.isDisplayed();
        } catch (NoSuchElementException e) {
            return false;
        }
    }

    public static void waitForElementVisible(final String element) throws IOException {
        setUp();
        new WebDriverWait(webDriver, 15).until(new ExpectedCondition() {

            @Override
            public Boolean apply(Object f) {
                try {
                    return isVisible(element);
                } catch (IOException ex) {
                    Logger.getLogger(WCMCommonHelper.class.getName()).log(Level.SEVERE, null, ex);
                    return false;
                }
            }
        });
    }

    public static void waitForElementNotVisible(final String element) throws IOException {
        setUp();
        new WebDriverWait(webDriver, 15).until(new ExpectedCondition() {

            @Override
            public Boolean apply(Object f) {
                try {
                    if (isVisible(element)) {
                        return false;
                    }
                } catch (IOException ex) {
                    Logger.getLogger(WCMCommonHelper.class.getName()).log(Level.SEVERE, null, ex);
                }
                return true;
            }
        });
    }

    public static String getConfirmation(boolean ok) throws IOException {
        setUp();
        trace("Wait for confirmation and click " + (ok ? "OK" : "Cancel") + "");
        Alert a = webDriver.switchTo().alert();
        if (ok) {
            a.accept();
        } else {
            a.dismiss();
        }

        String confirm = a.getText();
        trace(">" + confirm);
        return confirm;

    }
    //TODO
//    waitForElementPresentAndType

    public static void typeCKEditor(String locatorCKEditorIframe, String text) throws Exception {
        setUp();
        try {
            WebDriver w = webDriver.switchTo().frame(webDriver.findElement(By.xpath(locatorCKEditorIframe)));
            trace("type '" + text + "' into FCKEditor: " + locatorCKEditorIframe);
            ((JavascriptExecutor) w).executeScript("document.body.innerHTML = '" + text + "'");
            webDriver.switchTo().defaultContent();

        } catch (NoSuchFrameException e) {
            throw new Exception(e.getMessage(), e);
        }
    }

    public static void waitForElementPresentAndTypeCKEditor(String element, String value) throws Exception {
//        waitForElementPresent(element);
        waitForAndGetElement(element);
        typeCKEditor(element, value);
    }

    public static void waitForElementPresentAndType(String element, String value) {
//        waitForElementPresent(element);
        waitForAndGetElement(element);
        type(element, value, false);
    }

    public static void keyPressNativeOnElement(String element, String keyCode) throws IOException {
        trace("navive press key on element: " + element + " KEY_CODE=" + keyCode);

        WebElement queryText = webDriver.findElement(By.xpath(element));

        queryText.sendKeys(Keys.RETURN);
    }

    public static void clickButtonInElement(String locator,
            String buttonTitle,
            boolean waitForElementNotPresent) throws Exception {
        clickInElement(locator, buttonTitle, waitForElementNotPresent);
    }

    public static void clickInElement(String locator,
            String buttonTitle,
            boolean waitForElementNotPresent) throws Exception {

        debug("Click button '" + buttonTitle + "' in window");// '"+locatorWindow+"'");

        waitForAndGetElement(locator);

        String locatorButton = locator + LOCATOR_DIV_TPL.replace("${buttonTitle}", buttonTitle);
        if (isElementNotPresent(locatorButton)) {
            locatorButton = locator + LOCATOR_LINK_TPL1.replace("${buttonTitle}", buttonTitle);
        }
        if (isElementNotPresent(locatorButton)) {
            locatorButton = locator + LOCATOR_LINK_TPL2.replace("${buttonTitle}", buttonTitle);
        }
        if (isElementNotPresent(locatorButton)) {
            locatorButton = locator + LOCATOR_LINK_TPL3.replace("${buttonTitle}", buttonTitle);
        }
        //debug("Button locator: "+locatorButton+"");

        click(locatorButton);

        if (waitForElementNotPresent) {

            debug("waiting for element to disappear");

            waitForElementNotPresent(locator);

        }

    }

    public static void waitForOperationToFinish() throws Exception {
        pause(4000);
        // TODO verify this for 5.2
        waitForElementNotVisible("//div[@id='AjaxLoadingMask']");

    }

    public static void selectTabs(String horizontalTab, String verticalTab) throws Exception {

        waitForAndGetElement(LOCATOR);

        String locatorHTab = LOCATOR + "//div[@class='UIHorizontalTabs']"
                + "//div[@onclick and contains(.,'" + horizontalTab + "')]";
        waitForElementPresentAndClick(locatorHTab);

        String locatorVTab = LOCATOR + "//div[@class='UIVerticalSlideTabs']"
                + "//div[@onclick and .//a[@title='" + verticalTab + "']]";
        waitForElementPresentAndClick(locatorVTab);

    }

    public static void deleteContentPermissions(String name) throws IOException, Exception {
        ContentExplorer.ActionBar.addPermissions();
        waitForElementPresentAndClick("//div[contains(@title, '" + name + "')]/../..//img[contains(@class, 'DeleteIcon')]");
        getConfirmation(true);
        waitForElementPresentAndClick(AdministrationManagement.ADMIN_CLOSE_BUTTON);
    }

    public static void setContentPermissions(String user, String groupId, String membership, Boolean read, Boolean addNode, Boolean setProperty, Boolean remove) throws Exception {
        ContentExplorer.ActionBar.addPermissions();
        if (user != null) {
            waitForElementPresentAndClick("//img[contains(@class,'SelectUserIcon')]");
            waitForElementPresentAndClick("//table[contains(@id,'UIListUsers')]//div[@title='" + user + "']/../..//img[contains(@class,'SelectPageIcon')]");
            if (read) {
                check("//input[@class='checkbox' and @name='read']");
            }
            if (addNode) {
                check("//input[@class='checkbox' and @name='add_node']");
            }
            if (setProperty) {
                check("//input[@class='checkbox' and @name='set_property']");
            }
            if (remove) {
                check("//input[@class='checkbox' and @name='remove']");
            }

            waitForElementPresentAndClick(AdministrationManagement.SAVE_BUTTON);
            waitForElementPresentAndClick(AdministrationManagement.ADMIN_CLOSE_BUTTON);
        } else {
            waitForElementPresentAndClick("//img[contains(@class,'SelectMemberIcon')]");
            String membershipToSelect = ELEMENT_SELECT_ACCESS_MEMBERSHIP_ITEM.replace("${membership}", membership);
//		String selectedGroup = ELEMENT_SELECTED_ACCESS_PERM_GROUP.replace("${groupId}", groupId.replace(" ", "-").toLowerCase());
//		String selectedMembership = ELEMENT_SELECTED_ACCESS_PERM_MEMBERSHIP.replace("${membership}", membership);

            info("Setting view permission to " + groupId + ", " + membership);
            String[] groups = groupId.split("/");
            for (String group : groups) {
                String groupToSelect = ELEMENT_SELECT_ACCESS_GROUP_ITEM.replace("${group}", group);
                waitForElementPresentAndClick(groupToSelect);
            }
            waitForElementPresentAndClick(membershipToSelect);
            pause(3000);
            if (read) {
                check("//input[@class='checkbox' and @name='read']");
            }
            if (addNode) {
                check("//input[@class='checkbox' and @name='add_node']");
            }
            if (setProperty) {
                check("//input[@class='checkbox' and @name='set_property']");
            }
            if (remove) {
                check("//input[@class='checkbox' and @name='remove']");
            }
            waitForElementPresentAndClick(AdministrationManagement.SAVE_BUTTON);
            waitForElementPresentAndClick(AdministrationManagement.ADMIN_CLOSE_BUTTON);

        }
    }

    public static void editPortlet(String portletTitle) throws Exception {
//        mouseOverAndClick(CONTENT_PORTLET.replace("${portletName}", portletTitle), INFO_BAR_EDIT_ICON.replace("${portletName}", portletTitle));
        mouseOver(CONTENT_PORTLET.replace("${portletName}", portletTitle), false);
        click(INFO_BAR_EDIT_ICON.replace("${portletName}", portletTitle));
    }

    public static void deletePortlet(String portletTitle) throws IOException, Exception {
//        mouseOverAndClick(CONTENT_PORTLET.replace("${portletName}", portletTitle), INFO_BAR_DELETE_ICON.replace("${portletName}", portletTitle));
        mouseOver(CONTENT_PORTLET.replace("${portletName}", portletTitle), false);
        click(INFO_BAR_DELETE_ICON.replace("${portletName}", portletTitle));
        getConfirmation(true);
        waitForAndGetElement(LOCATOR);

        click(LOCATOR + "//a[@title='Finish']");

        waitForElementNotPresent(LOCATOR);
    }

    public static void signInVerified(String name, String pasword) {
        setUp();
        if (isElementPresent("//a[contains(@class, 'LogoutIcon')]")) {
            signOut();
        }
        signIn(name, pasword);
    }

    // backwards compatibility with EPP 5.1 URL scheme
    public static void goToPortal(String portalContainer, String portal, boolean privateMode) throws IOException {
        open(privateMode ? getPortalUrl().concat("/private/" + portal) : getPortalUrl().concat("/public/" + portal));
    }

    public static void goToACMEPortal() throws IOException {
        goToPortal("ecmdemo", "acme", false);
    }

    public static void goToACMEPortalPage(String page) throws IOException {
        open(getPortalUrl() + "/" + "acme" + "/" + page);
    }
}
