package org.jboss.gatein.selenium.wcm.content;

import static org.jboss.gatein.selenium.WCMCommonHelper.*;
import static org.jboss.gatein.selenium.common.CommonHelper.*;
import static org.jboss.gatein.selenium.testng.TestLogger.*;

/**
 *
 * @author Tomas Kyjovsky <tkyjovsk at redhat dot com>
 */
public class ContentSelector {

    public static final String LOCATOR_SINGLE_CONTENT_SELECTOR = POPUP_LOCATOR_TEMPLATE.replace("{popupTitle}","Single content selector panel");
    public static final String LOCATOR_MULTIPLE_CONTENT_SELECTOR = POPUP_LOCATOR_TEMPLATE.replace("{popupTitle}","Multiple Content Selector Pane");
    public static final String LOCATOR_FOLDER_SELECTOR = POPUP_LOCATOR_TEMPLATE.replace("{popupTitle}","Folder browser");
    public static String TAB_CONTENT_BROWSER = "//div[@onclick and .='Content browser']";
    public static String TAB_CONTENT_SEARCH = "//div[@onclick and .='Content search form']";
    public static String LEFT_WORKSPACE = "//div[contains(@class,'LeftWorkspace')]";
    public static String RIGHT_WORKSPACE = "//div[contains(@class,'RightWorkspace')]";
    public static final String GENERAL_DRIVES = "General Drives";

    public static void browseTree(String... path) throws Exception {

        debug("Content Selector: Browse tree path: " + path);
//        StringBuilder spc = new StringBuilder("");
//        for (String p : path) {
//            debug(" - " + spc + p);
//            spc.append(" ");
//        }

        String parentContainer = LEFT_WORKSPACE;

        for (String pathItem : path) {

            String itemLocator = parentContainer + "//div[contains(@class,'Node') and "
                    + ".//a[@title='" + pathItem + "']]";

            trace("  Click " + itemLocator);

            waitForElementPresentAndClick(itemLocator + "//a[@onclick]");

            parentContainer = itemLocator + "/following-sibling::*[1]"; // this should be //div[@class='ChildrenContainer']

        }

    }

    public static void selectItem(String itemName) throws Exception {

        debug("Content Selector: Select item " + itemName + " ");

//        if (itemName.length() < 15) {
            String locatorItem = RIGHT_WORKSPACE
                    + "//a[.='" + itemName + "']";
            waitForElementPresentAndClick(locatorItem);
//        } else {
//            String locatorItem = RIGHT_WORKSPACE
//                    + "//a[.='" + itemName.substring(0, 14) + "..." + "']";
//            waitForElementPresentAndClick(locatorItem);
//        }


    }

    public static void deleteItems() throws Exception {

        String locatorDeleteIcon = RIGHT_WORKSPACE
                + "//div[@class='DeleteIcon' and @onclick]";

        while (isElementPresent(locatorDeleteIcon)) {

            click(locatorDeleteIcon);

            pause(100);

        }

    }
}
