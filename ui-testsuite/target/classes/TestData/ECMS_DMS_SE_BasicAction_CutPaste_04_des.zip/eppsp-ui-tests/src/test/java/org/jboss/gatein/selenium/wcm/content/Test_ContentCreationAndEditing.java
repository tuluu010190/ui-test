package org.jboss.gatein.selenium.wcm.content;

import org.jboss.gatein.selenium.AbstractWCMTestCase;
import static org.jboss.gatein.selenium.testng.TestLogger.info;
import static org.jboss.gatein.selenium.WCMCommonHelper.*;

import org.jboss.gatein.selenium.wcm.content.ContentExplorer.ActionBar;
import org.jboss.gatein.selenium.wcm.content.ContentExplorer.ContentManagement;
import org.jboss.gatein.selenium.wcm.content.ContentExplorer.DocumentWorkspace;
import org.jboss.gatein.selenium.wcm.content.ContentExplorer.Navigation;
import static org.jboss.gatein.selenium.wcm.content.ContentExplorer.addItem;
import static org.jboss.gatein.selenium.wcm.content.ContentExplorer.goToTestFolder;
import org.jboss.gatein.selenium.wcm.content.type.*;
import org.testng.annotations.Test;

/**
 *
 *
 * @author Tomas Kyjovsky <tkyjovsk at redhat dot com>
 */
public class Test_ContentCreationAndEditing extends AbstractWCMTestCase {

    public void test_CRUD_ContentItem(Content document) throws Exception {
            
        goToACMEPortal();
        signInVerified("root", "gtn");
        goToPage("//div[contains(., 'Content Manager')]", new String[]{ELEMENT_LINK_GROUP, ELEMENT_LINK_CONTENT_EXPLORER});
        goToTestFolder(getTestName());

        // CREATE
        info("Create " + document);
        addItem(document);

        // READ
        info("Read " + document);
        DocumentWorkspace.verifyDisplayedContent(document);
        Navigation.browseUp();
        DocumentWorkspace.verifyItemPresent(document.getTitle());

        // UPDATE
        info("Update " + document);
        Navigation.browse(document.getTitle());

        if (document instanceof Folder) {
            // no updates for folder
        } else {
            ActionBar.editContent();
            document.updateContent(" - UPDATE" + generateTimeStampSuffix());
            DocumentWorkspace.fillUpdateForm(document);
            DocumentWorkspace.saveAndClose();
            DocumentWorkspace.verifyDisplayedContent(document);
        }
        Navigation.browseUp();

        // DELETE
        info("Delete " + document);
        ContentManagement.deleteItem(document.getTitle());
        DocumentWorkspace.verifyItemNotPresent(document.getTitle());
        signOut();

    }

    @Test(enabled=true)
    public void test_CRUD_File_Plain() throws Exception {
        test_CRUD_ContentItem(File.generateUnique());
    }

    @Test(enabled=true)
    public void test_CRUD_File_HTML() throws Exception {
        File file = File.generateUnique();
        file.setMimeType(File.MimeType.TEXT_HTML);
        test_CRUD_ContentItem(file);
    }

    @Test(enabled=true)
    public void test_CRUD_WebContent() throws Exception {
        test_CRUD_ContentItem(WebContent.generateUnique());
    }

    @Test(enabled=true)
    public void test_CRUD_Article() throws Exception {
        test_CRUD_ContentItem(Article.generateUnique());
    }

    @Test(enabled=true)
    public void test_CRUD_Folder() throws Exception {
        Folder folder = Folder.generateUnique();
        folder.getItems().add(new File("subitem1"));
        test_CRUD_ContentItem(folder);
    }
}
