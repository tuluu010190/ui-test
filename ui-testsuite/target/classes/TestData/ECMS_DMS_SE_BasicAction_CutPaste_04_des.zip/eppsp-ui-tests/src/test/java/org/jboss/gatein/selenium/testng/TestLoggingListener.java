package org.jboss.gatein.selenium.testng;

import org.apache.log4j.Level;
import org.testng.ITestResult;
import org.testng.TestListenerAdapter;

/**
 *
 * @author Tomas Kyjovsky <tkyjovsk at redhat dot com>
 */
public class TestLoggingListener extends TestListenerAdapter {

    private static void logStatus(ITestResult result) {
        Level level = Level.INFO;
        switch (result.getStatus()) {
            case ITestResult.FAILURE:
                level = Level.ERROR;
                break;
            case ITestResult.SKIP:
            case ITestResult.SUCCESS_PERCENTAGE_FAILURE:
                level = Level.WARN;
                break;
        }

        String message = TestInfo.getStatus(result).toUpperCase();
        TestLogger.log(result, message, level);
    }

    @Override
    public void onTestStart(ITestResult result) {
        logStatus(result);
    }

    @Override
    public void onTestFailure(ITestResult result) {
        logStatus(result);
    }

    @Override
    public void onTestSkipped(ITestResult result) {
        logStatus(result);
    }

    @Override
    public void onTestSuccess(ITestResult result) {
        logStatus(result);
    }

    @Override
    public void onTestFailedButWithinSuccessPercentage(ITestResult result) {
        logStatus(result);
    }
}
