package org.jboss.gatein.selenium.testng;

import org.apache.log4j.AppenderSkeleton;
import org.apache.log4j.Layout;
import org.apache.log4j.spi.LoggingEvent;
import org.testng.Reporter;

/**
 *
 * @author Tomas Kyjovsky <tkyjovsk at redhat dot com>
 */
public class ReportAppender extends AppenderSkeleton {

    public ReportAppender() {
    }

    public ReportAppender(Layout layout) {
        this.layout = layout;
    }

    @Override
    protected void append(LoggingEvent event) {
        Reporter.log(layout.format(event));
    }

    @Override
    public void close() {
    }

    @Override
    public boolean requiresLayout() {
        return true;
    }
}
