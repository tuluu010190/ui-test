package org.jboss.gatein.selenium.wcm.content.type;

import java.util.ArrayList;
import java.util.List;
import org.jboss.gatein.selenium.AbstractWCMTestCase;
import static org.jboss.gatein.selenium.WCMCommonHelper.*;
import static org.jboss.gatein.selenium.common.CommonHelper.type;
import org.jboss.gatein.selenium.wcm.content.ContentExplorer.DocumentWorkspace;
import org.jboss.gatein.selenium.wcm.content.ContentExplorer.Navigation;
/**
 *
 * @author Tomas Kyjovsky <tkyjovsk at redhat dot org>
 */
public final class Folder extends Content {

    public enum Type {

        CONTENT_FOLDER, DOCUMENT_FOLDER
    }
    public static final String CONTENT_TYPE_CONTENT_FOLDER = "nt:unstructured";
    public static final String CONTENT_TYPE_CONTENT_FOLDER_TITLE = "Content Folder";

    public static final String CONTENT_TYPE_DOCUMENT_FOLDER = "nt:folder";
    public static final String CONTENT_TYPE_DOCUMENT_FOLDER_TITLE = "Document Folder";

    @Override
    public String getContentType() {
        return getType().equals(Type.CONTENT_FOLDER) ? CONTENT_TYPE_CONTENT_FOLDER : CONTENT_TYPE_DOCUMENT_FOLDER;
    }
    
    @Override
    public String getContentTypeTitle() {
        return getType().equals(Type.CONTENT_FOLDER) ? CONTENT_TYPE_CONTENT_FOLDER_TITLE : CONTENT_TYPE_DOCUMENT_FOLDER_TITLE;
    }
    
    @Override
    public void fillCreateForm(String formLocator) throws Exception {
//        waitForElementPresentAndSelect(formLocator + "//select[@name='type']", "value=" + getJCRName());
        waitForAndGetElement(formLocator+"//input[@name='title']");
        type(formLocator+"//input[@name='title']", getName(), false);
        waitForAndGetElement(formLocator+"//input[@name='name']");
        type(formLocator+"//input[@name='name']", getName(), false);
    }

    @Override
    public void fillUpdateForm(String formLocator) throws Exception {
        // renaming is done in ContentExplorer.ContentManagement.renameItem()
    }

    @Override
    public void verifyDisplayedContent(String locator) throws Exception {
        if (locator.equals(DocumentWorkspace.LOCATOR)) {
            for (Content item : getItems()) {
                DocumentWorkspace.verifyItemPresent(item.getTitle());
                DocumentWorkspace.browse(item.getTitle());
                item.verifyDisplayedContent(locator);
                Navigation.browseUp();
            }
        }
    }

    @Override
    public void updateContent(String updateString) {
        // nothing to update for a folder
    }

    private Type type;
    private List<Content> items = new ArrayList<Content>();

    public Folder(String name) {
        this(Type.CONTENT_FOLDER, name);
    }
    
    public Folder(Type type, String name) {
        super(name);
        setType(type);
    }
    
    public Type getType() {
        return type;
    }

    public void setType(Type type) {
        this.type = type;
    }

    public static Folder generateUnique() {
        return new Folder("folder"+AbstractWCMTestCase.generateTimeStampSuffix());
    }
    
    public List<Content> getItems() {
        return items;
    }

    public void setItems(List<Content> items) {
        this.items = items;
    }

}
