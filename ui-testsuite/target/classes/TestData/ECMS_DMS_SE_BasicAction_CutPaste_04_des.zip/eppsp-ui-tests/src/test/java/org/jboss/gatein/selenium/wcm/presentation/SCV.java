package org.jboss.gatein.selenium.wcm.presentation;

import static org.jboss.gatein.selenium.wcm.content.ContentSelector.*;
import static org.jboss.gatein.selenium.WCMCommonHelper.*;
import static org.jboss.gatein.selenium.common.CommonHelper.*;
import static org.jboss.gatein.selenium.testng.TestLogger.*;

/**
 *
 * Convenience class for SingleContentViewer portlet.
 * 
 * @author Tomas Kyjovsky <tkyjovsk at redhat dot com>
 */
public class SCV {

    public static final String ICON_SELECT_CONTENT = "//img[contains(@onclick,'SelectFolderPath')]";
    public static final String LINK_ADVANCED = "//form[@id='UISCVPreferences']/child::a";

    public static final String SET_ENABLED  = "//div[contains(.,'Dynamic Navigation')]/..//input[@value='Enable']";
    public static final String SHOW_IN_PAGE  = "//td[contains(., 'Show in Page')]/..//img[contains(@class, 'AddIcon')]";

    public static void selectContent(String contentTitle) throws Exception {

        waitForElementPresentAndClick(ICON_SELECT_CONTENT);

        browseTree(GENERAL_DRIVES, "acme-category");

        selectItem(contentTitle);

    }
    
     public static void setAdvancedSCV() throws Exception {
        waitForElementPresentAndClick(LINK_ADVANCED);
        pause(3600);
        check(SET_ENABLED);
        pause(3600);
    }
    

    public static void checkSCVPresentWithContent(String portletTitle, String mainContentTitle) throws Exception {

        info("Check SCV portlet present with content");

        String locatorPortlet = "//div[contains(@class,'Title') and contains(.,'"+portletTitle+"')]";
        //String locatorContentTitle = locatorPortlet + "//div[@class='Title']";
        //waitForAndGetElement(locatorContentTitle);
        waitForAndGetElement(locatorPortlet);
      //  waitForAndGetElement("//p[contains(.,'"+mainContentTitle+"')]");
    }

    public static void checkSCVPresentWithDraft(String portletTitle, String mainContentEdited) throws Exception {

        info("Check SCV portlet present with draft");

        //String locatorPortlet = getLocatorByName(portletTitle);
       // String locatorDraftIcon = locatorPortlet + "//*[@class='DraftIcon']";

        waitForAndGetElement("//div[.='"+portletTitle+"']");
        //waitForAndGetElement("//p[contains(.,'"+mainContentEdited+"')]");

    }
}
