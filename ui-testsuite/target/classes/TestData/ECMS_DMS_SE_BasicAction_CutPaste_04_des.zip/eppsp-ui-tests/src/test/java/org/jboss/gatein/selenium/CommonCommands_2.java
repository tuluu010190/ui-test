///*
// * To change this template, choose Tools | Templates
// * and open the template in the editor.
// */
//package org.jboss.gatein.selenium;
//
////import com.thoughtworks.selenium.SeleniumException;
//import com.thoughtworks.selenium.Selenium;
//import java.io.IOException;
//import java.util.List;
//import java.util.logging.Level;
//import java.util.logging.Logger;
//import static org.jboss.gatein.selenium.testng.TestLogger.*;
//
//
//import org.openqa.selenium.Alert;
//import org.openqa.selenium.By;
//import org.openqa.selenium.JavascriptExecutor;
//import org.openqa.selenium.NoSuchElementException;
//import org.openqa.selenium.NoSuchFrameException;
//import org.openqa.selenium.WebDriver;
//import org.openqa.selenium.WebElement;
//import org.openqa.selenium.interactions.Action;
//import org.openqa.selenium.interactions.Actions;
//import org.openqa.selenium.support.ui.ExpectedCondition;
//import org.openqa.selenium.support.ui.Select;
//import org.openqa.selenium.support.ui.WebDriverWait;
//import org.testng.Assert;
//import org.openqa.selenium.Keys;
//import org.openqa.selenium.WebDriverBackedSelenium;
//
///**
// *
// * @author Tomas Kyjovsky <tkyjovsk at redhat dot org>
// */
//public class CommonCommands_2 extends PortalWebDriver_2.Context {
//
//    // static Wait wait = new WebDriverWait(getFirefoxDriver(), 15); 
//    public static void waitForElementNotPresent(final String element) throws IOException {
//        new WebDriverWait(getFirefoxDriver(), 15).until(new ExpectedCondition() {
//
//            @Override
//            public Boolean apply(Object f) {
//                try {
//                    try {
//                        getFirefoxDriver().findElement(By.xpath(element));
//                    } catch (IOException ex) {
//                        Logger.getLogger(CommonCommands_2.class.getName()).log(Level.SEVERE, null, ex);
//                    }
//                    return false;
//                } catch (NoSuchElementException e) {
//                    return true;
//                }
//            }
//        });
//    }
//
//// extended selenium functionality    
//    public static void waitForElementPresent(final String element) throws IOException {
//        new WebDriverWait(getFirefoxDriver(), 15).until(new ExpectedCondition() {
//
//            @Override
//            public Boolean apply(Object f) {
//                try {
//                    try {
//                        getFirefoxDriver().findElement(By.xpath(element));
//                    } catch (IOException ex) {
//                        Logger.getLogger(CommonCommands_2.class.getName()).log(Level.SEVERE, null, ex);
//                    }
//                    return true;
//                } catch (NoSuchElementException e) {
//                    return false;
//                }
//            }
//        });
//    }
//
//    public static void waitForElementVisible(final String element) throws IOException {
//        new WebDriverWait(getFirefoxDriver(), 15).until(new ExpectedCondition() {
//
//            @Override
//            public Boolean apply(Object f) {
//                try {
//                    return isVisible(element);
//                } catch (IOException ex) {
//                    Logger.getLogger(CommonCommands_2.class.getName()).log(Level.SEVERE, null, ex);
//                    return false;
//                }
//            }
//        });
//    }
//
//    public static void waitForElementNotVisible(final String element) throws IOException {
//        new WebDriverWait(getFirefoxDriver(), 15).until(new ExpectedCondition() {
//
//            @Override
//            public Boolean apply(Object f) {
//                try {
//                    if (isVisible(element)) {
//                        return false;
//                    }
//                } catch (IOException ex) {
//                    Logger.getLogger(CommonCommands_2.class.getName()).log(Level.SEVERE, null, ex);
//                }
//                return true;
//            }
//        });
//    }
//
//    public static void waitForTextPresent(final String text) throws Exception {
//        new WebDriverWait(getFirefoxDriver(), 15).until(new ExpectedCondition() {
//
//            @Override
//            public Boolean apply(Object f) {
//                try {
//                    if (isTextPresent(text)) {
//                        return true;
//                    }
//                } catch (IOException ex) {
//                    Logger.getLogger(CommonCommands_2.class.getName()).log(Level.SEVERE, null, ex);
//                }
//                Assert.fail("Timeout at waitForTextPresent: " + text);
//                return false;
//            }
//        });
//
//    }
//
//    public static void waitForTextNotPresent(final String text) throws Exception {
//        new WebDriverWait(getFirefoxDriver(), 15).until(new ExpectedCondition() {
//
//            @Override
//            public Boolean apply(Object f) {
//                try {
//                    if (!isTextPresent(text)) {
//                        return true;
//                    }
//                } catch (IOException ex) {
//                    Logger.getLogger(CommonCommands_2.class.getName()).log(Level.SEVERE, null, ex);
//                }
//                Assert.fail("Timeout at waitForTextPresent: " + text);
//                return false;
//            }
//        });
//
//    }
//
//    //probably wont work
//    //probably only text equation
//    public static void waitForConfirmation(final String confirmationText) throws IOException {
//        new WebDriverWait(getFirefoxDriver(), 15).until(new ExpectedCondition() {
//
//            @Override
//            public Boolean apply(Object f) {
//                Alert a = null;
//                try {
//                    a = getFirefoxDriver().switchTo().alert();
//                } catch (IOException ex) {
//                    Logger.getLogger(CommonCommands_2.class.getName()).log(Level.SEVERE, null, ex);
//                }
//                if (a.getText().equals(confirmationText)) {
//                    a.accept();
//                    return true;
//                } else {
//                    a.dismiss();
//                    Assert.fail("Timeout at waitForConfirmation: " + confirmationText);
//                    return true;
//                }
//            }
//        });
//    }
//
//    public static boolean isTextPresent(String text) throws IOException {
//        WebElement bodyElement = getFirefoxDriver().findElement(By.tagName("body"));
//        return bodyElement.getText().contains(text);
//    }
//
//    public static boolean isTextNotPresent(String text) throws Exception {
//        return !isTextPresent(text);
//    }
//
//    public static boolean isElementPresent(String element) throws Exception {
//        try {
//            getFirefoxDriver().findElement(By.xpath(element));
//            return true;
//        } catch (NoSuchElementException e) {
//            return false;
//        }
//    }
//
//    public static boolean isElementNotPresent(String element) throws Exception {
//        try {
//            getFirefoxDriver().findElement(By.xpath(element));
//            return false;
//        } catch (NoSuchElementException e) {
//            return true;
//        }
//    }
////    public static void waitForPageToLoad() {
////        (new WebDriverWait(getFirefoxDriver(), 10)).until(new ExpectedCondition<Boolean>() {
////
////            public Boolean apply(WebDriver d) {
////                return d.getTitle().toLowerCase().startsWith("cheese!");
////            }
//// 
//
//    public static void dragAndDropToObject(String source, String target) throws IOException {
//        trace("drag and drop: " + source + " --> " + target);
//        WebElement from = getFirefoxDriver().findElement(By.xpath(source));
//        WebElement to = getFirefoxDriver().findElement(By.xpath(target+"//div[@class='UIRowContainer']"));
//        Actions builder = new Actions(getFirefoxDriver());
//        Action dragAndDrop = builder.clickAndHold(from).moveToElement(to).release(to).build();
//        dragAndDrop.perform();
//        //to.click();
//
//    }
//
//
//    public static void invokeContextMenuOnElement(String element) throws IOException {
//        Actions actions = new Actions(getFirefoxDriver());
//        WebElement webElement = getFirefoxDriver().findElement(By.xpath(element));
//        actions.contextClick(webElement).perform();
//    }
//    
//
////
////    public static void doubleClickOnElement(String element) {
////        trace("doubleclick on element: " + element);
////        getSelenium().getEval("selenium.doComponentExoDoubleClick(\"" + element + "\")");
////    }
////
////    public static void keyPressOnElement(String element, String keySequence) {
////        trace("press key on element: " + element + " KEY=" + keySequence);
////        getSelenium().keyPress(element, keySequence);
////    }
////
//    public static void keyPressNativeOnElement(String element, String keyCode) throws IOException {
//        trace("navive press key on element: " + element + " KEY_CODE=" + keyCode);
//
//        WebElement queryText = getFirefoxDriver().findElement(By.xpath(element));
//
//        queryText.sendKeys(Keys.RETURN);
//    }
//
//    public static void mouseOverAndClick(String elementOver, String elementClick) throws IOException {
//
//        WebElement menu = getFirefoxDriver().findElement(By.xpath(elementOver));
//        WebElement menuOption = getFirefoxDriver().findElement(By.xpath(elementClick));
//        Actions builder = new Actions(getFirefoxDriver());
//        pause(500);
//        builder.moveToElement(menu).build().perform();
//        builder.moveToElement(menu).perform();
//        pause(1000);
//        menuOption.click(); 
//        pause(1000);
//    }
//    
//    public static void mouseOver(String element) throws IOException {
//        WebElement menu = getFirefoxDriver().findElement(By.xpath(element));
//        Actions builder = new Actions(getFirefoxDriver());
//        pause(500);
//        builder.moveToElement(menu).build().perform();
//    }
//
//    public static void open(String location) throws IOException {
//
//        info("open " + location);
//        info(getBaseUrl() + location);
//        getFirefoxDriver().get(getBaseUrl() + location);
//    }
////    
////    public static void openRelative(String location) {
////        open(getSelenium().getLocation()+location);
////    }
////
////    public static void click(String element) {
////        trace("click on: " + element);
////        getSelenium().click(element);
////    }
////
////    public static void type(String element, String value) {
////        trace("type '" + value + "' into element: " + element);
////        getSelenium().type(element, value);
////    }
////
//
//    public static void select(String element, String option) throws IOException {
//        WebElement selectElement = getFirefoxDriver().findElement(By.xpath(element));
//        Select select = new Select(selectElement);
//        List<WebElement> options = select.getOptions();
//        for (WebElement option1 : options) {
//            if (option1.getText().equals(option)) {
//                option1.click();
//                break;
//            }
//        }
//    }
//
//    public static void check(String element) throws IOException {
//        if (!getFirefoxDriver().findElement(By.xpath(element)).isSelected()) {
//            waitForElementPresentAndClick(element);
//        }
//    }
//
//    public static void uncheck(String element) throws IOException {
//        if (getFirefoxDriver().findElement(By.xpath(element)).isSelected()) {
//            getFirefoxDriver().findElement(By.xpath(element)).click();
//        }
//    }
//
//    public static void fireEvent(String element, String event) {
//        trace("fire event '" + event + "' on element: " + element);
//        // getSelenium().fireEvent(element, event);
//    }
//
//    public static void pause(long timeInMillis) {
//        try {
//            Thread.sleep(timeInMillis);
//        } catch (InterruptedException e) {
//            error(e.getMessage());
//        }
//    }
////
////    public static String getXpathCount(String element) {
////        return getSelenium().getXpathCount(element).toString();
////    }
////
////    public static boolean isChecked(String loc) {
////        return getSelenium().isChecked(loc);
////    }
////
////    public static String getValue(String locator) {
////        return getSelenium().getValue(locator);
////    }
////
////    public static String[] getAllSelectOptions(String locator) {
////
////        return getSelenium().getSelectOptions(locator);
////
////    }
////
////    public static String[] getSelectedValues(String locator) {
////        return getSelenium().getSelectedValues(locator);
////    }
////    
////    public static String getText(String locator) {
////        return getSelenium().getText(locator);
////    }
////    
////    
////    public static void selectWindow(String windowTitle) {
////        trace("select window: " + windowTitle);
////        getSelenium().selectWindow(windowTitle);
////        getSelenium().windowFocus();
////    }
////
////    public static void closeWindow(String windowTitle) {
////        trace("close window: " + windowTitle);
////        getSelenium().close();
////        selectWindow("");
////    }
////
//
//    public static void typeCKEditor(String locatorCKEditorIframe, String text) throws Exception {
//        try {
//            WebDriver w = getFirefoxDriver().switchTo().frame(getFirefoxDriver().findElement(By.xpath(locatorCKEditorIframe)));
//            String locBody = "//body";
//            trace("type '" + text + "' into FCKEditor: " + locatorCKEditorIframe);
//            waitForElementPresent(locBody);
//            ((JavascriptExecutor) w).executeScript("document.body.innerHTML = '" + text + "'");
//            getFirefoxDriver().switchTo().defaultContent();
//
//        } catch (NoSuchFrameException e) {
//            throw new Exception(e.getMessage(), e);
//        }
//    }
////
////    public static void refresh() {
////        trace("refresh page");
////        getSelenium().refresh();
////    }
////
//
//    public static boolean isVisible(final String element) throws IOException {
//
//        try {
//            WebElement webElement = getFirefoxDriver().findElement(By.xpath(element));
//            return webElement.isDisplayed();
//        } catch (NoSuchElementException e) {
//            return false;
//        }
//    }
////
////    public static void contextMenu(String locator) {
////        trace("invoke context menu: " + locator);
////        getSelenium().contextMenu(locator);
////    }
////
//
//    public static void waitForElementPresentAndClick(String element) throws IOException {
//        waitForElementPresent(element);
//        click(element);
//    }
//
//    public static void click(String element) throws IOException {
//        getFirefoxDriver().findElement(By.xpath(element)).click();
//    }
//
//    public static void type(String element, String text) throws IOException {
//        getFirefoxDriver().findElement(By.xpath(element)).sendKeys(text);
//    }
//
//    public static void doubleClickOnElement(String element) throws IOException {
//        WebElement webElement = getFirefoxDriver().findElement(By.xpath(element));
//        ((JavascriptExecutor) getFirefoxDriver()).executeScript("var evt = document.createEvent('MouseEvents');"
//                + "evt.initMouseEvent('dblclick',true, true, window, 0, 0, 0, 0, 0, false, false, false, false, 0,null);"
//                + "arguments[0].dispatchEvent(evt);", webElement);
//
//    }
//
////    public static void waitForElementPresentAndCheck(String element) throws Exception {
////        waitForElementPresent(element);
////        check(element);
////    }
////
//    public static void waitForElementPresentAndDblClick(String element) throws Exception {
//        waitForElementPresent(element);
//        doubleClickOnElement(element);
//    }
////
//
//    public static void waitForElementPresentAndType(String element, String value) throws IOException {
//        waitForElementPresent(element);
//        type(element, value);
//    }
////
//
//    public static void waitForElementPresentAndTypeCKEditor(String element, String value) throws Exception {
//        waitForElementPresent(element);
//        typeCKEditor(element, value);
//    }
//
//    public static void waitForElementPresentAndSelect(String element, String option) throws Exception {
//        waitForElementPresent(element);
//        select(element, option);
//    }
////
////    public static void waitForElementPresentAndMouseOver(String element) throws Exception {
////        waitForElementPresent(element);
////        mouseOver(element);
////    }
////
////    public static String getAlert() {
////        trace("get alert");
////        return getSelenium().getAlert();
////    }
////
////    public static void getConfirmation() {
////        trace("get confirmation");
////        getSelenium().getConfirmation();
////    }
//
//    public static String getConfirmation(boolean ok) throws IOException {
//        trace("Wait for confirmation and click " + (ok ? "OK" : "Cancel") + "");
//        Alert a = getFirefoxDriver().switchTo().alert();
//        if (ok) {
//            a.accept();
//        } else {
//            a.dismiss();
//        }
//
//        String confirm = a.getText();
//        trace(">" + confirm);
//        return confirm;
//    }
////    //    public static void waitWhileJQueryActive(int timeMax) throws InterruptedException {
//////
//////        boolean active = true;
//////        int interval = 100; // ms
//////        int timeLeft = timeMax;
//////        while (active && timeLeft > 0) {
//////            if ("true".equals(selenium.getEval("window.jQuery != null"))) {
//////                debug("TIME "+timeLeft);
//////                debug("active "+selenium.getEval("window.jQuery.active"));
//////                debug("isReady "+selenium.getEval("window.jQuery.isReady"));
//////            }
//////
//////            timeLeft -= interval;
//////            pause(interval);
//////        }
//////
//////    }
////    
////    
//}
