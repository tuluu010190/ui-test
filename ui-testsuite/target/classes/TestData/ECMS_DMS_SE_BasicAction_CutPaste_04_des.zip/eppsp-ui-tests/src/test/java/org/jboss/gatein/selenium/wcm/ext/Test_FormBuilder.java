package org.jboss.gatein.selenium.wcm.ext;

import org.jboss.gatein.selenium.AbstractWCMTestCase;
import static org.jboss.gatein.selenium.WCMCommonHelper.*;
import static org.jboss.gatein.selenium.common.CommonHelper.*;
import org.jboss.gatein.selenium.wcm.content.ContentExplorer.ActionBar;
import static org.jboss.gatein.selenium.wcm.ext.FormBuilder.addField;
import static org.jboss.gatein.selenium.wcm.ext.FormBuilder.editField;
import static org.testng.Assert.assertTrue;
import org.testng.annotations.Test;

/**
 * 
 * @author Tomas Kyjovsky <tkyjovsk at redhat dot com>
 */
public class Test_FormBuilder extends AbstractWCMTestCase {
    
    public static final String LOCATOR = POPUP_LOCATOR_TEMPLATE.replace("{popupTitle}","Messages");

    /**
     *
     * WCM_FG create new node type and dialog
     *
     * STEPS
     *
     * - Login acme by admin
     * - Select Groups/Form Generator
     * - Put value in General tab
     * - Next to Form builder tab:
     * Select some fields in the left panel to the right panel by click in field's name
     * - Click [Edit] icon of each field to set the properties
     * - Click [Save] button
     *
     * EXPECT
     *
     * New node type (template)  is created successfully.
     * This is in the template list when you add new document in Site Explorer
     *
     */
    @Test(enabled = true)
    public void test_FB_CreateNewNodeTypeAndDialog() throws Exception {

        goToACMEPortal();

        signInAsRoot();

        goToPage("//div[contains(., 'Form Builder')]", new String[]{"Group","Form Builder"} );

        waitForAndGetElement(FormBuilder.LOCATOR);

        String name = "FG_WCM"+generateTimeStampSuffix();

        waitForAndGetElement("//input[@id='FormGeneratorName']");
        type("//input[@id='FormGeneratorName']", name, false);

        waitForElementPresentAndClick("//div[@onclick and .='Form Builder']");

        // select some fields

        addField("input");

        editField("Input field", "INPUT", true, "", "GUIDELINES");

        addField("textarea");

        editField("Textarea field", "TEXTAREA", false, "", "GUIDELINES");

        addField("checkbox");

        editField("Checkbox field", "CHECKBOX", false, "", "GUIDELINES");

        clickButtonInElement(FormBuilder.LOCATOR, "Save", false); 
        
        pause(3600);
        
        waitForAndGetElement(LOCATOR+"//a[contains(@class,'ActionButton') and .='OK']");
        click(LOCATOR+"//a[contains(@class,'ActionButton') and .='OK']");
        
        pause(3600);
        
        goToPage("//div[contains(., 'Content Manager')]", new String[]{ELEMENT_LINK_GROUP, ELEMENT_LINK_CONTENT_EXPLORER});

        ActionBar.addContent();
        
        pause(3600);

        assertTrue(isElementPresent("//div[@id='UISelectDocumentForm']//a[.='"+name+"']"));
 
    }

}
