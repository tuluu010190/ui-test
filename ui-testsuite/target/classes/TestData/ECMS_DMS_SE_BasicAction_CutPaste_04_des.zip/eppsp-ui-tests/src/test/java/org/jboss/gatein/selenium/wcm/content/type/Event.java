package org.jboss.gatein.selenium.wcm.content.type;

/**
 *
 * @author Tomas Kyjovsky <tkyjovsk at redhat dot org>
 */
public class Event {
    public static final String JCR_NAME = "exo:event";
    // TODO
}
