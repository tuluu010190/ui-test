//package org.jboss.gatein.selenium.wcm.presentation;
//
//import org.jboss.gatein.selenium.PortalTest;
//import static org.testng.Assert.*;
//
//import static org.jboss.gatein.selenium.CommonCommands.*;
//import static org.jboss.gatein.selenium.portal.CommonWebUI.*;
//import static org.jboss.gatein.selenium.wcm.presentation.SCV.*;
//import static org.jboss.gatein.selenium.wcm.presentation.CLV.*;
//import static org.jboss.gatein.selenium.wcm.content.ContentSelector.*;
//import static org.jboss.gatein.selenium.portal.PageEditor.*;
//import static org.jboss.gatein.selenium.wcm.ECMDemo.*;
//import static org.jboss.gatein.selenium.portal.Page.*;
//
//import org.testng.annotations.Test;
//
///**
// *
// * @author Tomas Kyjovsky <tkyjovsk at redhat dot com>
// */
//public class Test_ContentListViewer extends PortalTest {
//
//    public static String[] newsTitles = new String[]{
//        "ACME News 1",
//        "ACME News 2",
//        "ACME News 3",
//        "ACME News 4",};
//    public static String[] newsNames = new String[]{
//        "News1",
//        "News2",
//        "News3",
//        "News4",};
//    public static String[] newsTitles321 = new String[]{
//        "ACME News 3",
//        "ACME News 2",
//        "ACME News 1",};
//    public static String[] newsNames321 = new String[]{
//        "News3",
//        "News2",
//        "News1",};
//    public static String[] acmeTopCategories = new String[]{
//        "Business",
//        "Sports",
//        "Technology",
//        "World",};
//    public static final String RADIO_BY_FOLDER = "//input[@name='UICLVConfigDisplayModeFormRadioBoxInput' and @value='AutoViewerMode']";
//    public static final String RADIO_BY_CONTENTS = "//input[@name='UICLVConfigDisplayModeFormRadioBoxInput' and @value='ManualViewerMode']";
//    public static final String SELECT_ORDER_BY = "//select[@name='UICLVConfigOrderByFormSelectBox']";
//    public static final String ORDER_BY_TITLE = "value=exo:title";
//    public static final String SELECT_TEMPLATE = "//select[@name='UICLVConfigDisplayTemplateFormSelectBox']";
//    public static final String TEMPLATE_CTG_TREE = "label=CategoryTree.gtmpl";
//    public static final String TEMPLATE_CTG_LIST = "label=CategoryList.gtmpl";
//    public static final String TEMPLATE_CLV_DEFAULT = "label=ContentListViewerDefault.gtmpl";
//
//    @Test
//    public static void test_CLV_ByFolder() throws Exception { // CLV
//
//        goToACMEPortal();
//
//        signIn("root", "gtn");
//
//        String title = "CLV_ByFolder" + generateTimeStampSuffix();
//
//        addNewPageWithEditor("Overview", title, title, null, null, null);
//        editPage();
//
//        dragAndDropPortletToPage("Contents", "Content List");
//
//        editPortlet("Content List");
//
//        waitForElementPresentAndClick("link=Advanced");
//
//        // check if CLV is pre-set as ContentList portlet
//        String locRadio_CtxNavEnabled = "//input[@name='UICLVConfigContextualFolderRadioBoxInput' and @value='contextualEnable']";
//        String locRadio_CtxNavDisabled = "//input[@name='UICLVConfigContextualFolderRadioBoxInput' and @value='contextualDisable']";
//        waitForAndGetElement(locRadio_CtxNavEnabled);
//        waitForAndGetElement(locRadio_CtxNavDisabled);
//
//        assertTrue(!isChecked(locRadio_CtxNavEnabled) && isChecked(locRadio_CtxNavDisabled));
//
//        // edit mode
//
//        waitForElementPresentAndCheck(RADIO_BY_FOLDER);
//
//        waitForElementPresentAndClick(ICON_SELECT_CONTENT);
//        browseTree(GENERAL_DRIVES);
//        selectItem("acme-category");
//
//        waitForElementPresentAndSelect(SELECT_ORDER_BY, ORDER_BY_TITLE); // publication:liveDate
//        waitForElementPresentAndCheck("//input[@name='UICLVConfigOrderTypeFormRadioBoxInput' and @value='" + OrderType.ASC + "']");
//
//        clickButtonInElement(MASK_WORKSPACE, "Save", false);
//
//        fillPortletSettingsForm(title);
//
//        finishEditing();
//
//        // check if content displayed
//        checkCLVDisplayedContents(title, newsTitles);
//
//    }
//
//    @Test
//    public static void test_CLV_ByContents() throws Exception { // CLV
//
//        goToACMEPortal();
//
//        signIn("root", "gtn");
//
//        String title = "CLV_ByCnts" + generateTimeStampSuffix();
//
//        addNewPageWithEditor("Overview", title, title, null, null, null);
//        editPage();
//
//        dragAndDropPortletToPage("Contents", "Content List");
//        editPortlet("Content List");
//
//        waitForElementPresentAndClick("link=Advanced");
//
//        // check if CLV is pre-set as ContentList portlet
//        String locRadio_CtxNavEnabled = "//input[@name='UICLVConfigContextualFolderRadioBoxInput' and @value='contextualEnable']";
//        String locRadio_CtxNavDisabled = "//input[@name='UICLVConfigContextualFolderRadioBoxInput' and @value='contextualDisable']";
//        waitForAndGetElement(locRadio_CtxNavEnabled);
//        waitForAndGetElement(locRadio_CtxNavDisabled);
//
//        assertTrue(!isChecked(locRadio_CtxNavEnabled) && isChecked(locRadio_CtxNavDisabled));
//
//        // edit mode
//        waitForElementPresentAndCheck(RADIO_BY_CONTENTS);
//
//        waitForElementPresentAndClick(ICON_SELECT_CONTENT);
//        browseTree(GENERAL_DRIVES, "acme-category");
//        for (String item : newsTitles321) {
//            selectItem(item);
//            pause(1000); //wait for the UI component to reload
//            //getAlert();
//        }
//        clickButtonInElement(LOCATOR_MULTIPLE_CONTENT_SELECTOR, "Save", true);
//        // check items in edit mode
//
////        waitForElementPresentAndSelect(SELECT_ORDER_BY, ORDER_BY_TITLE); // publication:liveDate
////        waitForElementPresentAndCheck("//input[@name='UICLVConfigOrderTypeFormRadioBoxInput' and @value='" + OrderType.ASC + "']");
//
//        clickButtonInElement(MASK_WORKSPACE, "Save", false);
//
//        fillPortletSettingsForm(title);
//
//        finishEditing();
//
//        // check if content displayed
//        checkCLVDisplayedContents(title, newsTitles321);
//
//    }
//
//    /**
//     *  TODO consider merging this case with CLV_ByFolder
//     *  or implementing a more general test case that would cover more display templates
//     */
//    @Test
//    public static void test_CLV_CategoryNavigationMode() throws Exception { // CN
//
//        goToACMEPortal();
//
//        signIn("root", "gtn");
//
//        String title = "CLV_CN" + generateTimeStampSuffix();
//
//        addNewPageWithEditor("Overview", title, title, null, null, null);
//        editPage();
//
//        dragAndDropPortletToPage("Contents", "Content List");
//
//        editPortlet("Content List");
//
//        waitForElementPresentAndClick("link=Advanced");
//
//        // check if CLV is pre-set as CN portlet
//        String locRadio_CtxNavEnabled = "//input[@name='UICLVConfigContextualFolderRadioBoxInput' and @value='contextualEnable']";
//        String locRadio_CtxNavDisabled = "//input[@name='UICLVConfigContextualFolderRadioBoxInput' and @value='contextualDisable']";
//        waitForAndGetElement(locRadio_CtxNavEnabled);
//        waitForAndGetElement(locRadio_CtxNavDisabled);
//
//        assertTrue(!isChecked(locRadio_CtxNavEnabled) && isChecked(locRadio_CtxNavDisabled));
//
//        // edit mode
//        waitForElementPresentAndCheck(RADIO_BY_FOLDER);
//
//        waitForElementPresentAndClick(ICON_SELECT_CONTENT);
//        browseTree(GENERAL_DRIVES);
//        selectItem("acme-category");
//
////        waitForElementPresentAndSelect(SELECT_ORDER_BY, ORDER_BY_TITLE); // publication:liveDate
////        waitForElementPresentAndCheck("//input[@name='UICLVConfigOrderTypeFormRadioBoxInput' and @value='" + OrderType.ASC + "']");
//        waitForElementPresentAndSelect(SELECT_TEMPLATE, TEMPLATE_CTG_TREE);
//
//        clickButtonInElement(MASK_WORKSPACE, "Save", false);
//
//        fillPortletSettingsForm(title);
//
//        finishEditing();
//
//        // check if content displayed
//        checkCLVDisplayedCategories(title, acmeTopCategories);
//
//    }
//
//    @Test
//    public static void test_CLV_CategoryContentsMode() throws Exception { // PCLV
//
//        goToACMEPortal();
//
//        signIn("root", "gtn");
//
//        String title = "CLV_CCtns" + generateTimeStampSuffix();
//
//        addNewPageWithEditor("Overview", title, title, null, null, null);
//        editPage();
//
//        dragAndDropPortletToPage("Contents", "Content List");
//
//        editPortlet("Content List");
//
//        waitForElementPresentAndClick("link=Advanced");
//
//        // check if CLV is pre-set as CN portlet
//        String locRadio_CtxNavEnabled = "//input[@name='UICLVConfigContextualFolderRadioBoxInput' and @value='contextualEnable']";
//        String locRadio_CtxNavDisabled = "//input[@name='UICLVConfigContextualFolderRadioBoxInput' and @value='contextualDisable']";
//        waitForAndGetElement(locRadio_CtxNavEnabled);
//        waitForAndGetElement(locRadio_CtxNavDisabled);
//
//        assertTrue(!isChecked(locRadio_CtxNavEnabled)
//                && isChecked(locRadio_CtxNavDisabled));
//
//        // edit mode
//        // enable ctx navigation
//        check(locRadio_CtxNavEnabled);
//
//        waitForElementPresentAndCheck(RADIO_BY_FOLDER);
//
//        waitForElementPresentAndClick(ICON_SELECT_CONTENT);
//        browseTree(GENERAL_DRIVES);
//        selectItem("acme-category");
//
////        waitForElementPresentAndSelect(SELECT_ORDER_BY, ORDER_BY_TITLE); // publication:liveDate
////        waitForElementPresentAndCheck("//input[@name='UICLVConfigOrderTypeFormRadioBoxInput' and @value='" + OrderType.ASC + "']");
//        waitForElementPresentAndSelect(SELECT_TEMPLATE, TEMPLATE_CLV_DEFAULT);
//
//        clickButtonInElement(MASK_WORKSPACE, "Save", false);
//
//        fillPortletSettingsForm(title);
//
//        finishEditing();
//
//        // check if category content displayed
//        checkCLVDisplayedContents(title, newsTitles);
//
//        // provide URL param and check if applied
//        openRelative("?folder-id=repository:collaboration:/sites content/live/classic/categories/classic/World");
//        checkCLVDisplayedContents(title, new String[]{newsTitles[0]});
//
//    }
//}
