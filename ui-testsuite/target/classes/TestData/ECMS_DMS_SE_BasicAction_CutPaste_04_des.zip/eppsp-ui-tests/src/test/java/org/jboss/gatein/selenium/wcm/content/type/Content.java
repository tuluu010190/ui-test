package org.jboss.gatein.selenium.wcm.content.type;

import org.jboss.gatein.selenium.AbstractWCMTestCase;

/**
 *
 * @author Tomas Kyjovsky <tkyjovsk at redhat dot org>
 */
public abstract class Content {

    public static final String INPUT_NAME = "//input[@name='name']";
    public static final String INPUT_TITLE = "//input[@name='title']";

    public abstract String getContentType();
    public abstract String getContentTypeTitle();

    public abstract void fillCreateForm(String formLocator) throws Exception;

    public abstract void fillUpdateForm(String formLocator) throws Exception;

    public abstract void verifyDisplayedContent(String locator) throws Exception;

    public abstract void updateContent(String updateString);
    private String name;
    private String title = null;

    public Content(String name) {
        this.name = name;
    }

    @Override
    public String toString() {
        return getName();
    }

    //Selenium
//    public String generateName() {
//        return this.getClass().getSimpleName().toLowerCase() + PortalTest.generateTimeStampSuffix();
//    }

    public String generateName() {
        return this.getClass().getSimpleName().toLowerCase() + AbstractWCMTestCase.generateTimeStampSuffix();
    }
    
    public String getName() {
        return name;
    }

    public final void setName(String name) {
        this.name = name;
    }

    public String getTitle() {
        // if empty defaults to name
        return title == null ? getName() : title;
    }

    public void setTitle(String title) {
        this.title = title;
    }
}
