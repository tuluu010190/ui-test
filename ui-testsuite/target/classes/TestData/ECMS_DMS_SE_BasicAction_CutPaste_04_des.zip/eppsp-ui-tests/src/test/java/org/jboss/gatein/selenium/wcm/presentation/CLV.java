package org.jboss.gatein.selenium.wcm.presentation;

import static org.jboss.gatein.selenium.WCMCommonHelper.*;
import static org.jboss.gatein.selenium.common.CommonHelper.*;
import static org.jboss.gatein.selenium.testng.TestLogger.debug;
import static org.jboss.gatein.selenium.testng.TestLogger.info;
import static org.jboss.gatein.selenium.wcm.content.ContentSelector.*;
import static org.testng.Assert.assertTrue;

/**
 * 
 * Convenience class for ContentListViewer portlet.
 * 
 * @author Tomas Kyjovsky <tkyjovsk at redhat dot com>
 */
public class CLV {

    public static String POPUP_CLV_CONFIG = "//div[@id='UICLVPortlet']";

    public static String PORTLET_CLV_TEMPLATE = "//div[contains(@class,'UICLVPortlet') and .//div[contains(@class,'TitleBar') and .='${title}']]";
    
    public static final String ICON_SELECT_CONTENT = "//img[contains(@onclick,'SelectFolderPath')]";
    public static final String LINK_ADVANCED = "//div[contains(@class,'FormContainer')]/child::a";

    public static final String SET_ENABLED  = "//div[contains(.,'Dynamic Navigation')]/..//input[@value='contextualEnable']";
    public static final String SHOW_IN_PAGE  = "//td[contains(., 'Show in Page')]/..//img[contains(@class, 'AddIcon')]";

    public static enum Mode {

        BY_FOLDER,
        BY_CONTENTS
    }

    public static enum OrderType {
        DESC,
        ASC
    }
    
    public static void selectContentFile(String contentTitle, Boolean advanced, String page) throws Exception {

        waitForElementPresentAndClick(ICON_SELECT_CONTENT);

        browseTree(GENERAL_DRIVES, "Sites Management","acme", "web contents");

        selectItem(contentTitle);
info("Selected cnotent");
    }
    
    
    public static void setAdvanced(String page) throws Exception {
        waitForElementPresentAndClick(LINK_ADVANCED);
        pause(3600);
        check(SET_ENABLED);
        waitForElementPresentAndClick(SHOW_IN_PAGE);
        waitForElementPresentAndClick("//div[@class='HomeNode']//a[@title='Up Level']");
        pause(3600);
        waitForElementPresentAndClick("//table[@class='UIGrid']//tbody/tr[3]//a//div");
 //       waitForElementPresentAndClick("//div[@id='UIPageSelectorPanel']//tr[.//div[.='"+page+"')]]//div[contains(@class, 'Select16x16Icon')]");
        
        pause(3600);
    }
    
    
    
    
//    
//    public static void addContentItems(String folderTitle, String[] items, String timestamp) throws Exception {
//
//        info("Add content items for CLV portlet");
//
//        goToPage("//div[contains(., 'Content Manager')]", new String[]{ELEMENT_LINK_GROUP, ELEMENT_LINK_CONTENT_EXPLORER});
//
//        openDrive(DRIVE_SITES_MANAGEMENT);
//
//        SideBar.FileExplorer.browse("acme-category", "web contents");
//
//        addFolder(FolderType.DOCUMENT, folderTitle);
//
//        DocumentWorkspace.dblClickItem(folderTitle);
//
//        for (String item : items) {
//
//            item = item + "_" + timestamp;
//            
//            addWebContent("exo:webContent", item);
//            
//        }
//
//    }


//    public static void removeContentItems(String folderTitle) throws Exception {
//
//        goToPage("//div[contains(., 'Content Manager')]", new String[]{ELEMENT_LINK_GROUP, ELEMENT_LINK_CONTENT_EXPLORER});
//
//        openDrive(DRIVE_SITES_MANAGEMENT);
//
//        SideBar.FileExplorer.browse("acme-category", "web contents");
//
//        deleteItemInFileExplorer(folderTitle);
//
//    }

    public static void checkCLVDisplayedContents(String portletTitle, String[] items) throws Exception {

        info("Check content items displayed by CLV portlet");

        String locPortlet = "//div[@id='UIPage']//div[@id='UICLVPortlet']";
        waitForAndGetElement(locPortlet); pause(100);

        for (String item : items) {
            assertTrue(isElementPresent(locPortlet + "//div[contains(.,'" + item + "')]"));
        }
        
    }
    
    public static void checkCLVDisplayedContentsPublished(String portletTitle, String[] items) throws Exception {

        info("Check content items displayed by CLV portlet");

        String locPortlet = "//div[@id='UIPage']//div[@id='UICLVPortlet']";
        waitForAndGetElement(locPortlet); 
        pause(1000);

        for (String item : items) {
            assertTrue(isElementPresent(locPortlet + "//p[contains(.,'" + item + "')]"));
        }
        
    }
    
    public static void checkCLVDisplayedEvents(String portletTitle, String[] items) throws Exception {

        info("Check content items displayed by CLV portlet");

        String locPortlet = "//div[@id='UIPage']//div[@id='UICLVPortlet']";
        waitForAndGetElement(locPortlet); pause(100);

        for (String item : items) {
            assertTrue(isElementPresent(locPortlet + "//a[contains(.,'" + item + "')]"));
        }
        
    }

    public static void checkCLVDisplayedCategories(String portletTitle, String[] items) throws Exception {

        info("Check categories displayed by CLV portlet");

        String locPortlet = "//div[@id='UIPage']//div[@id='UICLVPortlet']";//getLocatorByName(portletTitle);
        waitForAndGetElement(locPortlet); pause(100);
        
        for (String item : items) {

            String locItem = "//a[@class='CategoryLabel' " +
                    "and contains(@href,'"+item+"') " +
                    "and contains(@href,'folder-id')]";

            assertTrue(isElementPresent(locPortlet + locItem));
        }

    }

    public static String getCLVPortletLocatorByHeader(String header) {

        return PORTLET_CLV_TEMPLATE.replace("${title}", header);

    }

    //  ordering 

    public static String ITEM_TITLE_TEMPLATE = "//a[contains(@class,'TitleContent') and .='${itemTitle}']";
    public static String ITEM_TEMPLATE = "//div[@class='HotNews' or @class='NormalNews' and ."+ITEM_TITLE_TEMPLATE+"]";

    public static void checkOrderingOfItems(String [] items) throws Exception {

        String locatorItem = null;

        info("Check ordering of news items");
        for (String item : items) {

            if (locatorItem == null) {
                locatorItem = ITEM_TEMPLATE.replace("${itemTitle}", item);
            } else {
                locatorItem += "/following-sibling::div[1]";
            }

            String locItemTitle = locatorItem + ITEM_TITLE_TEMPLATE.replace("${itemTitle}", item);

            //debug("item title locator: "+locItemTitle);
            waitForAndGetElement(locItemTitle);

        }

    }

    public static void checkDisplayedItem(String item) throws Exception {

        debug("Click news item");
        String locatorItem = (ITEM_TEMPLATE + ITEM_TITLE_TEMPLATE)
                .replace("${itemTitle}", item);

        waitForElementPresentAndClick(locatorItem);

        debug("Check displayed news item");
        String locatorPCVPortlet = "//div[@id='UIPCVPortlet']//div[@class='Title' and .='"+item+"']";
        waitForAndGetElement(locatorPCVPortlet);

    }




}
