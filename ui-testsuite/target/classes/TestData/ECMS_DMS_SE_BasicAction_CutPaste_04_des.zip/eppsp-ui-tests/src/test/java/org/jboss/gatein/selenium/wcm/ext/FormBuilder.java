package org.jboss.gatein.selenium.wcm.ext;

//import static org.jboss.gatein.selenium.CommonCommands.*;
import java.io.IOException;
import static org.jboss.gatein.selenium.WCMCommonHelper.*;
import static org.jboss.gatein.selenium.common.CommonHelper.*;
import static org.jboss.gatein.selenium.testng.TestLogger.*;

/**
 *
 * @author Tomas Kyjovsky <tkyjovsk at redhat dot com>
 */
public class FormBuilder {

    public static String LOCATOR = "//div[@id='UIFormGeneratorPortlet']";

    public static void addField(String elementType) throws IOException {

        waitForElementPresentAndClick("//div[@elementtype='" + elementType + "']");

    }

    public static void editField(String fieldLabel,
        String label, boolean required, String defaultValue, String guidelines) throws Exception {

        String locField = LOCATOR + "//div[@class='BoxContentBoxStyle' and "
                + ".//*[@class='FieldLabel']]";

        String locIconEdit = locField + "//a[contains(@class,'EditIcon')]";

        waitForAndGetElement(locField);

        click(locIconEdit);

        String locInputRequired = locField + "//tr[./td[.='Width']]//div[@class='BoxRules']//input";
        if (required) {
            check(locInputRequired);
        } else {
     //       uncheck(locInputRequired);
        }

        String locInputDfltValue = locField + "//tr[./td[.='Default Value']]//input";
        waitForElementPresentAndType(locInputDfltValue, defaultValue);

        String locInputGuidelines = locField + "//tr[./td[.='Guidelines for User']]//textarea";
        waitForElementPresentAndType(locInputGuidelines, guidelines);

        String locInputLabel = locField + "//tr[./td[.='Field Label']]//input";

        waitForAndGetElement(locInputLabel);
        type(locInputLabel, label, false);

        String locFieldNewName = LOCATOR + "//div[@class='BoxContentBoxStyle' and "
                + ".//*[@class='FieldLabel' and .='" + label + "']]//a[contains(@class,'EditIcon')]";
        waitForElementPresentAndClick(locFieldNewName);
    }
}
