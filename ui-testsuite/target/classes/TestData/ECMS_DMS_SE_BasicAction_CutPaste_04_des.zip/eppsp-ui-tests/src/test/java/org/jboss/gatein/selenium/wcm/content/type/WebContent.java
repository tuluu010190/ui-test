package org.jboss.gatein.selenium.wcm.content.type;


import org.jboss.gatein.selenium.AbstractWCMTestCase;
import org.jboss.gatein.selenium.wcm.content.CKEditor;
import static org.jboss.gatein.selenium.WCMCommonHelper.*;
import static org.jboss.gatein.selenium.common.CommonHelper.*;
import static org.jboss.gatein.selenium.testng.TestLogger.*;
import static org.testng.Assert.*;

/**
 *
 * @author Tomas Kyjovsky <tkyjovsk at redhat dot org>
 */
public class WebContent extends Content {

    public static final String CONTENT_TYPE = "exo:webContent";
    public static final String CONTENT_TYPE_TITLE = "Free layout webcontent";
    public static final String CKE_MAIN_CONTENT = CKEditor.LOCATOR_TEMPLATE.replace("{name}", "Main Content");
    public static final String CKE_SUMMARY = CKEditor.LOCATOR_TEMPLATE.replace("{name}", "Summary");
    public static final String TAB_TEMPLATE = "//div[contains(@class,'UITab') and .//div[@onclick and contains(.,'${tabTitle}')]]";
    //public static final String TAB_TEMPLATE = "//div[contains(@class,'UITab')]//div[@onclick and .='${tabTitle}']]";
    public static final String TAB_MAIN_CONTENT = TAB_TEMPLATE.replace("${tabTitle}", "Main Content");
    //public static final String TAB_ILLUSTRATION = "//div[@class='TabsContainer']//div[@class='UITab NormalTabStyle'][2]//div[.='Illustration']";
    public static final String TAB_ILLUSTRATION = "//div[contains(@class, 'UITab')]//div[contains(@class, 'MiddleTab') and contains(., 'Illustration')]";
    public static final String TAB_ADVANCED = "//div[contains(@class, 'UITab')]//div[contains(@class, 'MiddleTab') and contains(., 'Advanced')]";
    private String mainContent;
    private String summary;
    private String cssData;
    private String jsData;

    @Override
    public String getContentType() {
        return CONTENT_TYPE;
    }
    @Override
    public String getContentTypeTitle() {
        return CONTENT_TYPE_TITLE;
    }

    @Override
    public void fillCreateForm(String formLocator) throws Exception {
        debug("Fill-in form / Web content / Main Content tab");
        waitForElementPresentAndClick(formLocator + TAB_MAIN_CONTENT);    
        waitForAndGetElement(formLocator + INPUT_TITLE);
        type(formLocator + INPUT_TITLE, getTitle(), false);
        waitForAndGetElement(formLocator + INPUT_NAME);
        type(formLocator + INPUT_NAME, getName(), false);
        fillUpdateForm(formLocator);
    }

    @Override
    public void fillUpdateForm(String formLocator) throws Exception {
        debug("Fill-in form / Web content / Main Content tab");
     //   waitForElementPresentAndType(formLocator + INPUT_TITLE, getTitle());
        pause(3600);
        waitForElementPresentAndClick(formLocator + TAB_MAIN_CONTENT);
        waitForElementPresentAndTypeCKEditor(formLocator + CKE_MAIN_CONTENT, mainContent);
       // waitForElementPresentAndTypeCKEditor(formLocator + "//tr[.//td[contains(@class, 'FieldLabel') and contains(., 'Main Content')]]//textarea", mainContent);
        pause(3600);
        pause(1000);
        fillFormIllustration(formLocator, summary);
        pause(1000);
        fillFormAdvanced(formLocator, cssData, jsData);
    }
    
    public static void fillFormIllustration(String formLocator, String summary) throws Exception {
        debug("Fill-in form / Web content / Advanced tab");
        waitForElementPresentAndClick(formLocator +TAB_ILLUSTRATION);
        pause(3600);
        waitForElementPresentAndTypeCKEditor(formLocator + CKE_SUMMARY, summary);
       // String locatorTextAreaSumm = formLocator + "//textarea[contains(@name,'ContentJS')]";
       // waitForElementPresentAndType(locatorTextAreaSumm, cssData);        
    }

    // TODO
    public static void fillFormAdvanced(String formLocator, String cssData, String jsData) throws Exception {
        debug("Fill-in form / Web content / Advanced tab");
        waitForElementPresentAndClick(formLocator + TAB_ADVANCED);        
        String locatorTextAreaCSS = formLocator + "//textarea[contains(@name,'ContentCSS')]";
        String locatorTextAreaJS = formLocator + "//textarea[contains(@name,'ContentJS')]";
        pause(3600);
        waitForAndGetElement(locatorTextAreaCSS);
        type(locatorTextAreaCSS, cssData, false);
        waitForAndGetElement(locatorTextAreaJS);
        type(locatorTextAreaJS, jsData, false);
    }

//    @Override
//    public void verifyDisplayedContent(String locator) throws Exception {
//        info("verify content");
//        waitForAndGetElement(locator);
//        assertTrue(isElementPresent(locator + "//div[contains(.,'" + mainContent + "')]"));
//    }

    @Override
    public void verifyDisplayedContent(String locator) throws Exception {
        info("verify content");
        waitForAndGetElement(locator);
        assertTrue(isElementPresent("//div[contains(@id,'UITreeExplorer')]//a[contains(@title,'"+getTitle()+"')]"));
    }
    
    @Override
    public void updateContent(String updateString) {
        setMainContent("main content of " + getName() + updateString);
        setSummary("summary of " + getName() + updateString);
        setCssData("// css data of " + getName() + updateString);
        setJsData("// JS data of " + getName() + updateString);
    }
    
    public String getMainContent() {
        return mainContent;
    }

    public void setMainContent(String mainContent) {
        this.mainContent = mainContent;
    }

    public String getSummary() {
        return summary;
    }

    public void setSummary(String summary) {
        this.summary = summary;
    }

    public String getCssData() {
        return cssData;
    }

    public void setCssData(String cssData) {
        this.cssData = cssData;
    }

    public String getJsData() {
        return jsData;
    }

    public void setJsData(String jsData) {
        this.jsData = jsData;
    }

    public WebContent(String name) {
        this(name, "-", "-", "", "");
    }

    public WebContent(String name, String mainContent, String summary, String cssData, String jsData) {
        super(name);
        this.mainContent = mainContent;
        this.summary = summary;
        this.cssData = cssData;
        this.jsData = jsData;
    }

//    public static WebContent generateUnique() {
//        WebContent webContent = new WebContent("webcontent"+PortalTest.generateTimeStampSuffix());
//        webContent.updateContent("");
//        return webContent;
//    }
    
    public static WebContent generateUnique() {
        WebContent webContent = new WebContent("webcontent"+AbstractWCMTestCase.generateTimeStampSuffix());
        webContent.updateContent("");
        return webContent;
    }

}
