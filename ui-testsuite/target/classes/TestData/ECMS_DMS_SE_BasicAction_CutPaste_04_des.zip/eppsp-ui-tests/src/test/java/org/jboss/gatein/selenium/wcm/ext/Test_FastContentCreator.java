package org.jboss.gatein.selenium.wcm.ext;

//import org.jboss.gatein.selenium.PortalTest;
import java.text.SimpleDateFormat;
import java.util.Date;
import org.jboss.gatein.selenium.AbstractWCMTestCase;
import static org.jboss.gatein.selenium.WCMCommonHelper.*;
import static org.jboss.gatein.selenium.common.CommonHelper.*;
import static org.jboss.gatein.selenium.page.PageHelper.*;
import static org.jboss.gatein.selenium.testng.TestLogger.info;
import static org.jboss.gatein.selenium.wcm.content.ContentExplorer.DRIVE_SITES_MANAGEMENT;
import org.jboss.gatein.selenium.wcm.content.ContentExplorer.DocumentWorkspace;
import org.jboss.gatein.selenium.wcm.content.ContentExplorer.Navigation;
import org.jboss.gatein.selenium.wcm.content.ContentExplorer.SideBar;
import static org.testng.Assert.assertTrue;
import org.testng.annotations.Test;

/**
 *
 * @author Tomas Kyjovsky <tkyjovsk at redhat dot com>
 */
public class Test_FastContentCreator extends AbstractWCMTestCase {
    
    public static final String EDIT_PORTLET_SAVE = "//div[@class='HorizontalLayout']//a[.='Save']";
    public static final String EDIT_PORTLET_CLOSE = "//div[@class='HorizontalLayout']//a[.='Close']";

    /**
     * FIXME Test_FastContentCreator
     * @throws Exception 
     */
    @Test(groups={"broken"}, enabled=true)
    public static void test_SNF_WCM_26_CreateNewDocumentAndConfigurePortlet() throws Exception {

        goToACMEPortal();
        signInAsRoot();
        pause(3600);
        goToACMEPortalPage("contactus");

        goToEditPage();;

        editPortlet("Contact Us");

        String title = "SNF_WCM_26" + generateTimeStampSuffix();

        //waitForAndGetElement(MASK_WORKSPACE);

        waitForAndGetElement("//input[@id='UIFCCSaveFormStringInput']");
        type("//input[@id='UIFCCSaveFormStringInput']", "Save_" + title, false);

        waitForAndGetElement("//textarea[@id='UIFCCMessageFormTextareaInput']");
        type("//textarea[@id='UIFCCMessageFormTextareaInput']", title + "_CUSTOM_MESSAGE", false);

//        clickButtonInElement(MASK_WORKSPACE, "Save", false);
//
//        clickButtonInElement(MASK_WORKSPACE, "Close", false);

        
        info("Finish page edit");

        waitForAndGetElement(EDIT_PORTLET_SAVE);

        click(EDIT_PORTLET_SAVE);

        pause(3600);

        waitForElementPresentAndClick("//a[contains(@class,'ActionButton') and .='OK']");

        waitForAndGetElement(EDIT_PORTLET_CLOSE);

        click(EDIT_PORTLET_CLOSE);

        finishPageEdit();

        waitForAndGetElement("//input[@id='your_nameFieldName']");
        type("//input[@id='your_nameFieldName']", title, false);
        waitForAndGetElement("//textarea[@id='your_messageFieldName']");
        type("//textarea[@id='your_messageFieldName']", title, false);

        clickButtonInElement("//div[@id='UIFCCPortlet']", "Save", false);

        SimpleDateFormat sdf = new SimpleDateFormat("yyyy.MM.dd - hh'h'mm'm'");

        String docTitle = sdf.format(new Date());

        waitForAndGetElement("//div[@class='Title' and .='Contact Form Confirmation']");

        info("Check if custom message present");

//        waitForAndGetElement("//div[@class='WebContentContainer' and contains(.,'"+title+"')]");

        goToPage("//div[contains(., 'Content Manager')]", new String[]{ELEMENT_LINK_GROUP, ELEMENT_LINK_CONTENT_EXPLORER});

        Navigation.openDrive(DRIVE_SITES_MANAGEMENT);

        SideBar.FileExplorer.browse("acme", "documents");

        waitForAndGetElement(DocumentWorkspace.LOCATOR);

        String locDoc = DocumentWorkspace.LOCATOR + "//div[contains(.,'"+docTitle+"')]";

        //debug(""+locDoc+"");

        assertTrue(isElementPresent(locDoc));
    }
}
