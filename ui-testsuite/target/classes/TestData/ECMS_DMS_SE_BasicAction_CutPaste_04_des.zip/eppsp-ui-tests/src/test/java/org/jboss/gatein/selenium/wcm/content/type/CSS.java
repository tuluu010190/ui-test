package org.jboss.gatein.selenium.wcm.content.type;

/**
 *
 * @author Tomas Kyjovsky <tkyjovsk at redhat dot org>
 */
public class CSS  {
    public static final String JCR_NAME = "exo:css";

    // TODO
    
//    public static void fillNewForm(String locatorForm, String name, String active, String priority, String cssData) throws Exception {
//        debug("Fill-in form / CSS");
//        String locatorInputName = locatorForm + "//input[@name='name']";
//        String locatorSelectActive = locatorForm + "//select[@name='activeCSS']";
//        String locatorInputPriority = locatorForm + "//input[@name='CSSpriority']";
//        String locatorTextAreaCSSData = locatorForm + "//textarea[@name='contentHtml']";
//        waitForElementPresentAndType(locatorInputName, name);
//        waitForElementPresentAndType(locatorSelectActive, active);
//        waitForElementPresentAndType(locatorInputPriority, priority);
//        waitForElementPresentAndType(locatorTextAreaCSSData, cssData);
//    }
    
}
