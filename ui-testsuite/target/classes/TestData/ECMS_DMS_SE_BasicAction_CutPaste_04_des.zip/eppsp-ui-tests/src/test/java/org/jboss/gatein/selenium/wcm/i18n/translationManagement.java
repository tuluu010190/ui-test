/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package org.jboss.gatein.selenium.wcm.i18n;

import static org.jboss.gatein.selenium.WCMCommonHelper.*;
import static org.jboss.gatein.selenium.common.CommonHelper.pause;
import org.jboss.gatein.selenium.wcm.content.ContentExplorer.ActionBar;
import org.jboss.gatein.selenium.wcm.content.ContentExplorer.TreeExplorerWorkspace;
import static org.jboss.gatein.selenium.wcm.content.ContentExplorer.addItem;
import static org.jboss.gatein.selenium.wcm.content.ContentExplorer.goToACMECategoryFolder;
import static org.jboss.gatein.selenium.wcm.content.ContentSelector.browseTree;
import static org.jboss.gatein.selenium.wcm.content.ContentSelector.selectItem;
import org.jboss.gatein.selenium.wcm.content.type.Article;

/**
 *
 * @author mgottval
 */
public class translationManagement {

    public static final String PATH_NODE_ADD_ITEM = POPUP_LOCATOR_TEMPLATE.replace("{popupTitle}","Symlink Manager") + "//img[@title='Add Item']";
    public static final String SAVE_BUTTON = POPUP_LOCATOR_TEMPLATE.replace("{popupTitle}","Symlink Manager") + "//a[.='Save']";

    public static void addTranslatedContent(String title) throws Exception {

        goToACMECategoryFolder();

        addItem(new Article(title, "Summary of " + title, "Main content of " + title));

        goToACMECategoryFolder();
        //DocumentWorkspace.browse("acme", "categories", "acme");        

        addItem(new Article(title + " cs", "Summary of " + title + "cs", "Main content of " + title + "cs"));

        //       goToACMECategoryFolder();
        //DocumentWorkspace.browse("acme", "categories", "acme");

        TreeExplorerWorkspace.clickItem(title);

        // TreeExplorerWorkspace.clickItem("ACME News 2");
        ActionBar.addTranslation(); // ?? in contentExplorer

        waitForElementPresentAndClick(PATH_NODE_ADD_ITEM);
        pause(2600);
//        browseTree("General Drives","acme-category");
//        selectItem(title+" cs");
        waitForElementPresentAndClick("//a[contains(@class,'Item default16x16Icon exo_article16x16Icon') and contains(@title,'" + title + " cs')]");
        // waitForElementPresentAndClick("//a[contains(@class,'Item default16x16Icon exo_webContent16x16Icon') and contains(.,'ACME News 1')]");
        pause(2600);
        waitForElementPresentAndClick(SAVE_BUTTON);

    }

    public static void selectTranslatedContent(boolean symlink, String title) throws Exception {
        if (symlink) {
            waitForElementPresentAndClick("//div[@id='BreadcumbsContainer']//a[.='General Drives']");
            browseTree("General Drives", "acme-category");
            selectItem(title);
        } else {
            waitForElementPresentAndClick("//a[contains(@class,'Item default16x16Icon exo_article16x16Icon') and contains(@title,'" + title +"')]");
        }
    }
}
