//package org.jboss.gatein.selenium.wcm.issues;
//
//import static org.jboss.gatein.selenium.CommonCommands.*;
//import static org.jboss.gatein.selenium.portal.CommonWebUI.*;
//import org.jboss.gatein.selenium.PortalTest;
//import org.testng.annotations.Test;
//import org.jboss.gatein.selenium.portal.PopupWindow;
//import org.jboss.gatein.selenium.wcm.content.ContentExplorer;
//import org.jboss.gatein.selenium.wcm.content.Publication;
//import static org.jboss.gatein.selenium.wcm.ECMDemo.*;
//import static org.jboss.gatein.selenium.wcm.content.ContentExplorer.*;
//import static org.testng.Assert.*;
//
///**
// *
// * @author Tomas Kyjovsky <tkyjovsk at redhat dot com>
// */
//public class Test_SPREDHAT34 extends PortalTest {
//
//    /**
//     * FIXME test_SPREDHAT34
//     * https://jira.exoplatform.org/browse/SPREDHAT-34
//     * 
//     * @throws Exception 
//     */
//    @Test(groups={"broken"}, enabled=false)
//    public static void test_SPREDHAT34() throws Exception {
//
//        goToACMEPortal();
//        signIn("root", "gtn");
//        open("news");
//        Publication.switchPortalToEditMode();
//
//        waitForElementPresent("link=ACME News 1");
//        mouseOver("link=ACME News 1");
//        pause(1000);
//
//        click("//a[contains(@href,'News1') and @title='Edit']");
//        waitForPageToLoad();
//        waitForElementPresent("//table[@class='cke_editor']");
//
//        info("save");
//        clickButtonInElement(DocumentWorkspace.LOCATOR, "Save as Draft", false);
//        pause(3000);
//        waitForElementNotVisible(PopupWindow.POPUP_LOADING);
//
//        // request approval
//        info("request approval");
//        ContentExplorer.ActionBar.invokeAction("Publication", "Request Approval");
//        pause(2000);
//        waitForElementPresent("//table[@class='cke_editor']");
//        pause(2000);
//
//        // assert no error message
//        debug("assert no error");
//        assertFalse(isElementPresent("//div[@class='PopupMessage' and contains(.,'Unknown error')]"));
//
//        // approve content
//        info("approve content");
//        ContentExplorer.ActionBar.invokeAction("Publication", "Approve Content");
//        pause(2000);
//        waitForElementPresent("//table[@class='cke_editor']");
//        pause(2000);
//
//        // assert no error message
//        debug("assert no error");
//        assertFalse(isElementPresent("//div[@class='PopupMessage' and contains(.,'Unknown error')]"));
//
//        // publish
//        info("publish");
//        ContentExplorer.ActionBar.invokeAction("Publication", "Publish");
//        pause(2000);
//        waitForElementPresent("//table[@class='cke_editor']");
//        pause(2000);
//
//        // assert no error message
//        debug("assert no error");
//        assertFalse(isElementPresent("//div[@class='PopupMessage' and contains(.,'Unknown error')]"));
//
//    }
//}
