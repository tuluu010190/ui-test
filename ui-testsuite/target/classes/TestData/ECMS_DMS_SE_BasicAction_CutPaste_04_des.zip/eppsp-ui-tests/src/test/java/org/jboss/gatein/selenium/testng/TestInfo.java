package org.jboss.gatein.selenium.testng;

import java.util.Collections;
import java.util.Map;
import java.util.TreeMap;
import org.testng.ITestResult;

/**
 *
 * @author Tomas Kyjovsky <tkyjovsk at redhat dot com>
 */
public class TestInfo {

    public static final Map<Integer, String> STATUSES = Collections.unmodifiableMap(new TreeMap<Integer, String>() {

        private static final long serialVersionUID = 1L;

        {
            put(ITestResult.FAILURE, "Failure");
            put(ITestResult.SKIP, "Skip");
            put(ITestResult.STARTED, "Started");
            put(ITestResult.SUCCESS, "Success");
            put(ITestResult.SUCCESS_PERCENTAGE_FAILURE, "FailurePercentage");
        }
    });

    public static Class getTestClass(ITestResult result) {
        Class c = null;
        if (result != null) {
            c = result.getTestClass().getRealClass();
        }
        return c;
    }

    public static String getTestMethod(ITestResult result) {
        String m = "";
        if (result != null) {
            m = result.getMethod().getMethodName();
        }
        return m;
    }

    public static String getStatus(ITestResult result) {
        String s = "";
        if (result != null) {
            s = STATUSES.get(result.getStatus());
        }
        return s;
    }

    public static String getParameters(ITestResult result) {
        StringBuilder parameters = new StringBuilder("");
        if (result != null) {
            if (result.getParameters() != null && result.getParameters().length != 0) {
                parameters.append("(");
                for (int i = 0; i < result.getParameters().length; i++) {
                    parameters.append("\"");
                    parameters.append(result.getParameters()[i]);
                    parameters.append(i == result.getParameters().length - 1 ? "\"" : "\", ");
                }
                parameters.append(")");
            }
        }
        return parameters.toString();
    }
}
