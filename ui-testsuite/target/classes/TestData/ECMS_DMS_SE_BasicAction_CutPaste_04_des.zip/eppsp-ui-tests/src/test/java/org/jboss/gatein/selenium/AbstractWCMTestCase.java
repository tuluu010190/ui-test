/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package org.jboss.gatein.selenium;

import java.util.Date;

/**
 *
 * @author mgottval
 */
public class AbstractWCMTestCase extends AbstractTestCase {
    
    private static final String testName = "test" + generateTimeStampSuffix();
    
    
    
    
    
    
    
     public static String generateTimeStamp() {
        return String.valueOf(new Date().getTime());
    }

    public static String generateTimeStampSuffix() {
        return "_" + generateTimeStamp();
    }

    public String getTestName() {
        return testName;
    }
    
}
