/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package org.jboss.gatein.selenium.wcm.presentation;

import org.jboss.gatein.selenium.AbstractWCMTestCase;
import static org.jboss.gatein.selenium.WCMCommonHelper.*;
import static org.jboss.gatein.selenium.common.CommonHelper.*;
import static org.jboss.gatein.selenium.page.PageHelper.*;
import static org.jboss.gatein.selenium.wcm.content.Publication.addCLVPortletWithContent;
import static org.jboss.gatein.selenium.wcm.content.Publication.addSCVPortletWithContent;
import static org.jboss.gatein.selenium.wcm.presentation.CLV.checkCLVDisplayedContents;
import static org.testng.Assert.assertFalse;
import static org.testng.Assert.assertTrue;
import org.testng.annotations.Test;
/**
 *
 * @author mgottval
 */
public class Test_ContentPortletView extends AbstractWCMTestCase {

    String[] listPublished = {"ACME Event 1",
        "ACME Event 2",
        "ACME Event 3",
        "ACME Event 4"};
//
//    @Test(enabled = false)
//    public void test_ContentPortletCLVContent() throws Exception {
//
//        goToACMEPortal();
//
//        signInVerified("root", "gtn");
//
////        deleteAllPortlets("events");
//
//        addCLVPortletWithContent("Events", false, "events");
//
//        pause(4600);
//
//        checkCLVDisplayedContents("a", listPublished);
//        
////        Page.editPage();
//        goToEditPage();
//        
//        deletePortlet("Content List");
//        
//    }
//
//    @Test(enabled = false)
//    public void test_ContentPortletSCVContent() throws Exception {
//
//        goToACMEPortal();
//
//        signInAsRoot();
//
////        deleteAllPortlets("events");
//
//        addSCVPortletWithContent("ACME News 1", false, "events");
//
//        pause(4600);
//
//        assertTrue(isElementPresent("//div[@class='Title' and .='ACME News 1']"));
//        
//        //        Page.editPage();
//        goToEditPage();
//        
//        deletePortlet("Content Detail");
//           
//    }

    @Test(enabled = true)
    public void test_ContentPortletCLVToSCVView() throws Exception {

        goToACMEPortal();

        signInAsRoot();

//        deleteAllPortlets("events");

        addCLVPortletWithContent("Events", true, "events");

        addSCVPortletWithContent("ACME News 1", true, "events");

        waitForElementPresentAndClick("//div[@id='UIPage']//div[contains(@id,'UICLVPortlet')]//a[contains(.,'ACME Event 4')]/../..//a[contains(.,'Read more')]");

        assertTrue(isElementPresent("//div[@class='Title' and .='ACME Event 4']"));

        assertFalse(isElementPresent("//div[@class='Title' and .='ACME News 1']"));
        
       //        Page.editPage();
        goToEditPage();
        
        deletePortlet("Content Detail");
        
        pause(4600);
        
//        deletePortlet("Content List");
                       
    }
}
