/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package org.jboss.gatein.selenium.wcm.wcmadministration;

//import org.jboss.gatein.selenium.PortalTest;
import org.jboss.gatein.selenium.AbstractWCMTestCase;
import static org.jboss.gatein.selenium.WCMCommonHelper.*;
import static org.jboss.gatein.selenium.common.CommonHelper.*;
import static org.jboss.gatein.selenium.wcm.wcmadministration.EditView.addTranslationIntoWcmView;
import static org.testng.Assert.assertTrue;
import org.testng.annotations.Test;

/**
 *
 * @author mgottval
 */
public class Test_EditView extends AbstractWCMTestCase {
    
    public static final String PUBLICATION_TAB = "//div[@id='UIWorkingArea']//div[@id='UIActionBar']//div[@class='UITab']//a[.='Publication']";
   
    @Test(enabled=true)
    public void test_addTranslationIntoWcm() throws Exception{
    
    goToACMEPortal();
        
    signInAsRoot();
        
    goToPage("//div[contains(., 'Manage ECM Main Functions')]", new String[]{ELEMENT_LINK_GROUP, ELEMENT_LINK_CONTENT_ADMINISTRATION});
        
    addTranslationIntoWcmView("WCM View");
        
    goToPage("//div[contains(., 'Content Manager')]", new String[]{ELEMENT_LINK_GROUP, ELEMENT_LINK_CONTENT_EXPLORER});
    pause(3600);
    waitForElementPresentAndClick(PUBLICATION_TAB);
    pause(4600);
    assertTrue(isElementPresent("//a[@title='Add Translation']"));  
    
    }
    
}
