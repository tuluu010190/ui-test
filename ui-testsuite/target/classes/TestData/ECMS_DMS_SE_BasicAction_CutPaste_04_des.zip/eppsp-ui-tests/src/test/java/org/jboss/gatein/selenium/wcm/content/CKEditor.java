package org.jboss.gatein.selenium.wcm.content;

import org.jboss.gatein.selenium.AbstractWCMTestCase;


/**
 *
 * @author Tomas Kyjovsky <tkyjovsk at redhat dot com>
 */
public class CKEditor extends AbstractWCMTestCase {

    public static final String LOCATOR_TEMPLATE = "//tr[.//td[contains(@class, 'FieldLabel') and contains(., '{name}')]]//iframe";
    
    public static String ICON_INSERT_CONTENTS = "//div[@title='Insert contents' and .//img[@src]]";
    
    public static String TITLE_CONTENT_SELECTOR_WINDOW = "FCKEditor Plugins eXo Utils";

}
