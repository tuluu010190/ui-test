package org.jboss.gatein.selenium.wcm.content.type;


import org.jboss.gatein.selenium.AbstractWCMTestCase;
import static org.jboss.gatein.selenium.WCMCommonHelper.*;
import static org.jboss.gatein.selenium.common.CommonHelper.*;
import static org.testng.Assert.*;

import org.jboss.gatein.selenium.wcm.content.CKEditor;

/**
 *
 * @author Tomas Kyjovsky <tkyjovsk at redhat dot org>
 */
public class File extends Content {

    public static final String CONTENT_TYPE = "nt:file";
    public static final String CONTENT_TYPE_TITLE = "File";
    
    public static final String SELECT_MIMETYPE = "//select[@name='mimetype']";
    public static final String TEXTAREA_CONTENT = "//textarea[contains(@name, 'content')]";
    public static final String CKE_CONTENT = CKEditor.LOCATOR_TEMPLATE.replace("{name}", "Content");

    @Override
    public String getContentType() {
        return CONTENT_TYPE;
    }
    
    @Override
    public String getContentTypeTitle() {
        return CONTENT_TYPE_TITLE;
    }
    
    @Override
    public void fillCreateForm(String formLocator) throws Exception {
        waitForElementPresentAndType(INPUT_NAME, getName());
        waitForElementPresentAndClick(SELECT_MIMETYPE);
      //  waitForElementPresentAndSelect(SELECT_MIMETYPE, mimeType);
        waitForAndGetElement(SELECT_MIMETYPE);
        select(SELECT_MIMETYPE, mimeType);
        waitForOperationToFinish();
        fillUpdateForm(formLocator);
    }

    @Override
    public void fillUpdateForm(String formLocator) throws Exception {
        if (MimeType.TEXT_PLAIN.equals(mimeType)) {
            waitForElementPresentAndType(formLocator + TEXTAREA_CONTENT, content);
        } else {
            waitForElementPresentAndTypeCKEditor(formLocator + CKE_CONTENT, content);
        }
        // update metadata
        // TODO
    }
    
    @Override
    public void verifyDisplayedContent(String locator) throws Exception {
        assertTrue(isElementPresent(locator + "//div[@class='Content' and contains(.,'"+getContent()+"')]"));
    }

    @Override
    public final void updateContent(String updateString) {
        setContent("content of "+getName()+updateString);
    }

    private String content;
    private String mimeType;
    private Metadata metadata;

    public File(String name) {
        this(name, MimeType.TEXT_PLAIN, "-");
    }
    
    public File(String name, String mimeType, String content) {
        this(name, mimeType, content, null);
        setMetadata(new Metadata(null, null, null, null));
    }
    
    public File(String name, String mimeType, String content, Metadata metadata) {
        super(name);
        this.mimeType = mimeType;
        this.content = content;
        this.metadata = metadata;
    }
    
    public static File generateUnique() {
        File file = new File("file"+AbstractWCMTestCase.generateTimeStampSuffix());
        file.updateContent("");
        return file;
    }
    
    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getMimeType() {
        return mimeType;
    }

    public final void setMimeType(String mimeType) {
        this.mimeType = mimeType;
    }

    public Metadata getMetadata() {
        return metadata;
    }

    public void setMetadata(Metadata metadata) {
        this.metadata = metadata;
    }

    public class Metadata {

        private String[] title;
        private String[] description;
        private String[] creator;
        private String[] source;

        public Metadata(String[] title, String[] description, String[] creator, String[] source) {
            this.title = title;
            this.description = description;
            this.creator = creator;
            this.source = source;
        }
        
        public String[] getTitle() {
            return title;
        }

        public void setTitle(String[] title) {
            this.title = title;
        }

        public String[] getDescription() {
            return description;
        }

        public void setDescription(String[] description) {
            this.description = description;
        }

        public String[] getCreator() {
            return creator;
        }

        public void setCreator(String[] creator) {
            this.creator = creator;
        }

        public String[] getSource() {
            return source;
        }

        public void setSource(String[] source) {
            this.source = source;
        }
    }

    public class MimeType {

        public static final String TEXT_PLAIN = "text/plain";
        public static final String TEXT_HTML = "text/html";
        public static final String APPLICATION_GROOVY = "application/x-groovy+html";
    }

}
