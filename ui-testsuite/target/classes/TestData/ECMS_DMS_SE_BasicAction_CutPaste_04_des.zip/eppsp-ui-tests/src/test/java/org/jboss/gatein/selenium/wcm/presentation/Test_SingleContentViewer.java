//package org.jboss.gatein.selenium.wcm.presentation;
//
//import org.jboss.gatein.selenium.PortalTest;
//import org.testng.annotations.Test;
//
//import static org.testng.Assert.*;
//
//import static org.jboss.gatein.selenium.CommonCommands.*;
//import static org.jboss.gatein.selenium.portal.CommonWebUI.*;
//import static org.jboss.gatein.selenium.wcm.presentation.SCV.*;
//import static org.jboss.gatein.selenium.wcm.content.ContentSelector.*;
//import static org.jboss.gatein.selenium.wcm.ECMDemo.*;
//import static org.jboss.gatein.selenium.portal.PageEditor.*;
//import static org.jboss.gatein.selenium.portal.Page.*;
//
///**
// * 
// * SCV = Single Content Viewer (portlet)
// *
// * @author Tomas Kyjovsky <tkyjovsk at redhat dot com>
// */
//public class Test_SingleContentViewer extends PortalTest {
//
//
//    @Test
//    public static void test_SCV_ContentDetailMode() throws Exception {
//
//        goToACMEPortal();
//
//        signIn("root", "gtn");
//
//        String title = "SCV_CDMode" + generateTimeStampSuffix();
//
//        addNewPageWithEditor("Overview", title, title, null, null, null);
//        editPage();
//
//        dragAndDropPortletToPage("Contents", "Content Detail");
//
//        editPortlet("Content Detail");
//
//        waitForElementPresentAndClick("link=Advanced");
//
//        // check if SCV is pre-set as ContentDetail portlet
//        String locRadio_CtxNavEnabled = "//input[@name='UISCVContextualRadioBox' and @value='Enable']";
//        String locRadio_CtxNavDisabled = "//input[@name='UISCVContextualRadioBox' and @value='Disable']";
//        waitForAndGetElement(locRadio_CtxNavEnabled);
//        waitForAndGetElement(locRadio_CtxNavDisabled);
//
//        assertTrue(!isChecked(locRadio_CtxNavEnabled) && isChecked(locRadio_CtxNavDisabled));
//
//        // select content
//        waitForElementPresentAndClick(ICON_SELECT_CONTENT);
//        browseTree(GENERAL_DRIVES, "acme-category");
//        selectItem("ACME News 1");
//        clickButtonInElement(MASK_WORKSPACE, "Save", false);
//        
//        fillPortletSettingsForm(title);
//
//        finishEditing();
//
//        // check if content displayed
//        checkSCVPresentWithContent(title, "ACME News 1");
//
//    }
//
//    @Test
//    public static void test_SCV_ContentByURLMode() throws Exception {
//
//        goToACMEPortal();
//
//        signIn("root", "gtn");
//
//        String title = "SCV_CbURLMode" + generateTimeStampSuffix();
//
//        addNewPageWithEditor("Overview", title, title, null, null, null);
//        editPage();
//
//        dragAndDropPortletToPage("Contents", "Content by URL");
//
//        editPortlet("Content by URL");
//
//        //waitForElementPresentAndClick("link=Advanced"); // open by default in ContentByURL edit mode
//
//        // check if SCV is pre-set as ContentByURL portlet
//        String locRadio_CtxNavEnabled = "//input[@name='UISCVContextualRadioBox' and @value='Enable']";
//        String locRadio_CtxNavDisabled = "//input[@name='UISCVContextualRadioBox' and @value='Disable']";
//        waitForAndGetElement(locRadio_CtxNavEnabled);
//        waitForAndGetElement(locRadio_CtxNavDisabled);
//
//        assertTrue(isChecked(locRadio_CtxNavEnabled) && !isChecked(locRadio_CtxNavDisabled));
//
//        // select default content
//        waitForElementPresentAndClick(ICON_SELECT_CONTENT);
//        browseTree(GENERAL_DRIVES, "acme-category");
//        selectItem("ACME News 1");
//        clickButtonInElement(MASK_WORKSPACE, "Save", false);
//
//        fillPortletSettingsForm(title);
//
//        finishEditing();
//
//        // check if default content displayed
//        checkSCVPresentWithContent(title, "ACME News 1");
//
//        // provide URL param
//        openRelative("?content-id=/repository/collaboration/sites content/live/classic/web contents/News/News2");
//        checkSCVPresentWithContent(title, "ACME News 2");
//
//    }
//    
//}
