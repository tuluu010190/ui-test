//package org.jboss.gatein.selenium.wcm.issues;
//
//import org.jboss.gatein.selenium.PortalTest;
//import org.jboss.gatein.selenium.wcm.content.ContentSelector;
//import org.jboss.gatein.selenium.wcm.content.Publication;
//import org.jboss.gatein.selenium.wcm.content.type.WebContent;
//import org.testng.annotations.Test;
//import static org.jboss.gatein.selenium.CommonCommands.*;
//import static org.jboss.gatein.selenium.wcm.ECMDemo.*;
//import static org.jboss.gatein.selenium.wcm.content.ContentExplorer.*;
//import static org.testng.Assert.*;
//
///**
// *
// * @author Tomas Kyjovsky <tkyjovsk at redhat dot com>
// */
//public class Test_SPREDHAT35 extends PortalTest {
//
//    public static final String LIPSUM = "Lorem ipsum dolor sit amet, consectetur adipiscing elit. In hendrerit, mauris eget iaculis molestie, tortor lectus volutpat libero, eleifend rhoncus orci metus ut eros. Nulla lacus risus, hendrerit eget feugiat ac, mollis in ante. Donec vitae enim vel tellus molestie blandit quis dictum sem. Etiam non vestibulum magna. Sed viverra nunc id mauris euismod et viverra urna ultrices. Sed mattis tincidunt vulputate. Aliquam semper lacinia scelerisque. Vivamus vel turpis quis odio euismod dapibus vitae non leo. Sed vulputate dolor sed tortor congue gravida eu sed velit. Proin a elit augue. Maecenas nec quam nisl. Integer ut orci nec ante condimentum eleifend. Nunc tincidunt tempor euismod. Nullam aliquam viverra fermentum. Aliquam eget felis nibh, et ornare ante. Nullam sed enim neque, a accumsan nunc. Nulla iaculis metus at nunc euismod at egestas mi condimentum. Maecenas vel tellus sed quam iaculis sagittis. Praesent id massa elit, sit amet tristique nunc. Aenean eget tortor nec est scelerisque fermentum.";
//    
//    /**
//     * 
//     * https://jira.exoplatform.org/browse/SPREDHAT-35
//     * 
//     * @throws Exception 
//     */
//    @Test
//    public static void test_SPREDHAT35() throws Exception {
//
//        String title = "SPREDHAT35"+generateTimeStampSuffix();
//        WebContent webContent = new WebContent(title);
//        webContent.setMainContent(LIPSUM);
//        String[] path = {"sites content", "live", "acme-category", "web contents"};
//        String image = "DocumentContentIcon.gif";
//        String[] imagePath = {ContentSelector.GENERAL_DRIVES, "Managed Sites", 
//            "acme-category", "medias", "images", "GlobalImages"};
//        
//        goToACMEPortal();
//        signIn("root", "gtn");
//        goToPage("//div[contains(., 'Content Manager')]", new String[]{ELEMENT_LINK_GROUP, ELEMENT_LINK_CONTENT_EXPLORER});
//        Navigation.openDrive("collaboration");
//        SideBar.FileExplorer.browse(path);
//
//        info("create new document in collaboration drive");
//        addContent(webContent);
//        DocumentWorkspace.fillCreateForm(webContent);
//        DocumentWorkspace.saveAndClose();
//
//        info("reproduce SPREDHAT-35 issue");
//        
//        open("news");
//        
//        Publication.switchPortalToEditMode();
//
//        debug("open Content Explorer from website");
//        waitForElementPresentAndMouseOver("//div[@class='Column1'][1]"); pause(1000);
//        waitForElementPresentAndClick("//a[contains(@class,'EditContentIcon') and @title='Edit'][1]");
//        waitForPageToLoad();
//
//        Navigation.openDrive("collaboration");
//        SideBar.FileExplorer.browse(path);
//        DocumentWorkspace.dblClickItem(title);
//        ActionBar.editContent();
//        
//        info("insert image into document");
//        waitForElementPresent("//table[@class='cke_editor']");
//        String iframe = "//table[@class='cke_editor']//iframe[contains(@title,'Rich text editor')]";
//        waitForElementPresentAndClick(iframe);
//        waitForElementPresentAndClick("//table[@class='cke_editor']//a[@title='WCM Content Selector']");
//
//        getSelenium().waitForPopUp("WCMGadgetSelector", getSelenium().getTimeout());
//        selectWindow("name=WCMGadgetSelector");
//        
//        ContentSelector.browseTree(imagePath);
//        ContentSelector.selectItem(image);
//
//        selectWindow("");
//
//        info("open the 'image properties' dialog");
//        doubleClickOnElement("//img[@alt='"+image+"']");
//
//        info("cancel the 'image properties' dialog");
//        waitForElementPresentAndClick("//div[@class='cke_dialog_body']//a[contains(@class,'cke_dialog_ui_button_cancel')]");
//
//        DocumentWorkspace.saveAndClose();
//
//        info("verify editor content");
//        assertTrue(isElementPresent("//img[@alt='DocumentContentIcon.gif']"));
//
//    }
//
//}
