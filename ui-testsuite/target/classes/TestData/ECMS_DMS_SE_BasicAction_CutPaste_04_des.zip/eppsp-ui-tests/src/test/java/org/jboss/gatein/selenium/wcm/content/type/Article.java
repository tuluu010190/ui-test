package org.jboss.gatein.selenium.wcm.content.type;


import org.jboss.gatein.selenium.AbstractWCMTestCase;
import static org.jboss.gatein.selenium.WCMCommonHelper.*;
//import static org.jboss.gatein.selenium.WCMCommonHelper.waitForElementPresentAndTypeCKEditor;
import static org.jboss.gatein.selenium.common.CommonHelper.isElementPresent;
import static org.jboss.gatein.selenium.common.CommonHelper.pause;
import org.jboss.gatein.selenium.wcm.content.CKEditor;
import static org.testng.Assert.assertTrue;

/**
 *
 * @author Tomas Kyjovsky <tkyjovsk at redhat dot org>
 */
public class Article extends Content {

    public static final String CONTENT_TYPE = "exo:article";
    public static final String CONTENT_TYPE_TITLE = "Article";

    public static final String CKE_SUMMARY = CKEditor.LOCATOR_TEMPLATE.replace("{name}", "Summary");
    public static final String CKE_CONTENT = CKEditor.LOCATOR_TEMPLATE.replace("{name}", "Content");
    public static final String FIELD_DIV_TPL = "//div[@class='ArticleFrame' and .//div[@class='FieldLabel' and contains(., '{field}')]]//div[contains(.,'{content}')]";

    @Override
    public String getContentType() {
        return CONTENT_TYPE;
    }
    
    @Override
    public String getContentTypeTitle() {
        return CONTENT_TYPE_TITLE;
    }
    
    @Override
    public void fillCreateForm(String formLocator) throws Exception {
waitForElementPresentAndType(INPUT_TITLE, getTitle());
        waitForElementPresentAndType(INPUT_NAME, getName());
        fillUpdateForm(formLocator);
    }

    @Override
    public void fillUpdateForm(String formLocator) throws Exception {
        waitForElementPresentAndTypeCKEditor(CKE_SUMMARY, getSummary());
        pause(2000);
        waitForElementPresentAndTypeCKEditor(CKE_CONTENT, getContent());
        pause(2000);
    }

    @Override
    public void verifyDisplayedContent(String locator) throws Exception {
        String locArticle = locator+"//div[@class='UIArticle']";
        assertTrue(isElementPresent("//div[@class='UIArticle' and .//div[contains(.,'" + getTitle() + "')]]"));
        assertTrue(isElementPresent(locArticle + FIELD_DIV_TPL.replace("{field}", "Summary").replace("{content}", summary)));
        assertTrue(isElementPresent(locArticle + FIELD_DIV_TPL.replace("{field}", "Content").replace("{content}", content)));
    }

    @Override
    public void updateContent(String initString) {
        setSummary("summary of "+getName()+initString);
        setContent("content of "+getName()+initString);
    }

    private String summary;
    private String content;

    public String getSummary() {
        return summary;
    }

    public void setSummary(String summary) {
        this.summary = summary;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public Article(String name) {
        this(name, "-", "-");
    }
    
    public Article(String name, String summary, String content) {
        super(name);
        this.summary = summary;
        this.content = content;
    }

    public static Article generateUnique() {
        Article article = new Article("article"+AbstractWCMTestCase.generateTimeStampSuffix());
        article.updateContent("");
        return article;
    }

}
