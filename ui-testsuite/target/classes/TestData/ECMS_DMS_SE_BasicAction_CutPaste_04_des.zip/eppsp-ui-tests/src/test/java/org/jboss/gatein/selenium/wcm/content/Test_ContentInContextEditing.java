/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package org.jboss.gatein.selenium.wcm.content;

import org.jboss.gatein.selenium.AbstractWCMTestCase;
import static org.jboss.gatein.selenium.WCMCommonHelper.*;
import org.jboss.gatein.selenium.wcm.content.ContentExplorer.ContentManagement;
import static org.jboss.gatein.selenium.wcm.content.ContentExplorer.goToACMECategoryFolder;
import static org.jboss.gatein.selenium.wcm.content.InContext.*;
import static org.jboss.gatein.selenium.wcm.content.Publication.switchPortalToPublishedMode;
import org.jboss.gatein.selenium.wcm.content.type.WebContent;
import static org.jboss.gatein.selenium.wcm.presentation.CLV.checkCLVDisplayedContents;
import static org.jboss.gatein.selenium.wcm.presentation.CLV.checkCLVDisplayedContentsPublished;
import org.testng.annotations.Test;
import static org.jboss.gatein.selenium.testng.TestLogger.*;
/**
 *
/**
 *
 * @author mgottval
 */
public class Test_ContentInContextEditing extends AbstractWCMTestCase{
    
    @Test(enabled=true)
    public void test_inContextEditing() throws Exception {    
        
        
        String title = "IN_WCM_"+generateTimeStampSuffix(); 
        
        String[] listPublished = {title+" summary"};
        String[] listEdited = {title+"Edit"};
        String[] listManaged = {title+"-Edit"};
        
        goToACMEPortal();
        signInAsRoot();
        
        //deleting another files
//        goToPage("//div[contains(., 'Content Manager')]", new String[]{ELEMENT_LINK_GROUP, ELEMENT_LINK_CONTENT_EXPLORER});
//        goToACMECategoryFolder();
        
//        deleteRemainigFilesInNews("SNF_WCM_");
        
        goToACMEPortalPage("news");

        
        addContentInContextNews(new WebContent(title, title+" mainContent", title+" summary", "css", "js"), "news");

        inContextPublish(title+" summary");
        
        switchPortalToPublishedMode();
        
        checkCLVDisplayedContentsPublished("news", listPublished);
        
        
        inContextEdittingNews("news", title, new WebContent(title+"Edit", title+"Edit", title+"Edit", "css", "js"));
        
        checkCLVDisplayedContents("news", listEdited);
                
        manageContentInContextNews("news");
        
        editContentInContext(title);
        
        checkCLVDisplayedContents("news", listManaged);
        
        switchPortalToPublishedMode();
        
        checkCLVDisplayedContentsPublished("news", listPublished);
        
        goToPage("//div[contains(., 'Content Manager')]", new String[]{ELEMENT_LINK_GROUP, ELEMENT_LINK_CONTENT_EXPLORER});

        goToACMECategoryFolder();
        
        ContentManagement.deleteItem(title);
        
    }
    
}
