package org.jboss.gatein.selenium.language;

import static org.jboss.gatein.selenium.common.CommonHelper.*;
import static org.jboss.gatein.selenium.language.LanguageHelper.*;
import static org.jboss.gatein.selenium.usersmanagement.UsersManagementHelper.*;

import org.jboss.gatein.selenium.AbstractTestCase;
import org.testng.annotations.Test;

public class Test_POR_07_006_ChangeLanguageOfUserInOrganization extends AbstractTestCase {

	@Test(groups={"epp5.0", "language"})
	public void testPOR_07_006_ChangeLanguageOfUserInOrganization() throws Exception {
		String userEditIcon = ELEMENT_USER_EDIT_ICON.replace("${username}", "mary");
		
		System.out.println("--ChangeLanguageInUserManagement--");
		openPortal(true);
		signInAsRoot();
		goToUsersAndGroupsManagement();
		
		System.out.println("--Change language for user--");
		click(userEditIcon);
        type(ELEMENT_INPUT_EMAIL, "mary@localhost.com", true);
		click(ELEMENT_USER_PROFILE_TAB);
		select(ELEMENT_SELECT_USER_LANGUAGE, "Vietnamese");
		save();
		
		waitForMessage("The user profile has been updated.");
		closeMessageDialog();
		
		signOut();
		
		System.out.println("--Login with user which edited aboved--");
		signInAsMary();
		waitForTextPresent(HOME_LABEL_VIETNAMESE);
		signOut();
		
		System.out.println("--Login with edited user to change language--");
		signInAsMary();
		waitForTextPresent(HOME_LABEL_VIETNAMESE);
		changeLanguage(LANGUAGE_ENGLISH);
        goToClassicPortal();
		signOut();
	}
}
