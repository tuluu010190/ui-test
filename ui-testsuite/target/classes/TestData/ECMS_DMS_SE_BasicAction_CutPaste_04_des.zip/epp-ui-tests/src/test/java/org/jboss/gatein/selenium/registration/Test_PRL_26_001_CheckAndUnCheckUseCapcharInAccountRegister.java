package org.jboss.gatein.selenium.registration;

import org.jboss.gatein.selenium.AbstractTestCase;
import org.testng.Assert;
import org.testng.annotations.Test;

import static org.jboss.gatein.selenium.common.CommonHelper.*;
import static org.jboss.gatein.selenium.registration.RegistrationHelper.*;

public class Test_PRL_26_001_CheckAndUnCheckUseCapcharInAccountRegister extends AbstractTestCase {
	
	@Test(groups={"registration"})
	public void testPRL_26_001_CheckAndUnCheckUseCapcharInAccountRegister()	throws Exception {
        
		System.out.println("-- Create new account when un-check/Check Use captcha --");
        
		openPortal(true);
		
		signInAsRoot();
        
		String registerPage = getPortalUrl().concat("/private/classic/register");
		
		open(registerPage);

		waitForTextPresent("Register New Account");
		
		setCaptchaInEditPage(false);
		
		signOut();
		
		signInAsRoot();
		
		open(registerPage);

		waitForTextPresent("Register New Account");
		
		waitForElementNotPresent(ELEMENT_INPUT_CAPTCHA);
		
		System.out.println("-- check Use capchar--");
		
		setCaptchaInEditPage(true);
		
		signOut();
		
		signInAsRoot();
		
		open(registerPage);

		waitForTextPresent("Register New Account");
		
		Assert.assertTrue(isElementPresent(ELEMENT_INPUT_CAPTCHA));
		
		signOut();
	}

}
