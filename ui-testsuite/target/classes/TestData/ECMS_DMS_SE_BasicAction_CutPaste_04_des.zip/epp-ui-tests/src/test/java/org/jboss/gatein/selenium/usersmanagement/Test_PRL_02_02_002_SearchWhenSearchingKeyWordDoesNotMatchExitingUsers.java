package org.jboss.gatein.selenium.usersmanagement;

import org.jboss.gatein.selenium.AbstractTestCase;
import org.testng.annotations.Test;

import static org.jboss.gatein.selenium.common.CommonHelper.*;
import static org.jboss.gatein.selenium.usersmanagement.UsersManagementHelper.*;

public class Test_PRL_02_02_002_SearchWhenSearchingKeyWordDoesNotMatchExitingUsers extends AbstractTestCase {
	
	@Test(groups={"usersmanagement","one"})
	public void testPRL_02_02_002_SearchWhenSearchingKeyWordDoesNotMatchExitingUsers() throws Exception {
        
		System.out.println("-- Search when searching keyword does not match existing users--");

		openPortal(true);
		
		signInAsRoot();
		
		goToUsersAndGroupsManagement();
		
		System.out.println("-- Search when searching keyword does not match existing users--");
		
		searchUserByUserName("testtest");
		
		waitForMessage("No result found.");
		closeMessageDialog();
		
		System.out.println("-- Return to user list--");
		
		searchUserByUserName("");

		System.out.println("-- Do search when search keyword matches un-selected search type--");
		
		searchUser("Demo", "Last Name");
		
		waitForMessage("No result found.");
		closeMessageDialog();

		System.out.println("-- Return to user list--");
		
		searchUserByUserName("");
		
		signOut();
	}

}
