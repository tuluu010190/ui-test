package org.jboss.gatein.selenium.usersmanagement;

import org.jboss.gatein.selenium.AbstractTestCase;
import org.testng.annotations.Test;

import static org.jboss.gatein.selenium.common.CommonHelper.*;
import static org.jboss.gatein.selenium.language.LanguageHelper.*;
import static org.jboss.gatein.selenium.usersmanagement.UsersManagementHelper.*;

public class Test_PRL_02_02_005_SearchUserAfterItWasAlreadyDeleted extends AbstractTestCase {
	
	@Test(groups={"usersmanagement","one"})
	public void testPRL_02_02_005_SearchUserAfterItWasAlreadyDeleted() throws Exception {
        
		System.out.println("-- Search user after it was already deleted --");
		
		openPortal(true);
		
		signInAsRoot();
		
		goToNewStaff();
		
		addNewAccountAtNewStaff("test_prl_02_02_005", "Test_PRL_02_02_005", "Test_PRL_02_02_005", "Test_PRL_02_02_005", "Test_PRL_02_02_005", "Test_PRL_02_02_005@localhost.com", "", "Russian", true);
		
		signOut();
		
		System.out.println("-- Login in with new user--");

		signIn("test_prl_02_02_005", "Test_PRL_02_02_005");
        
        waitForTextPresent(HOME_LABEL_RUSSIAN);
		
		signOut();
		
		System.out.println("-- Sign in with Administrator to delete and search new user--");
		
		signInAsRoot();

		goToUsersAndGroupsManagement();
		
		System.out.println("-- Search new user in list--");
		
		searchUserByUserName("test_prl_02_02_005");

		deleteUser("test_prl_02_02_005");
		
		waitForMessage("No result found.");
		closeMessageDialog();

		System.out.println("-- Return to user list after delete new user--");
		
		searchUserByUserName("");

		System.out.println("-- Search new user after delete from user list--");
		
		searchUserByUserName("test_prl_02_02_005");

		waitForMessage("No result found.");
		closeMessageDialog();

		signOut();
	}

}
