package org.jboss.gatein.selenium.usersmanagement;

import org.jboss.gatein.selenium.AbstractTestCase;
import org.testng.annotations.Test;

import static org.jboss.gatein.selenium.common.CommonHelper.*;
import static org.jboss.gatein.selenium.usersmanagement.UsersManagementHelper.*;

public class Test_PRL_03_02_003_AddNewGroupWhenNameStartWithNumber extends AbstractTestCase {
	
	@Test(groups={"usersmanagement","two"})
	public void testPRL_03_02_003_AddNewGroupWhenNameStartWithNumber() throws Exception {
        
		System.out.println("-- Add new group when Name starts with number--");

		openPortal(true);
		
		signInAsRoot();

		goToUsersAndGroupsManagement();
		
		chooseGroupTab();
		
		addNewGroup("03_02_003", "Test_PRL_03_02_003", "Test_PRL_03_02_003", false);
		
		waitForMessage("The \"Group Name\" field must start with a letter and must not contain special characters.");
		closeMessageDialog();
		
		cancel();

		signOut();
	}

}
