package org.jboss.gatein.selenium.navigation;

import org.jboss.gatein.selenium.AbstractTestCase;
import org.testng.annotations.Test;

import static org.jboss.gatein.selenium.common.CommonHelper.*;
import static org.jboss.gatein.selenium.navigation.NavigationHelper.*;

public class Test_SNF_PRL_26_MoveUpAndDownANode extends AbstractTestCase {
	
	@Test(groups={"sniff", "epp5.0", "navigation"})
	public void testSNF_PRL_26_MoveUpAndDownANode() throws Exception {
        
		String node = ELEMENT_NODE_LINK.replace("${nodeLabel}", "test_grp_label_26");
		String nodePosition = ELEMENT_NODE_ITEM + "[${position}]/div/a[@title='test_grp_label_26']";
		
		System.out.println("-MoveUp/DownNode-");
		
		openPortal(true);

		signInAsRoot();
		
		goToGroup();

		addNewNode("test_grp_node_26", "test_grp_label_26", false, ELEMENT_NAVIGATION_HOME_NODE, null, null, false, true, false, null);

		System.out.println("--Edit node's position");

		goToGroup();

		editFirstNavigation();

		waitForAndGetElement(node);

		String nodeLvl = getCountOfElements(ELEMENT_NODE_ITEM);

		System.out.println("--Node is at level " + nodeLvl + "--");

		contextMenuOnElement(node);
		
		click(ELEMENT_NODE_MOVE_UP);
		
		String position = nodePosition.replace("${position}", nodeLvl);
        waitForElementNotPresent(position);
        
		System.out.println("Node is not at level " + nodeLvl + "");

		System.out.println("--Move node down");
		
		contextMenuOnElement(node);
		
		click(ELEMENT_NODE_MOVE_DOWN);
                
        waitForAndGetElement(position);

		System.out.println("Node is back at level " + nodeLvl + "");

		deleteNodeFromFirstNavigation("test_grp_label_26", null, true);

		signOut();
	}

}
