package org.jboss.gatein.selenium.navigation;

import java.util.Locale;
import java.text.DateFormat;
import java.util.Date;
import org.jboss.gatein.selenium.AbstractTestCase;
import org.testng.annotations.Test;

import static org.jboss.gatein.selenium.common.CommonHelper.*;
import static org.jboss.gatein.selenium.navigation.NavigationHelper.*;
import org.testng.Assert;

/**
 * This test can fail when is run on different machine from machine where EPP is. It is using system time and it can be different.
 * 
 * @author vramik
 */
public class Test_SNF_PRL_38_CreateNewNodeAndTestPublicationDate extends AbstractTestCase {
	
	@Test(groups={"sniff", "navigation"})
	public void testSNF_PRL_38_CreateNewNodeAndTestPublicationDate() throws Exception {
                
        openPortal(true);
        
        signInAsRoot();
        
        goToSite();
        
        editFirstNavigation();
        
        click(ELEMENT_ADD_NODE_LINK);
        
        click(ELEMENT_PAGE_SELECTOR_TAB);
        click(ELEMENT_SEARCH_SELECT_PAGE_LINK);
        click(ELEMENT_SELECT_PAGE_FIRST);
        
        click(ELEMENT_PAGE_NODE_SETTING_TAB);

        waitForAndGetElement(ELEMENT_INPUT_NAME);
		type(ELEMENT_INPUT_NAME, "SNF_PRL_38", true);
        
        check(ELEMENT_CHECKBOX_PUBLICATION_DATE_TIME);
        
        System.out.println("now: " + new Date());
        Date startTime = addSecondsToSystemTime(30);
        Date endTime = addSecondsToSystemTime(60); 
        type(ELEMENT_INPUT_START_PUBLICATION_DATE, parseDateToCorrectFormat(startTime), true);
        type(ELEMENT_INPUT_END_PUBLICATION_DATE, parseDateToCorrectFormat(endTime), true);

        System.out.println("Start Publication Date: " + getValue(ELEMENT_INPUT_START_PUBLICATION_DATE));
        System.out.println("End Publication Date: " + getValue(ELEMENT_INPUT_END_PUBLICATION_DATE));
        
        click(ELEMENT_INPUT_NAME);
        save();
        waitForElementNotPresent(ELEMENT_INPUT_NAME);
        pause(500);
        save();
        waitForElementNotPresent(ELEMENT_SAVE_BUTTON);
        
        System.out.println("--Verify if node is not presented--");
        goToSite();
        mouseOver(ELEMENT_LINK_SITE, true);
        mouseOver(ELEMENT_LINK_CLASSIC_PORTAL, true);
        mouseOver(ELEMENT_LINK_HOME, true);
        waitForTextNotPresent("SNF_PRL_38");
        goToSite();
        
        if (!new Date().after(endTime)) {
            waitForTimeAfter(startTime);
        } else {
            Assert.fail("It's already after end publication time.");
        }
        
        System.out.println("--Verify if node is presented--");
        goToSite();
        String verification = ELEMENT_SELECTED_BREDCRUMBS_INFO_BAR.replace("${pageName}", "SNF_PRL_38");
        goToPage(verification, ELEMENT_LINK_SITE, ELEMENT_LINK_CLASSIC_PORTAL, ELEMENT_LINK_HOME, "SNF_PRL_38");
        
        waitForTimeAfter(endTime);
        
        System.out.println("--Verify if node is not presented--");
        goToSite();
        mouseOver(ELEMENT_LINK_SITE, true);
        mouseOver(ELEMENT_LINK_CLASSIC_PORTAL, true);
        mouseOver(ELEMENT_LINK_HOME, true);
        waitForTextNotPresent("SNF_PRL_38");
        
        deleteNodeFromFirstNavigation("SNF_PRL_38", null, true);
        
        signOut();
	}

    private void waitForTimeAfter(Date time) {
        System.out.println("--Waiting for page (not) to be presented.--");
        while (true) {
            Date now = new Date();
            if (now.after(time)) {
                System.out.println("\nafter");
                break;
            }
            if (now.before(time)) {
                System.out.print("before, ");
            }
            pause(1000);
        }
        pause(1000);
    }

    private static Date addSecondsToSystemTime(int seconds) {
        return new Date(new Date().getTime() + (seconds * 1000));
    }
    
    private static String parseDateToCorrectFormat(Date date) {
        DateFormat timeFormat = DateFormat.getDateTimeInstance(3, 2, Locale.UK);
        
        String stringDate = timeFormat.format(date);
        
        return switchDayAndMonth(stringDate);
    }
    
    private static String switchDayAndMonth(String date) {
        String first = date.substring(0, 2);
        String second = date.substring(3, 5);
        String rest = date.substring(6);
       
        return second + "/" + first + "/20" + rest;
    }
}
