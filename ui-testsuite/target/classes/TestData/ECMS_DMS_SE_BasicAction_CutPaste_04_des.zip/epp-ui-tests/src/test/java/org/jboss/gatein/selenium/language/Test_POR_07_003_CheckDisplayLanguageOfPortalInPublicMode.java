package org.jboss.gatein.selenium.language;

import static org.jboss.gatein.selenium.common.CommonHelper.*;
import static org.jboss.gatein.selenium.language.LanguageHelper.*;

import org.jboss.gatein.selenium.AbstractTestCase;
import org.testng.annotations.Test;

public class Test_POR_07_003_CheckDisplayLanguageOfPortalInPublicMode extends AbstractTestCase {
	
	@Test(groups={"epp5.0", "language"})
	public void testPOR_07_003_CheckDisplayLanguageOfPortalInPublicMode() throws Exception {
		System.out.println("-Change Language from English to Vietnamese-");
		
		openPortal(true);

		changeLanguage(LANGUAGE_VIETNAMESE);
		
		waitForTextPresent(HOME_LABEL_VIETNAMESE);

		changeLanguage(LANGUAGE_ENGLISH);

		waitForTextPresent(HOME_LABEL_ENGLISH);
	}
}
