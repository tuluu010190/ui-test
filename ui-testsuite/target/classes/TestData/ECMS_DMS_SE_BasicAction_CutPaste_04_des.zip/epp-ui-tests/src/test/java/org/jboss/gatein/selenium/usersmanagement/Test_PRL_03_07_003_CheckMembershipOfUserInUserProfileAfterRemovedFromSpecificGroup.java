package org.jboss.gatein.selenium.usersmanagement;

import org.jboss.gatein.selenium.AbstractTestCase;
import org.testng.annotations.Test;

import static org.jboss.gatein.selenium.common.CommonHelper.*;
import static org.jboss.gatein.selenium.usersmanagement.UsersManagementHelper.*;

public class Test_PRL_03_07_003_CheckMembershipOfUserInUserProfileAfterRemovedFromSpecificGroup extends AbstractTestCase {
	
	@Test(groups={"usersmanagement","two"})
	public void testPRL_03_07_003_CheckMembershipOfUserInUserProfileAfterRemovedFromSpecificGroup()	throws Exception {
        
		String userEditIcon = ELEMENT_USER_EDIT_ICON.replace("${username}", "mary");
		
		System.out.println("-- Check Membership of user in User profile after removed from specific group--");
		
		openPortal(true);
		
		signInAsRoot();

		goToUsersAndGroupsManagement();
		
		chooseGroupTab();
		
		selectGroup("Organization/Communication");
		
		addUsersAtGroup("mary", "manager", true, true);
		
		deleteUserFromGroup("mary", "manager", "organization/communication", true);
		
		chooseUserTab();
		
		System.out.println("-- Search user--");

		searchUserByUserName("mary");
		
		click(userEditIcon);

		click(ELEMENT_USER_MEMBERSHIP_TAB);

		waitForTextPresent("Group Id");
		
		waitForTextNotPresent("manager");
		
		cancel();

		signOut();
	}

}
