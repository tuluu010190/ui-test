package org.jboss.gatein.selenium.usersmanagement;

import org.jboss.gatein.selenium.AbstractTestCase;
import org.testng.annotations.Test;

import static org.jboss.gatein.selenium.common.CommonHelper.*;
import static org.jboss.gatein.selenium.usersmanagement.UsersManagementHelper.*;

public class Test_PRL_04_04_005_CheckExistingOfUserInGroupAfterHisRoleInThatGroupWasDeleted extends AbstractTestCase {
	
	@Test(groups={"usersmanagement","two"})
	public void testPRL_04_04_005_CheckExistingOfUserInGroupAfterHisRoleInThatGroupWasDeleted()	throws Exception {
        
		System.out.println("--Check existing of user in group after his role in that group was deleted--");
		
		openPortal(true);
		
		signInAsRoot();
		
		goToUsersAndGroupsManagement();
		
		chooseMembershipTab();

		addNewMembership("Test_PRL_04_04_005", "Test_PRL_04_04_005", true);
		
		chooseGroupTab();
		
		selectGroup("Customers");
		
		addUsersAtGroup("mary", "Test_PRL_04_04_005", false, true);
		
		System.out.println("-- Return to Membership Management to delete new membership--");
		
		chooseMembershipTab();
		
		deleteMembership("Test_PRL_04_04_005", true);
		
		System.out.println("-- Check existing of user in group--");
		
		chooseGroupTab();
		
		selectGroup("Customers");
		
		waitForTextNotPresent("Test_PRL_04_04_005");
		
		signOut();
	}

}
