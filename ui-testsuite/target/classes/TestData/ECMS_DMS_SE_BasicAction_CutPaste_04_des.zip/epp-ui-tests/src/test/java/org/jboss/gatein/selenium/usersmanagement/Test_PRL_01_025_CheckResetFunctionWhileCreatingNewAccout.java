package org.jboss.gatein.selenium.usersmanagement;

import org.jboss.gatein.selenium.AbstractTestCase;
import org.testng.Assert;
import org.testng.annotations.Test;

import static org.jboss.gatein.selenium.common.CommonHelper.*;
import static org.jboss.gatein.selenium.usersmanagement.UsersManagementHelper.*;

public class Test_PRL_01_025_CheckResetFunctionWhileCreatingNewAccout extends AbstractTestCase {
	
	@Test(groups={"usersmanagement","one"})
	public void testPRL_01_025_CheckResetFunctionWhileCreatingNewAccout() throws Exception {
        
		System.out.println("-- Check Reset function while creating new account--");
		
		openPortal(true);
		
		signInAsRoot();
		
		goToNewStaff();
		
		type(ELEMENT_INPUT_USERNAME, "test_PRL_01_025", true);
		type(ELEMENT_INPUT_PASSWORD, "Test_PRL_01_025", true);
		type(ELEMENT_INPUT_CONFIRM_PASSWORD, "Test_PRL_01_025", true);
		type(ELEMENT_INPUT_FIRSTNAME, "Test_PRL_01_025", true);
		type(ELEMENT_INPUT_LASTNAME, "Test_PRL_01_025", true);
		type(ELEMENT_INPUT_EMAIL, "Test_PRL_01_025@localhost.com", true);
		click(ELEMENT_USER_PROFILE_TAB);
		waitForTextPresent("Given Name:");
		select(ELEMENT_SELECT_USER_LANGUAGE, "Italian");
		click(ELEMENT_ACCOUNT_SETTING_TAB);
		
		System.out.println("-- Click Reset--");

		click(ELEMENT_RESET_BUTTON);
		
		Assert.assertEquals(getValue(ELEMENT_INPUT_PASSWORD), "");
		
		Assert.assertEquals(getValue(ELEMENT_INPUT_CONFIRM_PASSWORD), "");
		
		Assert.assertEquals(getValue(ELEMENT_INPUT_FIRSTNAME), "");
		
		Assert.assertEquals(getValue(ELEMENT_INPUT_LASTNAME), "");
		
		Assert.assertEquals(getValue(ELEMENT_INPUT_EMAIL), "");
		
		Assert.assertEquals(getValue(ELEMENT_INPUT_USERNAME), "");

		signOut();
	}

}
