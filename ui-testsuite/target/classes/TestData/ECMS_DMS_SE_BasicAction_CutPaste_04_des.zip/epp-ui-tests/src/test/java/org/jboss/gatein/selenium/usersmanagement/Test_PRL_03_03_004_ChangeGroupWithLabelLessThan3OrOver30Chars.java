package org.jboss.gatein.selenium.usersmanagement;

import org.jboss.gatein.selenium.AbstractTestCase;
import org.testng.annotations.Test;

import static org.jboss.gatein.selenium.common.CommonHelper.*;
import static org.jboss.gatein.selenium.usersmanagement.UsersManagementHelper.*;

public class Test_PRL_03_03_004_ChangeGroupWithLabelLessThan3OrOver30Chars extends AbstractTestCase {
	
	@Test(groups={"usersmanagement","two"})
	public void testPRL_03_03_004_ChangeGroupWithLabelLessThan3OrOver30Chars() throws Exception {
        
		System.out.println("-- Edit group with Label less than 3 or over 30 characters--");
		
		openPortal(true);
		
		signInAsRoot();
		
		goToUsersAndGroupsManagement();
		
		chooseGroupTab();

		addNewGroup("Test_PRL_03_03_004", "Test_PRL_03_03_004", "Test_PRL_03_03_004", true);
		
		System.out.println("-- Edit group with label less than 3 chars--");
		
		click(ELEMENT_GROUP_EDIT_SELECTED);

		type(ELEMENT_INPUT_LABEL, "PR", true);

		save();
		
		waitForMessage("The length of the text in field \"Label\" must be between \"3\" and \"30\" characters.");
		closeMessageDialog();
		
		System.out.println("-- Edit label over 30 chars--");
		
		type(ELEMENT_INPUT_LABEL, "Test_PRL_03_03_004 Test_PRL_03_03_004 Test_PRL_03_03_004 Test_PRL_03_03_004 Test_PRL_03_03_004", true);

		save();
		
		waitForMessage("The length of the text in field \"Label\" must be between \"3\" and \"30\" characters.");
		closeMessageDialog();
		
		cancel();

		deleteGroup("Test_PRL_03_03_004", true);
		
		signOut();
	}

}
