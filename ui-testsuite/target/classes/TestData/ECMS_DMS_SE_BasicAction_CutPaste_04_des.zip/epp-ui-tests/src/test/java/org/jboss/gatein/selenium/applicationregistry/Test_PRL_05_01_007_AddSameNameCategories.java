package org.jboss.gatein.selenium.applicationregistry;

import java.util.HashMap;
import java.util.Map;

import org.jboss.gatein.selenium.AbstractTestCase;
import org.testng.annotations.Test;

import static org.jboss.gatein.selenium.applicationregistry.ApplicationRegistryHelper.*;
import static org.jboss.gatein.selenium.common.CommonHelper.*;

public class Test_PRL_05_01_007_AddSameNameCategories extends AbstractTestCase {
		
	@Test(groups={"applicationregistry"})
	public void testPRL_05_01_007_AddSameNameCategories() throws Exception {
		System.out.println("-- Add same name categories--");

		openPortal(true);
		
		signInAsRoot();
		
		goToApplicationRegistry();
		
		Map<String, String> permissions = new HashMap<String, String>();
		permissions.put("Platform/Administrators", "manager");
		addNewCategory("Test_PRL_05_01_007", "Test_PRL_05_01_007", "Test_PRL_05_01_007", false, permissions, true);
		
		addApplicationToCategory("Test_PRL_05_01_007", PortletType.GADGET, "Calculator", "");
		
		permissions.clear();
		permissions.put("Organization/Management", "manager");
		addNewCategory("Test_PRL_05_01_007", "Test_PRL_05_01_007", "Test_PRL_05_01_007", false, permissions, false);
		
		waitForMessage("This category is existing, please enter another one!");
		closeMessageDialog();

		deleteCategory("Test_PRL_05_01_007");
		
		signOut();
	}

}
