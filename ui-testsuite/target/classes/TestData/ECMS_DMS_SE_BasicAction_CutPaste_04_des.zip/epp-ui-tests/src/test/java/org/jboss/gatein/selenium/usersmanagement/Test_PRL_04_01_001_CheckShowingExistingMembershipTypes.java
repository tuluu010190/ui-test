package org.jboss.gatein.selenium.usersmanagement;

import org.jboss.gatein.selenium.AbstractTestCase;
import org.testng.annotations.Test;

import static org.jboss.gatein.selenium.common.CommonHelper.*;
import static org.jboss.gatein.selenium.usersmanagement.UsersManagementHelper.*;

public class Test_PRL_04_01_001_CheckShowingExistingMembershipTypes extends AbstractTestCase {
	
	@Test(groups={"usersmanagement","two"})
	public void testPRL_04_01_001_CheckShowingExistingMembershipTypes() throws Exception {
        
		System.out.println("-- Check showing existing membership types--");
		
		openPortal(true);
		
		signInAsRoot();
		
		goToUsersAndGroupsManagement();
		
		chooseMembershipTab();

		waitForTextPresent("member");
		
		waitForTextPresent("manager");
		
		waitForTextPresent("validator");
		
		signOut();
	}

}
