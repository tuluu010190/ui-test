package org.jboss.gatein.selenium.navigation;

import org.jboss.gatein.selenium.AbstractTestCase;
import org.testng.annotations.Test;

import static org.jboss.gatein.selenium.common.CommonHelper.*;
import static org.jboss.gatein.selenium.navigation.NavigationHelper.*;


public class Test_POR_15_01_001_CheckVisibleCheckbox extends AbstractTestCase {
	
	@Test(groups={"navigation"})
	public void testPOR_15_01_001_CheckVisibleCheckbox() throws Exception {
        
		openPortal(true);
        
        signInAsRoot();
        
        goToSite();
        
        editFirstNavigation();
        
        click(ELEMENT_ADD_NODE_LINK);
        
        waitForTextPresent("Page Node Setting");
        
        waitForAndGetElement(ELEMENT_CHECKBOX_PUBLICATION_DATE_TIME);
        
        uncheck(ELEMENT_CHECKBOX_VISIBLE);
        
        waitForElementNotPresent(ELEMENT_CHECKBOX_PUBLICATION_DATE_TIME);

        check(ELEMENT_CHECKBOX_VISIBLE);
        
        waitForAndGetElement(ELEMENT_CHECKBOX_PUBLICATION_DATE_TIME);
        
        closeByX();
        
        signOut();
	}

}
