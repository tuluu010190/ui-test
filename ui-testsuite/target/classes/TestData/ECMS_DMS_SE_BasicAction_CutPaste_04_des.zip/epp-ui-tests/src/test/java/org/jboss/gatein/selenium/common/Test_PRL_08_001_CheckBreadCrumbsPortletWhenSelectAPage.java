package org.jboss.gatein.selenium.common;

import org.jboss.gatein.selenium.AbstractTestCase;

import static org.jboss.gatein.selenium.common.CommonHelper.*;

import org.testng.Assert;
import org.testng.annotations.Test;

public class Test_PRL_08_001_CheckBreadCrumbsPortletWhenSelectAPage extends AbstractTestCase {

	@Test(groups={"common"})
	public void testPRL_08_001_CheckBreadCrumbsPortletWhenSelectAPage()
			throws Exception {
		System.out.println("-- Check breadcrumbs portlet when select a page--");
		
		openPortal(true);
		
		signInAsRoot();

		System.out.println("-- Select page from page navigation (not child page)--");

        goToSiteClassicHome();
		
		Assert.assertTrue(isTextAtElementEqual(ELEMENT_BREADCRUMB_SELECTED_TEXT, "Home"));
	}

}
