package org.jboss.gatein.selenium.navigation;

import org.jboss.gatein.selenium.AbstractTestCase;
import org.testng.annotations.Test;

import static org.jboss.gatein.selenium.common.CommonHelper.*;
import static org.jboss.gatein.selenium.navigation.NavigationHelper.*;
import static org.jboss.gatein.selenium.page.PageHelper.*;

public class Test_SNFN_PRL_35_ChangeApplicationWhenEditPropertiesOfNodeInPortalNavigation extends AbstractTestCase {
	
	@Test(groups={"sniff", "navigation"})
	public void testSNFN_PRL_35_ChangeApplicationWhenEditPropertiesOfNodeInPortalNavigation() throws Exception {
		
        String node = ELEMENT_NODE_LINK.replace("${nodeLabel}", "Test_SNF_PRL_35");
        String gadgetsCategory = ELEMENT_EDIT_PAGE_CATEGORY_MENU.replace("${categoryLabel}", "Gadgets");
        String calculator = "//div[@id='Gadgets/Calculator']";
        String pageVerification = BREADCRUMB_PORTLET_SELECTED_NODE.replace("${node_label}", "Test_SNF_PRL_35");
        String calculatorPosition1 = ELEMENT_EDIT_PAGE_COMPONENT_FIRST + PORTLET_LABEL.replace("${portletName}", "Calculator");
		
		System.out.println("-- Edit Node page's properties in portal navigation--");
		
		openPortal(true);
		
		signInAsRoot();
		
		goToSite();
		
		addNewNode("Test_SNF_PRL_35", "Test_SNF_PRL_35", true, null, "Test_SNF_PRL_35", "Test_SNF_PRL_35", true, true, false, null);
		
		System.out.println("-- Change application when edit page properties of node --");

		editFirstNavigation();
		
		contextMenuOnElement(node);
		
		click(ELEMENT_NODE_EDIT_NODE_PAGE);

		System.out.println("-- View layout of node before Change application--");

		click(ELEMENT_SWITCH_VIEW_MODE_PAGE);
		
		click(ELEMENT_SWITCH_VIEW_MODE_PAGE);

		System.out.println("-- Drag & drop applcation in portal--");
		
		click(gadgetsCategory);
		
        String elementEditPagePage = ELEMENT_EDIT_PAGE_PAGE;

        if (ieFlag) {
            elementEditPagePage = ELEMENT_EDIT_PAGE_PAGE + "/..";
        }
        
		dragAndDropToObject(calculator, elementEditPagePage, calculatorPosition1);
		
		System.out.println("-- View application after drag & drop in portal--");

		click(ELEMENT_SWITCH_VIEW_MODE_PAGE);
		
		waitForTextPresent("Calculator");

		System.out.println("-- Return to normal view --");

		click(ELEMENT_SWITCH_VIEW_MODE_PAGE);
		
		System.out.println("--Edit application --");

		editSpecifiedPortletOrContainer("1", false, ELEMENT_INPUT_TITLE);

		type(ELEMENT_INPUT_TITLE, "Test_SNF_PRL_35", true);

		System.out.println("-- Choose Select Icon tab --");

		click(ELEMENT_SELECT_ICON_TAB);

		click(ELEMENT_SELECT_ICON_FIRST);

		System.out.println("-- Choose Decoration Themes--");
                
		click(ELEMENT_DECORATION_THEMES_TAB);

		click(ELEMENT_DECORATION_THEME_FIRST);
		
		click(ELEMENT_SAVE_AND_CLOSE_BUTTON);
		
		System.out.println("-- View after change something in application --");
		
		click(ELEMENT_SWITCH_VIEW_MODE_PAGE);

		waitForTextPresent("Test_SNF_PRL_35");//test fails in this point for gatein because there is not Info Bar shown by default
		
		System.out.println("-- Return to normail view --");
		
		click(ELEMENT_SWITCH_VIEW_MODE_PAGE);

		finishPageEdit();
		
		System.out.println("-- Close Navigation Management form --");

		save();
		
		waitForTextNotPresent("Navigation Management");

        goToPage(pageVerification, ELEMENT_LINK_SITE, ELEMENT_LINK_CLASSIC_PORTAL, ELEMENT_LINK_HOME, "Test_SNF_PRL_35");
		
		goToSite();

		deleteNodeFromFirstNavigation("Test_SNF_PRL_35", null, true);
		
		goToPageManagement();
		
		searchAndDeletePage(PageType.PORTAL, "Test_SNF_PRL_35", "Test_SNF_PRL_35", true, "Test_SNF_PRL_35");

		signOut();
	}

}
