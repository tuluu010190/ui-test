package org.jboss.gatein.selenium.page;

import org.jboss.gatein.selenium.AbstractTestCase;
import org.testng.annotations.Test;

import static org.jboss.gatein.selenium.common.CommonHelper.*;
import static org.jboss.gatein.selenium.page.PageHelper.*;

public class Test_POR_20_024_CreateNewPageForPortalWithValidValues extends AbstractTestCase {
	
	@Test(groups={"epp5.0", "page"})
	public void testPOR_20_024_CreateNewPageForPortalWithValidValues() throws Exception {
        
		System.out.println("--CreateNewPageForPortalWithValidValues--");

		openPortal(true);
		
		signInAsRoot();
		
		goToPageManagement();

		addNewPageAtPageManagement("POR_20_024", "POR_20_024", PageType.PORTAL, null, "portal::classic::POR_20_024");
		
		searchAndDeletePage(PageType.PORTAL, "POR_20_024", "POR_20_024", true, "portal::classic::POR_20_024");
		
		signOut();
	}

}
