package org.jboss.gatein.selenium.applicationregistry;

import java.util.HashMap;
import java.util.Map;

import org.jboss.gatein.selenium.AbstractTestCase;
import org.testng.Assert;
import org.testng.annotations.Test;

import static org.jboss.gatein.selenium.common.CommonHelper.*;
import static org.jboss.gatein.selenium.applicationregistry.ApplicationRegistryHelper.*;
import static org.jboss.gatein.selenium.page.PageHelper.*;
import static org.jboss.gatein.selenium.navigation.NavigationHelper.*;
import static org.jboss.gatein.selenium.permission.PermissionHelper.*;

public class Test_PRL_05_06_003_LimitAccessRightInNonPublicCategoryWhenUserCanAccessApplicationAndItsCategory extends AbstractTestCase {
	
	@Test(groups={"applicationregistry"})
	public void testPRL_05_06_003_LimitAccessRightInNonPublicCategoryWhenUserCanAccessApplicationAndItsCategory() throws Exception {
        
		System.out.println("-- Limit access right for application in not public category when user who has right to access application also has right to access its category--");
		
		openPortal(true);
		
		signInAsRoot();

		goToApplicationRegistry();
		
		System.out.println("-- Add new category--");

		Map<String, String> permissions = new HashMap<String, String>();
		permissions.put("Platform/Administrators", "manager");
		addNewCategory("Test_PRL_05_06_003", "Test_PRL_05_06_003", "Test_PRL_05_06_003", false, permissions, true);
		
		System.out.println("-- Add new application into category--");

		addApplicationToCategory("Test_PRL_05_06_003", PortletType.PORTLET, "HomePage Portlet", "");
		
		Assert.assertTrue(isSelected(ELEMENT_CHECKBOX_PUBLIC_MODE));
		
		signOut();

		System.out.println("-- Login by user who is not in group/membership assigned on added application in above category--");

		signInAsJohn();
		
		goToNewStaff();
		
		System.out.println("-- Add new page--");

        pause(500);
        goToAddNewPage();
        
		type(ELEMENT_INPUT_PAGE_NAME, "Test_PRL_05_06_003", true);
		type(ELEMENT_INPUT_LOCALIZED_LABEL, "Test_PRL_05_06_003", true);
		click(ELEMENT_PAGE_EDITOR_NEXT_STEP);
		waitForTextPresent("Empty Layout");
		click(ELEMENT_PAGE_EDITOR_NEXT_STEP);
		Assert.assertFalse(isTextPresent("Test_PRL_05_06_003"));

		finishPageEdit();
		
		signOut();

		System.out.println("--Login by user who is in group/membership assigned on added application in above category--");

		signInAsRoot();
		
		goToApplicationRegistry();
		
        Map<String, String> portletIdsAndVerifications = new HashMap<String, String>();
        portletIdsAndVerifications.put("Test_PRL_05_06_003/HomePagePortlet", "HomePage Portlet");
		addNewPageWithEditorAtFirstLevel("Test_PRL_05_06_003", "Test_PRL_05_06_003", "Test_PRL_05_06_003", portletIdsAndVerifications, false, null);
		
		System.out.println("--View page created--");

        String verification = LOGO_PORTLET.replace("${text}", "Administrators");
		goToPage(verification, ELEMENT_LINK_GROUP, ELEMENT_LINK_ADMINISTRATION, ELEMENT_LINK_APP_REGISTRY, "Test_PRL_05_06_003");
		
		goToApplicationRegistry();

		deleteCategory("Test_PRL_05_06_003");
		
		System.out.println("-- Delete page which user does not have right on added application in above category --");

		goToGroup();
		
		deleteNodeFromNavigation("Executive Board", "Test_PRL_05_06_003", "New Staff", true);

		System.out.println("--Delete page which user have right on added application in above category--");

		deleteNodeFromNavigation("Administrators", "Test_PRL_05_06_003", "Application Registry", true);
		
		goToPageManagement();
		
		searchAndDeletePage(PageType.GROUP, "page", "Test_PRL_05_06_003", false, null);
        
		searchAndDeletePage(PageType.GROUP, "page", "Test_PRL_05_06_003", true, "Test_PRL_05_06_003");

		signOut();
	}

}
