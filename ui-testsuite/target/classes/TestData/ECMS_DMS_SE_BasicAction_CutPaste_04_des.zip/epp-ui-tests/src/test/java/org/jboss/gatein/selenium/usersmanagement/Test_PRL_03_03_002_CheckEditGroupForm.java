package org.jboss.gatein.selenium.usersmanagement;

import org.jboss.gatein.selenium.AbstractTestCase;
import org.testng.Assert;
import org.testng.annotations.Test;

import static org.jboss.gatein.selenium.common.CommonHelper.*;
import static org.jboss.gatein.selenium.usersmanagement.UsersManagementHelper.*;

public class Test_PRL_03_03_002_CheckEditGroupForm extends AbstractTestCase {

	@Test(groups={"usersmanagement","two"})
	public void testPRL_03_03_002_CheckEditGroupForm() throws Exception {
        
		System.out.println("-- Check Edit group form--");
		
		openPortal(true);
		
		signInAsRoot();
		
		goToUsersAndGroupsManagement();
		
		chooseGroupTab();
		
		selectGroup("Customers");

		click(ELEMENT_GROUP_EDIT_SELECTED);

		waitForAndGetElement(ELEMENT_INPUT_GROUP_NAME);
		Assert.assertTrue(isTextPresent("Group Name"));
		
		waitForAndGetElement(ELEMENT_INPUT_LABEL);
		Assert.assertTrue(isTextPresent("Label"));
		
		waitForAndGetElement(ELEMENT_TEXTAREA_DESCRIPTION);
		Assert.assertTrue(isTextPresent("Description"));
	
		cancel();
		
		signOut();
	}

}
