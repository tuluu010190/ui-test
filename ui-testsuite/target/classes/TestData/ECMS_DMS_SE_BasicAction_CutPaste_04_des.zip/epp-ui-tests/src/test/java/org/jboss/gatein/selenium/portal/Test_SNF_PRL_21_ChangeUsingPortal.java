package org.jboss.gatein.selenium.portal;

import org.jboss.gatein.selenium.AbstractTestCase;
import org.testng.annotations.Test;

import static org.jboss.gatein.selenium.portal.PortalHelper.*;
import static org.jboss.gatein.selenium.common.CommonHelper.*;

public class Test_SNF_PRL_21_ChangeUsingPortal extends AbstractTestCase {
	
	@Test(groups={"sniff", "epp5.0", "portal"})
	public void testSNF_PRL_21_ChangeUsingPortal() throws Exception {
        
		String portalChangeVerification = "//div[contains (@class, 'BreadcumbsInfoBar')]//a[text()='Home' and contains(@href, 'test_portal_name_21')]";
		
		System.out.println("-ChangePortal-");
		
		openPortal(true);

		signInAsRoot();
		
		goToSite();

		createNewPortal("test_portal_name_21", "English", "Default", "On Demand", true, null, "Platform/Administrators", "*");
		
		verifyPortalExists("test_portal_name_21");

		System.out.println("--View new portal");

		goToSite();

		goToPage(ELEMENT_TEST_USER_ADMIN, ELEMENT_LINK_SITE, "test_portal_name_21");
		
		waitForAndGetElement(portalChangeVerification);

		openPortal(false);

		goToSite();

		deletePortal("test_portal_name_21");

		signOut();
	}
}