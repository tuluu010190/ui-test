package org.jboss.gatein.selenium.navigation;

import org.jboss.gatein.selenium.AbstractTestCase;
import org.testng.annotations.Test;

import static org.jboss.gatein.selenium.common.CommonHelper.*;
import static org.jboss.gatein.selenium.navigation.NavigationHelper.*;

public class Test_POR_14_01_016_CreateNewNodeWithNameIsTheSameWithExistingOneInTheSameLevel extends AbstractTestCase {
	
	@Test(groups={"navigation"})
	public void testPOR_14_01_016_CreateNewNodeWithNameIsTheSameWithExistingOneInTheSameLevel()	throws Exception {
        
		System.out.println("CreateNewNodeWithNameIsTheSameWithExistingOneInTheSameLevel");

		openPortal(true);
		
		signInAsRoot();

		goToSite();
		
		addNewNode("Test_POR_14_01_016", "Test_POR_14_01_016", true, null, null, null, false, true, false, null);
		
		addNewNode("Test_POR_14_01_016", "Test_POR_14_01_016", true, null, null, null, false, false, false, null);

		waitForMessage("This node name already exists.");
		
		closeMessageDialog();
		
		click(ELEMENT_BACK_BUTTON);
		
		waitForTextNotPresent("Page Node Setting");

		save();
		
		waitForTextNotPresent("Navigation Management");

		deleteNodeFromFirstNavigation("Test_POR_14_01_016", null, true);
		
		signOut();
	}

}
