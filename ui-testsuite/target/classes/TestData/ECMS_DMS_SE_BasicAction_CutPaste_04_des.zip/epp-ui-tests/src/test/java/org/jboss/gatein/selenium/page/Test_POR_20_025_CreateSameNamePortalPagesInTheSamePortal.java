package org.jboss.gatein.selenium.page;

import static org.jboss.gatein.selenium.common.CommonHelper.*;
import static org.jboss.gatein.selenium.page.PageHelper.*;

import org.jboss.gatein.selenium.AbstractTestCase;
import org.testng.annotations.Test;

public class Test_POR_20_025_CreateSameNamePortalPagesInTheSamePortal extends AbstractTestCase {
	
	@Test(groups={"epp5.0", "page"})
	public void testPOR_20_025_CreateSameNamePortalPagesInTheSamePortal() throws Exception {
		System.out.println("--CreateSameNamePortalPagesInTheSamePortal--");

		openPortal(true);
		
		signInAsRoot();
		
		goToPageManagement();

		addNewPageAtPageManagement("POR_20_025", "POR_20_025", PageType.PORTAL, null, "portal::classic::POR_20_025");
		
		addNewPageAtPageManagement("POR_20_025", "POR_20_025", PageType.PORTAL, null, null);
		
		waitForMessage("This page name already exists.");
		
		closeMessageDialog();

		cancel();
		
		searchAndDeletePage(PageType.PORTAL, "POR_20_025", "POR_20_025", true, "portal::classic::POR_20_025");
		
		signOut();
	}

}
