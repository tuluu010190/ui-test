package org.jboss.gatein.selenium.page;

import org.jboss.gatein.selenium.AbstractTestCase;
import org.testng.annotations.Test;

import static org.jboss.gatein.selenium.common.CommonHelper.*;
import static org.jboss.gatein.selenium.page.PageHelper.*;
import static org.jboss.gatein.selenium.navigation.NavigationHelper.*;
import static org.jboss.gatein.selenium.applicationregistry.ApplicationRegistryHelper.ELEMENT_CHECKBOX_SHOW_IMPORT_EDIT_MODE;

public class Test_POR_26_03_004_CheckFinishFunctionAfterEditContainerOfNodePage extends AbstractTestCase {
	
	@Test(groups={"page"})
	public void testPOR_26_03_004_CheckFinishFunctionAfterEditContainerOfNodePage() throws Exception {
        
		String adminCategory = ELEMENT_EDIT_PAGE_CATEGORY_MENU.replace("${categoryLabel}", "Administration");
		String appRegPortlet = "//div[@id='Administration/ApplicationRegistryPortlet']/div/div/div[1]/div[1]";
		String accountPortlet = "//div[@id='Administration/AccountPortlet']/div/div/img";
		String drop1 = "//div[@class='UIRowContainer']/div[1]//div[@class='UIRowContainer EmptyContainer']";
		String drop2 = "//div[@class='UIRowContainer']/div[2]//div[@class='UIRowContainer EmptyContainer']";
		String adminNavigation = ELEMENT_EDIT_NAVIGATION.replace("${navigation}", "Administrators");
		String appRegNode = ELEMENT_NODE_LINK.replace("${nodeLabel}", "Application Registry");
		String node = ELEMENT_NODE_LINK.replace("${nodeLabel}", "Test_POR_26_03_004");
        String dragDropVerifAppReg = ELEMENT_EDIT_PAGE_COMPONENT.replace("${portletNumber}", "1") + PORTLET_LABEL.replace("${portletName}", "Application Registry");
        String dragDropVerifNewAcc = ELEMENT_EDIT_PAGE_COMPONENT.replace("${portletNumber}", "2") + PORTLET_LABEL.replace("${portletName}", "New Account");
		
		openPortal(true);
		
		signInAsRoot();
		
		goToApplicationRegistry();
		
		System.out.println("-- Add new page with editor--");
		
		goToAddNewPage();

		type(ELEMENT_INPUT_PAGE_NAME, "Test_POR_26_03_004", true);
        
        uncheck(ELEMENT_CHECKBOX_EXTENDED_LABEL_MODE);

		type(ELEMENT_INPUT_PAGE_DISPLAY_NAME, "Test_POR_26_03_004", true);

		click(ELEMENT_PAGE_EDITOR_NEXT_STEP);
		
		waitForTextPresent("Empty Layout");
		
		click(ELEMENT_PAGE_CONFIGS_MENU);
		
		System.out.println("-- Choose page configs--");
		
		click(ELEMENT_PAGE_CONFIGS_ROW);

		click(ELEMENT_PAGE_EDITOR_NEXT_STEP);
		
		click(adminCategory);

        pause(500);
        
		dragAndDropToObject(appRegPortlet, drop1, dragDropVerifAppReg);

		pause(500);
		
		dragAndDropToObject(accountPortlet, drop2, dragDropVerifNewAcc);
		
		finishPageEdit();

		System.out.println("-- Edit add container--");

		goToGroup();

		click(adminNavigation);

		click(appRegNode);

		contextMenuOnElement(node);
	
		click(ELEMENT_NODE_EDIT_NODE_PAGE);

        editSpecifiedPortletOrContainer("1", true, ELEMENT_CHECKBOX_SHOW_IMPORT_EDIT_MODE);

        click(ELEMENT_PORLET_SETTING_TAB);
        
		type(ELEMENT_INPUT_TITLE, "TEST_POR_26_03_004", true);

		click(ELEMENT_SAVE_AND_CLOSE_BUTTON);

		finishPageEdit();

		save();

		signOut();
		
		signInAsRoot();
		
		goToGroup();
		
		click(adminNavigation);
		
		waitForTextPresent("Navigation Management");
		
		click(appRegNode);
		
		deleteNode("Test_POR_26_03_004", true);
		
		goToPageManagement();
		
		searchAndDeletePage(PageType.GROUP, "page", "Test_POR_26_03_004", true, "Test_POR_26_03_004");

		signOut();
	}

}
