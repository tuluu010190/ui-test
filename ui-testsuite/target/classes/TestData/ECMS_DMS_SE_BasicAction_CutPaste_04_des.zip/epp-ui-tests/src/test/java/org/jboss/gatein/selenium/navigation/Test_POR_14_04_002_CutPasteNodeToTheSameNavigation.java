package org.jboss.gatein.selenium.navigation;

import static org.jboss.gatein.selenium.common.CommonHelper.*;
import static org.jboss.gatein.selenium.navigation.NavigationHelper.*;

import org.jboss.gatein.selenium.AbstractTestCase;
import org.testng.annotations.Test;

public class Test_POR_14_04_002_CutPasteNodeToTheSameNavigation extends AbstractTestCase {
	
	@Test(groups={"navigation"})
	public void testPOR_14_04_002_CutPasteNodeToTheSameNavigation() throws Exception {
       
		String homeNode = ELEMENT_NODE_LINK.replace("${nodeLabel}", "Home");
		
		System.out.println("--CutPasteNodeToTheSameNavigation--");
		
		openPortal(true);
		
		signInAsRoot();
		
		goToSite();
		
		addNewNode("POR_14_04_002", "POR_14_04_002", true, null, null, null, false, true, false, null);
		
		editFirstNavigation();
		
		copyNode(CopyType.CUT, null, "POR_14_04_002", homeNode, null);

		save();
        
        waitForMessage("This node name already exists.");
        closeMessageDialog();
		
		deleteNodeFromFirstNavigation("POR_14_04_002", null, true);
		
		signOut();
	}

}
