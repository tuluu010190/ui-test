package org.jboss.gatein.selenium.usersmanagement;

import org.jboss.gatein.selenium.AbstractTestCase;
import org.testng.annotations.Test;

import static org.jboss.gatein.selenium.common.CommonHelper.*;
import static org.jboss.gatein.selenium.usersmanagement.UsersManagementHelper.*;

public class Test_PRL_04_02_003_AddNewMembershipWithNameLessThan3OrOver30Chars extends AbstractTestCase {
	
	@Test(groups={"usersmanagement","two"})
	public void testPRL_04_02_003_AddNewMembershipWithNameLessThan3OrOver30Chars() throws Exception {
        
		System.out.println("-- Add new membership with name less than 3 or over 30 characters--");

		openPortal(true);
		
		signInAsRoot();
		
		goToUsersAndGroupsManagement();
		
		chooseMembershipTab();

		addNewMembership("PL", "Test_PLT_04_02_003", false);
		
		waitForMessage("The length of the text in field \"Membership name\" must be between \"3\" and \"30\" characters.");
		closeMessageDialog();
		
		addNewMembership("Test_PLT_04_02_003 Test_PLT_04_02_003 Test_PLT_04_02_003 Test_PLT_04_02_003 Test_PLT_04_02_003 Test_PLT_04_02_003", "Test_PLT_04_02_003", false);
		
		waitForMessage("The length of the text in field \"Membership name\" must be between \"3\" and \"30\" characters.");
		closeMessageDialog();
		
		signOut();
	}

}
