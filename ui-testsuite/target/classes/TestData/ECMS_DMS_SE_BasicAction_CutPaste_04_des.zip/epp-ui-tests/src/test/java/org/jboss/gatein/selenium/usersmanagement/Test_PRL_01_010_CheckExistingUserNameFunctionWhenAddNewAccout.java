package org.jboss.gatein.selenium.usersmanagement;

import org.jboss.gatein.selenium.AbstractTestCase;
import org.testng.annotations.Test;

import static org.jboss.gatein.selenium.common.CommonHelper.*;
import static org.jboss.gatein.selenium.usersmanagement.UsersManagementHelper.*;

public class Test_PRL_01_010_CheckExistingUserNameFunctionWhenAddNewAccout extends AbstractTestCase {
	
	@Test(groups={"usersmanagement","one"})
	public void testPRL_01_010_CheckExistingUserNameFunctionWhenAddNewAccout() throws Exception {
        
		System.out.println("-- Check existing user name function when add new account--");

		openPortal(true);
		
		signInAsRoot();
		
		goToNewStaff();

		addNewAccountAtNewStaff("test_prl_01_010", "Test_PRL_01_010", "Test_PRL_01_010", "Test_PRL_01_010", "Test_PRL_01_010", "Test_PRL_01_010@localhost.com", "", "English", true);
		
		System.out.println("-- Check Availability function when new account's user name is existing--");
		
		type(ELEMENT_INPUT_USERNAME, "test_prl_01_010", true);

		click(ELEMENT_SEARCH_ICON_REGISTER);
		
		waitForMessage("This user name already exists, please enter a different name.");
		closeMessageDialog();

		System.out.println("-- Check Availability function when new account's user name does not exist--");
		
		type(ELEMENT_INPUT_USERNAME, "test", true);

		click(ELEMENT_SEARCH_ICON_REGISTER);
		
		waitForMessage("This user name is available.");
		closeMessageDialog();

		goToUsersAndGroupsManagement();
		
		deleteUser("test_prl_01_010");
		
		goToNewStaff();
		
		System.out.println("-- Check Availability function when new account's user name is the same with deleted account's user name--");
		
		type(ELEMENT_INPUT_USERNAME, "test_prl_01_010", true);

		click(ELEMENT_SEARCH_ICON_REGISTER);
		
		waitForMessage("This user name is available.");
		closeMessageDialog();

		System.out.println("-- Check Availability function when new account's user name is blank--");
		
		type(ELEMENT_INPUT_USERNAME, "", true);

		click(ELEMENT_SEARCH_ICON_REGISTER);
		
		waitForMessage("The user name cannot be empty.");
		closeMessageDialog();

		signOut();
	}

}
