package org.jboss.gatein.selenium.page;

import org.jboss.gatein.selenium.AbstractTestCase;
import org.testng.annotations.Test;

import static org.jboss.gatein.selenium.common.CommonHelper.*;
import static org.jboss.gatein.selenium.page.PageHelper.*;
import static org.jboss.gatein.selenium.permission.PermissionHelper.*;

public class Test_POR_22_019_ChangeEditRightOnPortalPageWhileEditingPortalPageProperties extends AbstractTestCase {

	@Test(groups={"epp5.0", "page"})
	public void testPOR_22_019_ChangeEditRightOnPortalPageWhileEditingPortalPageProperties() throws Exception {
        
		String pageEditIcon = ELEMENT_PAGE_EDIT_ICON.replace("${page}", "Test_POR_22_019");
		
		System.out.println("--ChangeEditRightOnPortalPageWhileEditingPortalPageProperties--");

		openPortal(true);
		
		signInAsRoot();
		
		goToPageManagement();
		
		addNewPageAtPageManagement("Test_POR_22_019", "Test_POR_22_019", PageType.PORTAL, null, "portal::classic::Test_POR_22_019");
		
		searchPageByTitle(PageType.PORTAL, "Test_POR_22_019", "portal::classic::Test_POR_22_019");
		
		System.out.println("-- Edit this page--");

		click(pageEditIcon);

		System.out.println("-- Go to editing portal page's properties--");

		click(ELEMENT_VIEW_PAGE_PROPERTIES);
		
		System.out.println("--Choose Permission Setting tab--");

		click(ELEMENT_PERMISSION_SETTING_TAB);
		
		System.out.println("--Choose Edit Permission Setting--");
		
		click(ELEMENT_LINK_EDIT_PERMISSION);
		
		setEditPermissions("Platform/Administrators", "manager");
		
		save();
		
		System.out.println("--Click Finish--");

		finishPageEdit();
		
		System.out.println("--Delete page--");

		deletePage(PageType.PORTAL, "Test_POR_22_019", "Test_POR_22_019", true, "portal::classic::Test_POR_22_019");
		
		signOut();
	}

}
