package org.jboss.gatein.selenium.portal;

import static org.jboss.gatein.selenium.common.CommonHelper.*;
import static org.jboss.gatein.selenium.portal.PortalHelper.*;

import org.jboss.gatein.selenium.AbstractTestCase;
import org.testng.annotations.Test;

public class Test_POR_09_009_CreateNewPortalWithPortalNameTheSameWithExistingButDifferentByLowerAndUpperCase extends AbstractTestCase {
	
	// failing for mssql, sybase15.5 - JBEPP-334, JBEPP-1359, excluded at testng-upper_lower-case.xml
	@Test(groups={"epp5.0", "portal"})
	public void testPOR_09_009_CreateNewPortalWithPortalNameTheSameWithExistingButDifferentByLowerAndUpperCase() throws Exception {
		System.out.println("--Create new portal with lower case--");
		
		openPortal(true);

		signInAsRoot();

		goToSite();

		createNewPortal("test_por_09_009", "English", "Default", "On Demand", true, null, "Platform/Administrators", "*");
		
		verifyPortalExists("test_por_09_009");
		
		System.out.println("-- Add new portal with name is the same with existing one but different with existing by upper case --");
		
		createNewPortal("Test_POR_09_009", "English", "Default", "On Demand", true, null, "Platform/Administrators", "*");
		
		verifyPortalExists("Test_POR_09_009");

		System.out.println("--Delete portal with name is lower case--");
		
		deletePortal("test_por_09_009");
		
		System.out.println("--Delete portal with name is upper case--");
		
		deletePortal("Test_POR_09_009");

		signOut();
	}

}
