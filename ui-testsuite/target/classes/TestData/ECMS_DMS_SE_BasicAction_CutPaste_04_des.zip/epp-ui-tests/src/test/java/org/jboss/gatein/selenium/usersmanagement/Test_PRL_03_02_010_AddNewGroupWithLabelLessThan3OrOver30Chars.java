package org.jboss.gatein.selenium.usersmanagement;

import org.jboss.gatein.selenium.AbstractTestCase;
import org.testng.annotations.Test;

import static org.jboss.gatein.selenium.common.CommonHelper.*;
import static org.jboss.gatein.selenium.usersmanagement.UsersManagementHelper.*;

public class Test_PRL_03_02_010_AddNewGroupWithLabelLessThan3OrOver30Chars extends AbstractTestCase {
	
	@Test(groups={"usersmanagement","two"})
	public void testPRL_03_02_010_AddNewGroupWithLabelLessThan3OrOver30Chars() throws Exception {
        
		System.out.println("-- Add new group with label less than 3 or over 30 characters--");

		openPortal(true);
		
		signInAsRoot();
		
		goToUsersAndGroupsManagement();
		
		chooseGroupTab();
		
		addNewGroup("Test_PRL_03_02_010", "PR", "Test_PRL_03_02_010", false);
		
		waitForMessage("The length of the text in field \"Label\" must be between \"3\" and \"30\" characters.");
		closeMessageDialog();
	
		cancel();
		
		System.out.println("-- Add new group with label over 30 characters--");
		
		addNewGroup("Test_PRL_03_02_010", "Test_PRL_03_02_010 Test_PRL_03_02_010 Test_PRL_03_02_010 Test_PRL_03_02_010", "Test_PRL_03_02_010", false);
		
		waitForMessage("The length of the text in field \"Label\" must be between \"3\" and \"30\" characters.");
		closeMessageDialog();
	
		cancel();
		
		signOut();
	}

}
