package org.jboss.gatein.selenium.usersmanagement;

import org.jboss.gatein.selenium.AbstractTestCase;
import org.testng.annotations.Test;

import static org.jboss.gatein.selenium.common.CommonHelper.*;
import static org.jboss.gatein.selenium.usersmanagement.UsersManagementHelper.*;

public class Test_PRL_02_02_003_SearchWithCompletedWordWhenSearchingKeywordsMatchesExistingUsers extends AbstractTestCase {
	
	@Test(groups={"usersmanagement","one"})
	public void testPRL_02_02_003_SearchWithCompletedWordWhenSearchingKeywordsMatchesExistingUsers() throws Exception {
        
		System.out.println("-- Search with completed word when searching keyword matches existing user(s)--");

		openPortal(true);
		
		signInAsJohn();
		
		goToUsersAndGroupsManagement();
		
		System.out.println("-- Input completed word into Search text box that matches existing users--");
		
		searchUserByUserName("root");
		
		waitForTextPresent("root");
		
		signOut();
	}

}
