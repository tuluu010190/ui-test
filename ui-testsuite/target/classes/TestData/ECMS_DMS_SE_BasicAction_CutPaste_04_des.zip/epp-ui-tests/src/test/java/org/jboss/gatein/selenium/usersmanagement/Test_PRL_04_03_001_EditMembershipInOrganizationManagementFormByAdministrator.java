package org.jboss.gatein.selenium.usersmanagement;

import org.jboss.gatein.selenium.AbstractTestCase;
import org.testng.annotations.Test;

import static org.jboss.gatein.selenium.common.CommonHelper.*;
import static org.jboss.gatein.selenium.usersmanagement.UsersManagementHelper.*;

public class Test_PRL_04_03_001_EditMembershipInOrganizationManagementFormByAdministrator extends AbstractTestCase {

	@Test(groups={"usersmanagement","two"})
	public void testPRL_04_03_001_EditMembershipInOrganizationManagementFormByAdministrator() throws Exception {
        
		System.out.println("-- Edit Membership in Organization  Management form by  Administrator--");
		
		openPortal(true);
		
		signInAsRoot();
		
		goToUsersAndGroupsManagement();

		System.out.println("-- Add new membership--");

		chooseMembershipTab();
		
		addNewMembership("Test_PRL_04_03_001", "Test_PRL_04_03_001", true);
		
		editMembership("Test_PRL_04_03_001", "Test_PRL_04_03_001_edit");
		
		deleteMembership("Test_PRL_04_03_001", true);
		
		signOut();
	}

}
