package org.jboss.gatein.selenium.page;

import org.jboss.gatein.selenium.AbstractTestCase;
import org.testng.annotations.Test;

import static org.jboss.gatein.selenium.common.CommonHelper.*;
import static org.jboss.gatein.selenium.page.PageHelper.*;

public class Test_POR_20_028_CreateNewPortalPageWithNameIsTheSameWithExistingGroupPage extends AbstractTestCase {
	
	@Test(groups={"epp5.0", "page"})
	public void testPOR_20_028_CreateNewPortalPageWithNameIsTheSameWithExistingGroupPage() throws Exception {
        
		System.out.println("--CreateNewPortalPageWithNameIsTheSameWithExistingGroupPage--");

		openPortal(true);
		
		signInAsRoot();
		
		goToPageManagement();
		
		addNewPageAtPageManagement("POR_20_028", "POR_20_028", PageType.PORTAL, null, "portal::classic::POR_20_028");
		
		addNewPageAtPageManagement("POR_20_028", "POR_20_028", PageType.GROUP, "/organization/operations", "group::/organization/operations::POR_20_028");
		
		searchAndDeletePage(PageType.GROUP, "POR_20_028", "POR_20_028", true, "group::/organization/operations::POR_20_028");
		
		searchAndDeletePage(PageType.PORTAL, "POR_20_028", "POR_20_028", true, "portal::classic::POR_20_028");
		
		signOut();
	}

}
