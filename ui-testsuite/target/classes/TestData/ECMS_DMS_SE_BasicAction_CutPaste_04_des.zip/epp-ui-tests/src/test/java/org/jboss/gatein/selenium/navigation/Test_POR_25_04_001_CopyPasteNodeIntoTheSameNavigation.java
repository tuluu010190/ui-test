package org.jboss.gatein.selenium.navigation;

import org.jboss.gatein.selenium.AbstractTestCase;
import org.testng.annotations.Test;

import static org.jboss.gatein.selenium.common.CommonHelper.*;
import static org.jboss.gatein.selenium.navigation.NavigationHelper.*;

public class Test_POR_25_04_001_CopyPasteNodeIntoTheSameNavigation extends AbstractTestCase {
	
	@Test(groups={"epp5.0", "navigation"})
	public void testPOR_25_04_001_CopyPasteNodeIntoTheSameNavigation() throws Exception {
        
        String organizationNode = ELEMENT_NODE_LINK.replace("${nodeLabel}", "Organization");
		
		System.out.println("--CopyPasteNodeIntoTheSameNavigation--");
		
		openPortal(true);
		
		signInAsRoot();

		goToGroup();

		editNavigation("Executive Board");
		
		copyNode(CopyType.COPY, null, "New Staff", ELEMENT_NAVIGATION_HOME_NODE, null);

		save();
		
		waitForTextNotPresent("Navigation Management");
		
		editNavigation("Executive Board");
		
		click(organizationNode);
		
		deleteNode("New Staff", false);
		
		signOut();
	}

}
