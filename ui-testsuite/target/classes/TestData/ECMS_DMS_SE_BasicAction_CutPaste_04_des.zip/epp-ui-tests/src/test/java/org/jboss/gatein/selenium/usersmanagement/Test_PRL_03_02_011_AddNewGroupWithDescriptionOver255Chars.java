package org.jboss.gatein.selenium.usersmanagement;

import org.jboss.gatein.selenium.AbstractTestCase;
import org.testng.annotations.Test;

import static org.jboss.gatein.selenium.common.CommonHelper.*;
import static org.jboss.gatein.selenium.usersmanagement.UsersManagementHelper.*;

public class Test_PRL_03_02_011_AddNewGroupWithDescriptionOver255Chars extends AbstractTestCase {
	
	@Test(groups={"usersmanagement","two"})
	public void testPRL_03_02_011_AddNewGroupWithDescriptionOver255Chars() throws Exception {
        
		System.out.println("-- Add new group with Description over 255 characters--");

		openPortal(true);
		
		signInAsRoot();
		
		goToUsersAndGroupsManagement();
		
		chooseGroupTab();
		
		addNewGroup("Test_PRL_03_02_011", "Test_PRL_03_02_011", "Test_PRL_03_02_011 Test_PRL_03_02_011 Test_PRL_03_02_011 Test_PRL_03_02_011 Test_PRL_03_02_011 Test_PRL_03_02_011 Test_PRL_03_02_011 Test_PRL_03_02_011 Test_PRL_03_02_011 Test_PRL_03_02_011 Test_PRL_03_02_011 Test_PRL_03_02_011 Test_PRL_03_02_011 Test_PRL_03_02_011 Test_PRL_03_02_011 Test_PRL_03_02_011", false);
		
		waitForMessage("The length of the text in field \"Description\" must be between \"0\" and \"255\" characters.");
		closeMessageDialog();	
	
		cancel();
		
		signOut();
	}

}
