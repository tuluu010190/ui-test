package org.jboss.gatein.selenium.usersmanagement;

import org.jboss.gatein.selenium.AbstractTestCase;
import org.testng.annotations.Test;

import static org.jboss.gatein.selenium.common.CommonHelper.*;
import static org.jboss.gatein.selenium.usersmanagement.UsersManagementHelper.*;

public class Test_PRL_04_02_001_AddNewBlankNameMembershipInMembershjpManagement extends AbstractTestCase {
	
	@Test(groups={"usersmanagement","two"})
	public void testPRL_04_02_001_AddNewBlankNameMembershipInMembershjpManagement() throws Exception {
        
		System.out.println("-- Add new blank name membership in Membership Management--");
		
		openPortal(true);
		
		signInAsRoot();
		
		goToUsersAndGroupsManagement();
		
		chooseMembershipTab();

		addNewMembership("", "Test_PRL_04_02_001", false);
		
		waitForMessage("The field \"Membership name\" is required.");
		closeMessageDialog();
		
		signOut();
	}

}
