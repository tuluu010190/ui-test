package org.jboss.gatein.selenium.usersmanagement;

import org.jboss.gatein.selenium.AbstractTestCase;
import org.testng.annotations.Test;

import static org.jboss.gatein.selenium.common.CommonHelper.*;
import static org.jboss.gatein.selenium.usersmanagement.UsersManagementHelper.*;

public class Test_PRL_01_021_CreateNewAccountWithFirstLastNameIncludesSpecialCharacters extends AbstractTestCase {
	
	@Test(groups={"usersmanagement","one"})
	public void testPRL_01_021_CreateNewAccountWithFirstLastNameIncludesSpecialCharacters()	throws Exception {
        
		System.out.println("-- Create new account with First/Last Name includes special characters --");
		
		openPortal(true);
		
		signInAsRoot();
		
		goToNewStaff();

		addNewAccountAtNewStaff("test_prl_01_021", "Test_PRL_01_021", "Test_PRL_01_021", "#$%^#", "(**()^$#", "Test_PRL_01_021@localhost.com", "", "English", true);
	
		signOut();
		
		signIn("test_prl_01_021", "Test_PRL_01_021");
		
		signOut();
		
		signInAsRoot();
		
		goToUsersAndGroupsManagement();
		
		deleteUser("test_prl_01_021");
		
		signOut();
	}

}
