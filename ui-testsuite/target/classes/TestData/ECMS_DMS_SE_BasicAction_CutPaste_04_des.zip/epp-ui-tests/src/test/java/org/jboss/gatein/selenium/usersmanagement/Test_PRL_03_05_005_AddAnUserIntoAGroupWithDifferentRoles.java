package org.jboss.gatein.selenium.usersmanagement;

import static org.jboss.gatein.selenium.common.CommonHelper.*;
import static org.jboss.gatein.selenium.usersmanagement.UsersManagementHelper.*;

import org.jboss.gatein.selenium.AbstractTestCase;
import org.testng.annotations.Test;

public class Test_PRL_03_05_005_AddAnUserIntoAGroupWithDifferentRoles extends AbstractTestCase {
	
	@Test(groups={"usersmanagement","two"})
	public void testPRL_03_05_005_AddAnUserIntoAGroupWithDifferentRoles() throws Exception {
        
		System.out.println("-- Add an user into a group with different roles--");
		
		openPortal(true);
		
		signInAsRoot();
		
		goToUsersAndGroupsManagement();
		
		chooseGroupTab();
		
		selectGroup("Customers");
		
		addUsersAtGroup("root", "manager", true, true);
		
		addUsersAtGroup("root", "validator", true, true);
		
		deleteUserFromGroup("root", "manager", "customers", false);
		
		deleteUserFromGroup("root", "validator", "customers", false);

		signOut();
	}

}
