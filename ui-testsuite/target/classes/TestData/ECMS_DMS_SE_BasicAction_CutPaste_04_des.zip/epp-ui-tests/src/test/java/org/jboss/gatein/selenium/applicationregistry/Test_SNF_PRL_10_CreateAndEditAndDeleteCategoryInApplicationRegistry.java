package org.jboss.gatein.selenium.applicationregistry;

import java.util.HashMap;
import java.util.Map;

import org.jboss.gatein.selenium.AbstractTestCase;
import org.testng.annotations.Test;

import static org.jboss.gatein.selenium.applicationregistry.ApplicationRegistryHelper.*;
import static org.jboss.gatein.selenium.common.CommonHelper.*;

public class Test_SNF_PRL_10_CreateAndEditAndDeleteCategoryInApplicationRegistry extends AbstractTestCase {
	
	@Test(groups={"sniff", "epp5.0", "applicationregistry"})
	public void testSNF_PRL_10_CreateAndEditAndDeleteCategoryInApplicationRegistry() throws Exception {
		System.out.println("--CategoryManagement--");

		openPortal(true);

		signInAsRoot();
		
		goToApplicationRegistry();

		Map<String, String> permissions = new HashMap<String, String>();
		permissions.put("Platform/Administrators", "member");
		addNewCategory("test_name_category_10", "test_displayname_category_10", "test_description_category_10", false, permissions, true);

		editCategory("test_displayname_category_10", "test_displayname_edit_10", "test_description_edit_10");
		
		deleteCategory("test_displayname_edit_10");

		signOut();
	}

}
