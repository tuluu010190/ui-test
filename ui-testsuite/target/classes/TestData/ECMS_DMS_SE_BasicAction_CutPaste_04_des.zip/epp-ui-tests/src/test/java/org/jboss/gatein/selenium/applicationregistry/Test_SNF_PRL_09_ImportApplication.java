package org.jboss.gatein.selenium.applicationregistry;

import static org.jboss.gatein.selenium.applicationregistry.ApplicationRegistryHelper.*;
import static org.jboss.gatein.selenium.common.CommonHelper.*;

import org.jboss.gatein.selenium.AbstractTestCase;
import org.testng.annotations.Test;


public class Test_SNF_PRL_09_ImportApplication extends AbstractTestCase {
	
	@Test(groups={"sniff", "epp5.0", "applicationregistry"})
	public void testSNF_PRL_09_ImportApplication() throws Exception {
		System.out.println("--Import Application--");
		
		openPortal(true);

		signInAsRoot();

		goToApplicationRegistry();

		autoImportApplications();
        
		signOut();
	}

}
