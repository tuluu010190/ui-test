package org.jboss.gatein.selenium.usersmanagement;

import static org.jboss.gatein.selenium.common.CommonHelper.*;
import static org.jboss.gatein.selenium.usersmanagement.UsersManagementHelper.*;

import org.jboss.gatein.selenium.AbstractTestCase;
import org.testng.annotations.Test;

public class Test_PRL_03_02_002_AddNewGroupWithBlankRequireFields extends AbstractTestCase {
	
	@Test(groups={"usersmanagement","two"})
	public void testPRL_03_02_002_AddNewGroupWithBlankRequireFields() throws Exception {
        
		System.out.println("-- Add new group with blank required fields--");

		openPortal(true);
		
		signInAsRoot();

		goToUsersAndGroupsManagement();
		
		chooseGroupTab();
		
		addNewGroup("", "Test_PRL_03_02_002", "Test_PRL_03_02_002", false);
		
		waitForMessage("The field \"Group Name\" is required.");
		closeMessageDialog();
		
		cancel();

		signOut();
	}

}
