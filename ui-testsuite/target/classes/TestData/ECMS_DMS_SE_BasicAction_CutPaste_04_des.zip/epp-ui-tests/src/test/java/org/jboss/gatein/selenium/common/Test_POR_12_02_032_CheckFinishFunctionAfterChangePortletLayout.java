package org.jboss.gatein.selenium.common;

import org.jboss.gatein.selenium.AbstractTestCase;
import org.testng.annotations.Test;

import static org.jboss.gatein.selenium.common.CommonHelper.*;
import static org.jboss.gatein.selenium.page.PageHelper.*;

public class Test_POR_12_02_032_CheckFinishFunctionAfterChangePortletLayout extends AbstractTestCase {
	
	@Test(groups={"common"})
	public void testPOR_12_02_032_CheckFinishFunctionAfterChangePortletLayout()	throws Exception {
        
		String administrationInEditLayout = ELEMENT_EDIT_PAGE_CATEGORY_MENU.replace("${categoryLabel}", "Administration");
		String appRegistryPortlet = "//div[@id='Administration/ApplicationRegistryPortlet']/div/div/img";
		String appRegistryDropElement = "//div[contains(@class, 'UIPortlet')][2]";
        String dragAndDropVerification = ELEMENT_EDIT_PAGE_COMPONENT.replace("${portletNumber}", "2") + PORTLET_LABEL.replace("${portletName}", "Application Registry");
		
		openPortal(true);
		
		signInAsRoot();
		
		goToSite();
		
		click(ELEMENT_EDIT_LAYOUT_FROM_TABLE_FIRST);
		
		waitForTextPresent("Edit Inline Composer");
		
		System.out.println("--Change current portal's portlet layout--");
		
		click(administrationInEditLayout);

		dragAndDropToObject(appRegistryPortlet, appRegistryDropElement, dragAndDropVerification);

		click(ELEMENT_EDIT_LAYOUT_FINISH_BUTTON);
		
		System.out.println("--Return to Default layout--");
		
		click(ELEMENT_EDIT_LAYOUT_FROM_TABLE_FIRST);

		deleteSpecifiedPortletOrContainer(ContainerType.PORTLET, "2", false);
		
		click(ELEMENT_EDIT_LAYOUT_FINISH_BUTTON);
		
		signOut();
	}

}
