package org.jboss.gatein.selenium.applicationregistry;

import java.util.HashMap;
import java.util.Map;

import org.jboss.gatein.selenium.AbstractTestCase;
import org.testng.Assert;
import org.testng.annotations.Test;

import static org.jboss.gatein.selenium.applicationregistry.ApplicationRegistryHelper.*;
import static org.jboss.gatein.selenium.common.CommonHelper.*;
import static org.jboss.gatein.selenium.permission.PermissionHelper.*;

public class Test_SNF_PRL_11_AddApplicationIntoCategory extends AbstractTestCase {
	
	@Test(groups={"sniff", "epp5.0", "applicationregistry"})
	public void testSNF_PRL_11_AddApplicationIntoCategory() throws Exception {
		System.out.println("--AddApplicationToCategory--");
		
		openPortal(true);

		signInAsRoot();

		goToApplicationRegistry();
		
		Map<String, String> permissions = new HashMap<String, String>();
		permissions.put("Platform/Administrators", "manager");
		addNewCategory("Test_cat_11", "Test_cat_11", "", false, permissions, true);
		
		addApplicationToCategory("Test_cat_11", PortletType.PORTLET, "Register Portlet", "test_displayname_11");
		
		Assert.assertTrue(isSelected(ELEMENT_CHECKBOX_PUBLIC_MODE));
		
		deleteApplicationFromCategory("Test_cat_11", "test_displayname_11");
		
        if (ieFlag) {
            pause(500);
        }
        
		deleteCategory("Test_cat_11");

		signOut();
	}

}
