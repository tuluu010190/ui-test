package org.jboss.gatein.selenium.page;

import org.jboss.gatein.selenium.AbstractTestCase;
import org.testng.annotations.Test;

import static org.jboss.gatein.selenium.common.CommonHelper.*;
import static org.jboss.gatein.selenium.page.PageHelper.*;
import static org.jboss.gatein.selenium.permission.PermissionHelper.*;

public class Test_POR_20_023_CreateNewPageForGroupWithValidValues extends AbstractTestCase {

	@Test(groups={"epp5.0", "page"})
	public void testPOR_20_023_CreateNewPageForGroupWithValidValues() throws Exception {
        
		String pageEditIcon = ELEMENT_PAGE_EDIT_ICON.replace("${page}", "POR_20_023");
		
		System.out.println("--CreateNewPageForGroupWithValidValues--");

		openPortal(true);

		signInAsRoot();

		goToPageManagement();
		
		addNewPageAtPageManagement("POR_20_023", "POR_20_023", PageType.GROUP, "/organization/operations", "group::/organization/operations::POR_20_023");
		
		searchPageByTitle(PageType.GROUP, "POR_20_023", "group::/organization/operations::POR_20_023");

		System.out.println("--Edit page--");

		click(pageEditIcon);

		System.out.println("--View page properties--");

		click(ELEMENT_VIEW_PAGE_PROPERTIES);
		
		waitForTextPresent("Page Id");
		
		System.out.println("--Choose Permission setting tab--");

		click(ELEMENT_PERMISSION_SETTING_TAB);
		
		waitForTextPresent("Make it public");

		setViewPermissions("Platform/Administrators", "member");
		
		click(ELEMENT_LINK_EDIT_PERMISSION);

		click(ELELENT_LINK_DELETE_PERMISSION);
		
		setEditPermissions("Platform/Administrators", "member");
		
		System.out.println("--Save after edit page--");

		save();

		waitForTextNotPresent("Page Setting");
		
		System.out.println("--Finish all action--");

        finishPageEdit();

		System.out.println("--Delete page of group--");

		deletePage(PageType.GROUP, "POR_20_023", "POR_20_023", true, "group::/organization/operations::POR_20_023");
		
		signOut();
	}
}
