package org.jboss.gatein.selenium.usersmanagement;

import org.jboss.gatein.selenium.AbstractTestCase;
import org.testng.annotations.Test;

import static org.jboss.gatein.selenium.common.CommonHelper.*;
import static org.jboss.gatein.selenium.usersmanagement.UsersManagementHelper.*;

public class Test_SNFN_PRL_66_ChangeUserProfile extends AbstractTestCase {
	
	@Test(groups={"sniff", "usersmanagement","one"})
	public void testSNFN_PRL_66_ChangeUserProfile() throws Exception {
        
		String signedUserLink = ELEMENT_SIGNED_USER_LINK.replace("${name}", "Test SNF PRL").replace("${surname}", "Test SNF PRL");
		String signedUserEditedLink = ELEMENT_SIGNED_USER_LINK.replace("${name}", "Test SNF PRL 66 edit").replace("${surname}", "Test SNF PRL 66 edit");
		
		System.out.println("-- Change User Profile--");
		
		openPortal(true);
		
		signInAsRoot();
		
		goToNewStaff();
		
		addNewAccountAtNewStaff("test_snf_prl_66", "Test_SNF_PRL_66", "Test_SNF_PRL_66", "Test SNF PRL", "Test SNF PRL", "Test_SNF_PRL_66@localhost.com", "", "English", true);
		
		signOut();
		
		signIn("test_snf_prl_66", "Test_SNF_PRL_66");
		
		click(signedUserLink);

		type(ELEMENT_INPUT_FIRSTNAME, "Test SNF PRL edit", true);

		type(ELEMENT_INPUT_LASTNAME, "Test SNF PRL edit", true);
        
        type(ELEMENT_INPUT_DISPLAYNAME, "Test SNF PRL 66 edit Test SNF PRL 66 edit", true);

		save();

		waitForMessage("The account information has been updated.");
		
		closeMessageDialog();
		
		close();

		waitForTextPresent("Test SNF PRL 66 edit Test SNF PRL 66 edit");
		
		signOut();
		
		System.out.println("--Return to original values--");
		
		signIn("test_snf_prl_66", "Test_SNF_PRL_66");
		
		click(signedUserEditedLink);

		type(ELEMENT_INPUT_FIRSTNAME, "Test SNF PRL 66", true);

		type(ELEMENT_INPUT_LASTNAME, "Test SNF PRL 66", true);
        
        type(ELEMENT_INPUT_DISPLAYNAME, "Test_SNF_PRL_66 Test_SNF_PRL_66", true);

		save();

		waitForMessage("The account information has been updated.");
		
		closeMessageDialog();
		
		close();

		waitForTextPresent("Test_SNF_PRL_66 Test_SNF_PRL_66");
		
		signOut();
		
		signInAsRoot();
		
		goToUsersAndGroupsManagement();
		
		deleteUser("test_snf_prl_66");
		
		signOut();
	}
}
