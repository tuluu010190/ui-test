package org.jboss.gatein.selenium.language;

import static org.jboss.gatein.selenium.common.CommonHelper.*;
import static org.jboss.gatein.selenium.language.LanguageHelper.*;

import org.jboss.gatein.selenium.AbstractTestCase;
import org.testng.annotations.Test;

public class Test_POR_07_002_ChangeLanguage extends AbstractTestCase {
	
	@Test(groups={"epp5.0", "language"})
	public void testPOR_07_002_ChangeLanguage() throws Exception {
		System.out.println("-ChangeLanguagePrivateMode-");
		
		openPortal(true);

		signInAsRoot();
		
		changeLanguage(LANGUAGE_FRENCH);

		System.out.println("--Verify--");

		waitForTextPresent(HOME_LABEL_FRENCH);

		signOut();
		
		System.out.println("--Sign in again to change language to English--");

		signInAsRoot();
		
		waitForTextPresent(HOME_LABEL_FRENCH);

		changeLanguage(LANGUAGE_ENGLISH);
		
		goToSiteClassicHome();

		signOut();
	}

}
