package org.jboss.gatein.selenium.usersmanagement;

import org.jboss.gatein.selenium.AbstractTestCase;
import org.testng.annotations.Test;

import static org.jboss.gatein.selenium.common.CommonHelper.*;
import static org.jboss.gatein.selenium.usersmanagement.UsersManagementHelper.*;

public class Test_PRL_03_05_002_AddUnAvaibaleUserIntoGroup extends AbstractTestCase {
		
	@Test(groups={"usersmanagement","two"})
	public void testPRL_03_05_002_AddUnAvaibaleUserIntoGroup() throws Exception {
        
		System.out.println("-- Add un-available user into group--");
		
		openPortal(true);
		
		signInAsRoot();
		
		goToUsersAndGroupsManagement();
		
		chooseGroupTab();
		
		selectGroup("Customers");
		
		type(ELEMENT_INPUT_USERNAME, "test_prl_03_05_002", true);

		save();

		waitForMessage("User \"test_prl_03_05_002\" doesn't exist.");
		closeMessageDialog();
		
		signOut();
	}

}
