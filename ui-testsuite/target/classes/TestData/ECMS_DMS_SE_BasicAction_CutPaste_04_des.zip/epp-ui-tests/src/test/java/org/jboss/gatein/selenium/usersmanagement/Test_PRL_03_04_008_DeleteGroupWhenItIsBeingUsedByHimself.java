package org.jboss.gatein.selenium.usersmanagement;

import org.jboss.gatein.selenium.AbstractTestCase;
import org.testng.annotations.Test;

import static org.jboss.gatein.selenium.common.CommonHelper.*;
import static org.jboss.gatein.selenium.usersmanagement.UsersManagementHelper.*;

public class Test_PRL_03_04_008_DeleteGroupWhenItIsBeingUsedByHimself extends AbstractTestCase {
	
	@Test(groups={"usersmanagement","two"})
	public void testPRL_03_04_008_DeleteGroupWhenItIsBeingUsedByHimself() throws Exception {
        
		System.out.println("-- Delete group when it is being used by himself--");

		openPortal(true);
		
		signInAsRoot();
		
		goToUsersAndGroupsManagement();
		
		chooseGroupTab();
		
		addNewGroup("Test_PRL_03_04_008", "Test_PRL_03_04_008", "Test_PRL_03_04_008", true);
		
		click(ELEMENT_GROUP_EDIT_SELECTED);
		
		waitForAndGetElement(ELEMENT_INPUT_GROUP_NAME);
		
		System.out.println("-- Delete this group when it is being used --");

		deleteGroup("Test_PRL_03_04_008", false);
		
		waitForMessage("You can't delete this group because it is being used by an other program.");
		closeMessageDialog();
		
		cancel();
		
		deleteGroup("Test_PRL_03_04_008", true);
		
		signOut();
	}

}
