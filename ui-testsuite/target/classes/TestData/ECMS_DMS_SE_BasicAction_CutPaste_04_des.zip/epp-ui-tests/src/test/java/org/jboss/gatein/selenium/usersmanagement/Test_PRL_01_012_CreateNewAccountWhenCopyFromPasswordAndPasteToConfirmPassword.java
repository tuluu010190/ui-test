package org.jboss.gatein.selenium.usersmanagement;

import static org.jboss.gatein.selenium.common.CommonHelper.*;
import static org.jboss.gatein.selenium.usersmanagement.UsersManagementHelper.*;

import org.jboss.gatein.selenium.AbstractTestCase;
import org.testng.annotations.Test;

public class Test_PRL_01_012_CreateNewAccountWhenCopyFromPasswordAndPasteToConfirmPassword extends AbstractTestCase {
	
	private final String CONFIRM_PASSWORD_COPIED_VALUE = getMessage("passwordconfirm.copiedvalue");
	
	@Test(groups={"usersmanagement","one"})
	public void testPRL_01_012_CreateNewAccountWhenCopyFromPasswordAndPasteToConfirmPassword() throws Exception {
        
		System.out.println("--Add new user when copy from Password and paste to Confirm Password field--");

		openPortal(true);
		
		signInAsRoot();
		
		goToNewStaff();

		addNewAccountAtNewStaff("test_prl_01_012", "Test_PRL_01_012", CONFIRM_PASSWORD_COPIED_VALUE, "Test_PRL_01_012", "Test_PRL_01_012", "Test_PRL_01_012@localhost.com", "", "English", false);
		
		waitForMessage("Password and Confirm Password must be the same.");
		closeMessageDialog();
		
		signOut();
	}

}
