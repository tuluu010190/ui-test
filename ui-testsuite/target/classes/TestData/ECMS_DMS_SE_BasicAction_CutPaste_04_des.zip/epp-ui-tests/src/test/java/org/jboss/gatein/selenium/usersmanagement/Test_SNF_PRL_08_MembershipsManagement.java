package org.jboss.gatein.selenium.usersmanagement;

import static org.jboss.gatein.selenium.common.CommonHelper.*;
import static org.jboss.gatein.selenium.usersmanagement.UsersManagementHelper.*;

import org.jboss.gatein.selenium.AbstractTestCase;
import org.testng.annotations.Test;

public class Test_SNF_PRL_08_MembershipsManagement extends AbstractTestCase {
	
	@Test(groups={"sniff", "epp5.0", "usersmanagement","one"})
	public void testSNF_PRL_08_MembershipsManagement() throws Exception {
        
		System.out.println("--MembershipManagement--");
		
		openPortal(true);

		signInAsRoot();
		
		goToUsersAndGroupsManagement();
		
		chooseMembershipTab();

		addNewMembership("test_name_08", "test_description_08", true);
		
		editMembership("test_name_08", "test_description_edit_08");
		
		deleteMembership("test_name_08", true);

		signOut();
	}

}
