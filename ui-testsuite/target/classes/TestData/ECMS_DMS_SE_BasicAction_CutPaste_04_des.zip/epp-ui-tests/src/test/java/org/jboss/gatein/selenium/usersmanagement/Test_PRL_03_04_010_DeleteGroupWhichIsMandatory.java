package org.jboss.gatein.selenium.usersmanagement;

import org.jboss.gatein.selenium.AbstractTestCase;
import org.testng.annotations.Test;

import static org.jboss.gatein.selenium.common.CommonHelper.*;
import static org.jboss.gatein.selenium.usersmanagement.UsersManagementHelper.*;

public class Test_PRL_03_04_010_DeleteGroupWhichIsMandatory extends AbstractTestCase {
	
	@Test(groups={"usersmanagement","two"})
	public void testPRL_03_04_010_DeleteGroupWhichIsMandatory()	throws Exception {
        
		System.out.println("-- Delete group which is mandatory--");

		openPortal(true);
		
		signInAsRoot();
		
		goToUsersAndGroupsManagement();
		
		chooseGroupTab();
		
		selectGroup("Platform");

		deleteGroup("Platform", false);
		
		waitForMessage("You can't delete this group because it (or its child) is mandatory.");
		closeMessageDialog();

		signOut();
	}

}
