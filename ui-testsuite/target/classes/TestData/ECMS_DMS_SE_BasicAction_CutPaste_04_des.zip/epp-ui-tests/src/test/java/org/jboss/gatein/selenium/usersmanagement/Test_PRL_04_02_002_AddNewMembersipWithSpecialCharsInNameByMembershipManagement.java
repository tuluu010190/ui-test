package org.jboss.gatein.selenium.usersmanagement;

import static org.jboss.gatein.selenium.common.CommonHelper.*;
import static org.jboss.gatein.selenium.usersmanagement.UsersManagementHelper.*;

import org.jboss.gatein.selenium.AbstractTestCase;
import org.testng.annotations.Test;

public class Test_PRL_04_02_002_AddNewMembersipWithSpecialCharsInNameByMembershipManagement extends AbstractTestCase {
	
	@Test(groups={"usersmanagement","two"})
	public void testPRL_04_02_002_AddNewMembersipWithSpecialCharsInNameByMembershipManagement() throws Exception {
        
		System.out.println("-- Add new membership with special characters in Name by Membership management--");

		openPortal(true);
		
		signInAsRoot();
		
		goToUsersAndGroupsManagement();
		
		chooseMembershipTab();

		addNewMembership("#%#^#^", "Test_PTL_04_02_002", false);
		
		waitForMessage("Only letters, digits, dot, dash and underscore characters are allowed for the field \"Membership name\".");
		closeMessageDialog();
		
		signOut();
	}

}
