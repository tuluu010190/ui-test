package org.jboss.gatein.selenium.usersmanagement;


import org.jboss.gatein.selenium.AbstractTestCase;
import org.testng.annotations.Test;

import static org.jboss.gatein.selenium.common.CommonHelper.*;
import static org.jboss.gatein.selenium.usersmanagement.UsersManagementHelper.*;

public class Test_PRL_03_04_004_CheckExistingOfUserInDeletedGroup extends AbstractTestCase {
	
	@Test(groups={"usersmanagement","two"})
	public void testPRL_03_04_004_CheckExistingOfUserInDeletedGroup() throws Exception {
        
		String johnEditIcon = ELEMENT_USER_EDIT_ICON.replace("${username}", "john");
		
		System.out.println("-- Add new group--");

		openPortal(true);
		
		signInAsRoot();
		
		goToUsersAndGroupsManagement();
		
		chooseGroupTab();
		
		System.out.println("-- Click add new group button--");
		
		addNewGroup("Test_PRL_03_04_004", "Test_PRL_03_04_004", "Test_PRL_03_04_004", true);
		
		System.out.println("-- Add user into this group--");

		addUsersAtGroup("john", "member", true, true);
		
		chooseUserTab();

		System.out.println("- Select above user to edit");

		click(johnEditIcon);
		
		System.out.println("-- Choose User Membership tab--");

		click(ELEMENT_USER_MEMBERSHIP_TAB);

		waitForTextPresent("/Test_PRL_03_04_004");
		
		cancel();
		
		System.out.println("-- Return to Group Management--");
		
		chooseGroupTab();

		selectGroup("Test_PRL_03_04_004");
		
		deleteGroup("Test_PRL_03_04_004", true);
        
        pause(500);
		waitForTextNotPresent("Test_PRL_03_04_004");
        
        goToUsersAndGroupsManagement();
        
		System.out.println("-- Go to User Management to check user--");

		chooseUserTab();

		System.out.println("- Select above user to edit");

		click(johnEditIcon);
		
		System.out.println("-- Choose User Membership tab--");

		click(ELEMENT_USER_MEMBERSHIP_TAB);

		waitForTextPresent("Group Id");
		
		waitForTextNotPresent("/Test_PRL_03_04_004");
		
		signOut();
	}

}
