package org.jboss.gatein.selenium.usersmanagement;

import org.jboss.gatein.selenium.AbstractTestCase;
import org.testng.annotations.Test;

import static org.jboss.gatein.selenium.common.CommonHelper.*;
import static org.jboss.gatein.selenium.usersmanagement.UsersManagementHelper.*;

public class Test_PRL_02_03_003_EditLastNameOfUserInCommunityManagement extends AbstractTestCase {
	
	@Test(groups={"usersmanagement","one"})
	public void testPRL_02_03_003_EditLastNameOfUserInCommunityManagement()	throws Exception {
        
		System.out.println("-- Edit First Name of user in Community Management--");
		
		openPortal(true);
		
		signInAsRoot();
		
		goToNewStaff();

		addNewAccountAtNewStaff("test_prl_02_03_003", "Test_PRL_02_03_003", "Test_PRL_02_03_003", "Test_PRL_02_03_003", "Test_PRL_02_03_003", "Test_PRL_02_03_003@localhost.com", "", "English", true);
		
		goToUsersAndGroupsManagement();

		System.out.println("-- Edit with blank Last Name--");

		editLastNameAndCheckMessage("", "The field \"Last Name\" is required.", true);
		
		System.out.println("-- Edit with Last Name contains special characters --");

		editLastNameAndCheckMessage("#$#%#^#@", "The user profile has been updated.", false);
		
		System.out.println("-- Change current value of Last Name with dash --");
		
		editLastNameAndCheckMessage("----Test_PRL_02_03_003", "The user profile has been updated.", true);
		
		System.out.println("-- Change current value of Last Name with underscore--");
		
		editLastNameAndCheckMessage("____Test_PRL_02_03_003", "The user profile has been updated.", true);
		
		System.out.println("--  Edit with First Name start with number--");
		
		editLastNameAndCheckMessage("02_03_003", "The user profile has been updated.", true);
		
		System.out.println("-- Edit with First Name contains space--");
		
		editLastNameAndCheckMessage("Test_PRL_02_03_003 Test_PRL_02_03_003", "The user profile has been updated.", true);
		
		System.out.println("-- Edit with valid value for First Name--");
		
		editLastNameAndCheckMessage("Test_PRL_02_03_003_edit", "The user profile has been updated.", true);
		
		deleteUser("test_prl_02_03_003");
		
		signOut();
	}
	
	private static void editLastNameAndCheckMessage(String newLastName, String message, boolean editOnStart) {
		if (editOnStart) {
            editUser("test_prl_02_03_003");
        }
		type(ELEMENT_INPUT_LASTNAME, newLastName, true);
		save();
		waitForMessage(message);
		closeMessageDialog();
	}

}
