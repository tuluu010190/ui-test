package org.jboss.gatein.selenium.navigation;

import org.jboss.gatein.selenium.AbstractTestCase;
import org.jboss.gatein.selenium.navigation.NavigationHelper.CopyType;
import org.testng.annotations.Test;

import static org.jboss.gatein.selenium.common.CommonHelper.*;
import static org.jboss.gatein.selenium.navigation.NavigationHelper.*;

public class Test_POR_14_04_001_CutPasteNodeToTheSamePlace extends AbstractTestCase {
	
	@Test(groups={"navigation"})
	public void testPOR_14_04_001_CutPasteNodeToTheSamePlace() throws Exception {
        
		System.out.println("--CutPasteNodeToTheSamePlace--");

		openPortal(true);
		
		signInAsRoot();
		
		goToSite();
		
		editFirstNavigation();
		
		copyNode(CopyType.CUT, null, "Home", ELEMENT_NAVIGATION_HOME_NODE, null);

		waitForMessage("This node name already exists.");
		
		closeMessageDialog();
		
		save();
		
		waitForTextNotPresent("Navigation Management");
		
		signOut();
	}
}
