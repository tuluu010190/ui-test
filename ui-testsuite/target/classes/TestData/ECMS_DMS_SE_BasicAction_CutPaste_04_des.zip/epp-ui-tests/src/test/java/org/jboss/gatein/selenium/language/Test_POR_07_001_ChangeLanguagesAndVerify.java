package org.jboss.gatein.selenium.language;

import static org.jboss.gatein.selenium.common.CommonHelper.*;
import static org.jboss.gatein.selenium.language.LanguageHelper.*;

import org.jboss.gatein.selenium.AbstractTestCase;
import org.testng.Assert;
import org.testng.annotations.Test;

public class Test_POR_07_001_ChangeLanguagesAndVerify extends AbstractTestCase {
	
	@Test(groups={"language"})
	public void testPOR_07_001_ChangeLanguagesAndVerify() throws Exception {
		System.out.println("-ChangeLanguagePrivateMode-");
		
		openPortal(true);

		changeLanguage(LANGUAGE_ARABIC);
        Assert.assertTrue(isTextPresent(CHANGE_LANGUAGE_ARABIC));

		changeLanguage(LANGUAGE_CZECH);
        Assert.assertTrue(isTextPresent(CHANGE_LANGUAGE_CZECH));

		changeLanguage(LANGUAGE_DUTCH);
        Assert.assertTrue(isTextPresent(CHANGE_LANGUAGE_DUTCH));

		changeLanguage(LANGUAGE_FRENCH);
        Assert.assertTrue(isTextPresent(CHANGE_LANGUAGE_FRENCH));

		changeLanguage(LANGUAGE_GERMAN);
        Assert.assertTrue(isTextPresent(CHANGE_LANGUAGE_GERMAN));

		changeLanguage(LANGUAGE_ITALIAN);
        Assert.assertTrue(isTextPresent(CHANGE_LANGUAGE_ITALIAN));

		changeLanguage(LANGUAGE_JAPANESE);
        Assert.assertTrue(isTextPresent(CHANGE_LANGUAGE_JAPANESE));

		changeLanguage(LANGUAGE_KOREAN);
        Assert.assertTrue(isTextPresent(CHANGE_LANGUAGE_KOREAN));

		changeLanguage(LANGUAGE_NEPALI);
        Assert.assertTrue(isTextPresent(CHANGE_LANGUAGE_NEPALI));

		changeLanguage(LANGUAGE_PORTUGUESE_BRAZIL);
        Assert.assertTrue(isTextPresent(CHANGE_LANGUAGE_PORTUGUESE_BRAZIL));

		changeLanguage(LANGUAGE_RUSSIAN);
        Assert.assertTrue(isTextPresent(CHANGE_LANGUAGE_RUSSIAN));

		changeLanguage(LANGUAGE_SIMPLIFIED_CHINESE);
        Assert.assertTrue(isTextPresent(CHANGE_LANGUAGE_SIMPLIFIED_CHINESE));

		changeLanguage(LANGUAGE_SPANISH);
        Assert.assertTrue(isTextPresent(CHANGE_LANGUAGE_SPANISH));

		changeLanguage(LANGUAGE_TRADITIONAL_CHINESE);
        Assert.assertTrue(isTextPresent(CHANGE_LANGUAGE_TRADITIONAL_CHINESE));

		changeLanguage(LANGUAGE_UKRANIAN);
        Assert.assertTrue(isTextPresent(CHANGE_LANGUAGE_UKRANIAN));

		changeLanguage(LANGUAGE_VIETNAMESE);
        Assert.assertTrue(isTextPresent(CHANGE_LANGUAGE_VIETNAMESE));

        changeLanguage(LANGUAGE_ENGLISH);
        Assert.assertTrue(isTextPresent(CHANGE_LANGUAGE_ENGLISH));
	}

}
