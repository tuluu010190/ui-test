package org.jboss.gatein.selenium.navigation;

import org.jboss.gatein.selenium.AbstractTestCase;
import org.testng.annotations.Test;

import static org.jboss.gatein.selenium.common.CommonHelper.*;
import static org.jboss.gatein.selenium.navigation.NavigationHelper.*;
import static org.jboss.gatein.selenium.page.PageHelper.*;

public class Test_SNF_PRL_25_EditPageOfNode extends AbstractTestCase {
	
	@Test(groups={"sniff", "epp5.0", "navigation"})
	public void testSNF_PRL_25_EditPageOfNode() throws Exception {
		String node = ELEMENT_NODE_LINK.replace("${nodeLabel}", "test_grp_label_25");
		String checkbox = "//input[@class='checkbox']";
		
		System.out.println("-EditNavActions_Rightclickmenu-");
		
		openPortal(true);

		signInAsRoot();
		
		goToGroup();
		
		addNewNode("test_grp_node_25", "test_grp_label_25", true, null, "test_grp_page_25", "test_grp_page_label_25", true, true, false, null);
		
		System.out.println("--Edit node's page");

		editFirstNavigation();

		contextMenuOnElement(node);
		
		click(ELEMENT_NODE_EDIT_NODE_PAGE);

		click(ELEMENT_VIEW_PAGE_PROPERTIES);

		waitForAndGetElement(checkbox);
		
		save();

        finishPageEdit();

		save();

		waitForTextNotPresent("Navigation Management");
		
		deleteNodeFromNavigation("Administrators", "test_grp_label_25", null, true);
		
		goToPageManagement();
		
		searchAndDeletePage(PageType.GROUP, "test_grp_page_25", "test_grp_page_label_25", true, "test_grp_page_label_25");
		
		signOut();
	}

}
