package org.jboss.gatein.selenium.usersmanagement;

import org.jboss.gatein.selenium.AbstractTestCase;
import org.testng.annotations.Test;

import static org.jboss.gatein.selenium.common.CommonHelper.*;
import static org.jboss.gatein.selenium.usersmanagement.UsersManagementHelper.*;

public class Test_PRL_03_05_004_CheckRefreshMembershipInCaseThereIsNewMembershipCreated extends AbstractTestCase {
	
	@Test(groups={"usersmanagement","two"})
	public void testPRL_03_05_004_CheckRefreshMembershipInCaseThereIsNewMembershipCreated()	throws Exception {
        
		System.out.println("-- Check Refresh membership list in case there's new membership created while adding user into group--");

		openPortal(true);
		
		signInAsRoot();
		
		goToUsersAndGroupsManagement();
		
		chooseGroupTab();
		
		selectGroup("Customers");
		
        waitForAndGetElement("//option[@value='member']");
        waitForAndGetElement("//option[@value='manager']");
		waitForAndGetElement("//option[@value='validator']");
        
		System.out.println("-- Add new membership");
		
		chooseMembershipTab();
		
		addNewMembership("Test_PRL_03_05_004", "Test_PRL_03_05_004", true);

		chooseGroupTab();		
		
		System.out.println("-- Click Refresh--");

		click(ELEMENT_GROUP_SEARCH_MEMBERSHIP_REFRESH_ICON);

        waitForAndGetElement("//option[@value='member']");
        waitForAndGetElement("//option[@value='manager']");
		waitForAndGetElement("//option[@value='validator']");
		waitForAndGetElement("//option[@value='Test_PRL_03_05_004']");
        
		chooseMembershipTab();
		
		deleteMembership("Test_PRL_03_05_004", true);
		
		chooseGroupTab();
		
		System.out.println("-- Click Refresh--");

		click(ELEMENT_GROUP_SEARCH_MEMBERSHIP_REFRESH_ICON);
		
        waitForAndGetElement("//option[@value='member']");
        waitForAndGetElement("//option[@value='manager']");
		waitForAndGetElement("//option[@value='validator']");
		
		waitForElementNotPresent("//option[@value='Test_PRL_03_05_004']");

		signOut();
	}

}
