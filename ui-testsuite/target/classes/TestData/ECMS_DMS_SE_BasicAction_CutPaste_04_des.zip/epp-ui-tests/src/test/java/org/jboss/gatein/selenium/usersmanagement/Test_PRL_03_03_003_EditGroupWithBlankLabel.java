package org.jboss.gatein.selenium.usersmanagement;

import static org.jboss.gatein.selenium.common.CommonHelper.*;
import static org.jboss.gatein.selenium.usersmanagement.UsersManagementHelper.*;

import org.jboss.gatein.selenium.AbstractTestCase;
import org.testng.annotations.Test;

public class Test_PRL_03_03_003_EditGroupWithBlankLabel extends AbstractTestCase {
	
	@Test(groups={"usersmanagement","two"})
	public void testPRL_03_03_003_EditGroupWithBlankLabel() throws Exception {
        
		System.out.println("-- Edit group with blank Label--");

		openPortal(true);
		
		signInAsRoot();
		
		goToUsersAndGroupsManagement();
		
		chooseGroupTab();

		addNewGroup("Test_PRL_03_03_003", "Test_PRL_03_03_003", "Test_PRL_03_03_003", true);
		
		System.out.println("-- Edit group with blank Label--");
		
		click(ELEMENT_GROUP_EDIT_SELECTED);

		type(ELEMENT_INPUT_LABEL, "", true);

		save();
		
		waitForTextNotPresent("Edit Current Group");

		deleteGroup("Test_PRL_03_03_003", true);
		
		signOut();
	}

}
