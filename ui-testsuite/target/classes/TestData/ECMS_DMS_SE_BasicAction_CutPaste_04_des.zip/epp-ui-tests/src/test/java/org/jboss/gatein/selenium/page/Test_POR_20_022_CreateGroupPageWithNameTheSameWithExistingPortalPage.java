package org.jboss.gatein.selenium.page;

import org.jboss.gatein.selenium.AbstractTestCase;
import org.testng.annotations.Test;

import static org.jboss.gatein.selenium.common.CommonHelper.*;
import static org.jboss.gatein.selenium.page.PageHelper.*;

public class Test_POR_20_022_CreateGroupPageWithNameTheSameWithExistingPortalPage extends AbstractTestCase {
	
	@Test(groups={"epp5.0", "page"})
	public void testPOR_20_022_CreateGroupPageWithNameTheSameWithExistingPortalPage() throws Exception {
        
		System.out.println("--CreateGroupPageWithNameTheSameWithExistingPortalPage--");
		
		openPortal(true);

		signInAsRoot();
		
		goToPageManagement();

		addNewPageAtPageManagement("POR_20_022", "POR_20_022", PageType.PORTAL, null, "portal::classic::POR_20_022");
		
		addNewPageAtPageManagement("POR_20_022", "POR_20_022", PageType.GROUP, "/organization/operations", "group::/organization/operations::POR_20_022");
		
		searchAndDeletePage(PageType.GROUP, "POR_20_022", "POR_20_022", true, "group::/organization/operations::POR_20_022");
		
		searchAndDeletePage(PageType.PORTAL, "POR_20_022", "POR_20_022", true, "portal::classic::POR_20_022");
		
		signOut();
	}

}
