package org.jboss.gatein.selenium.navigation;

import org.jboss.gatein.selenium.AbstractTestCase;
import org.testng.annotations.Test;

import static org.jboss.gatein.selenium.common.CommonHelper.*;
import static org.jboss.gatein.selenium.navigation.NavigationHelper.*;
import static org.jboss.gatein.selenium.page.PageHelper.*;

public class Test_POR_14_07_002_CheckCloneNodeContainSubNode extends AbstractTestCase {

	@Test(groups={"navigation"})
	public void testPOR_14_07_002_CheckCloneNodeContainSubNode() throws Exception {
        
		String homeNode = ELEMENT_NODE_LINK.replace("${nodeLabel}", "Home");
		String siteMapNode = ELEMENT_NODE_LINK.replace("${nodeLabel}", "SiteMap");
		
		System.out.println("--CheckCloneNodeContainSubNode--");

		openPortal(true);

		signInAsRoot();

		goToSite();

		addNewPageWithEditor("SiteMap", "Test_POR_14_07_002", "Test_POR_14_07_002", null, null, false, null);

		goToSite();

		editFirstNavigation();

		copyNode(CopyType.CLONE, null, "SiteMap", homeNode, null);

		save();
		
		waitForTextNotPresent("Navigation Management");
		
		deleteNodeFromFirstNavigation("Test_POR_14_07_002", "SiteMap", true);
		
		editFirstNavigation();
		
		click(homeNode);
		
		click(siteMapNode);
		
		deleteNode("Test_POR_14_07_002", true);
		
		deleteNodeFromFirstNavigation("SiteMap", null, false);

		System.out.println("--Check and delete page list in Manage Page--");

		goToPageManagement();

		System.out.println("-- Check existing of page with title 'Test_POR_14_07_002'--");

		searchAndDeletePage(PageType.PORTAL, "page", "Test_POR_14_07_002", false, null);

		searchAndDeletePage(PageType.PORTAL, "page", "Test_POR_14_07_002", true, "Test_POR_14_07_002");

		signOut();
	}
}
