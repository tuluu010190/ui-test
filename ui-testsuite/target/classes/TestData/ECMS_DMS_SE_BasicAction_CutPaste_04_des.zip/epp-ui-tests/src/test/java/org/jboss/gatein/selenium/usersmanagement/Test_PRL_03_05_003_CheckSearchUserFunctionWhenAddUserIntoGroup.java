package org.jboss.gatein.selenium.usersmanagement;

import org.jboss.gatein.selenium.AbstractTestCase;
import org.testng.annotations.Test;

import static org.jboss.gatein.selenium.common.CommonHelper.*;
import static org.jboss.gatein.selenium.usersmanagement.UsersManagementHelper.*;

public class Test_PRL_03_05_003_CheckSearchUserFunctionWhenAddUserIntoGroup extends AbstractTestCase {
	
	@Test(groups={"usersmanagement","two"})
	public void testPRL_03_05_003_CheckSearchUserFunctionWhenAddUserIntoGroup()	throws Exception {
        
		System.out.println("-- Check search user function when add user into group--");

		openPortal(true);
		
		signInAsRoot();
		
		goToUsersAndGroupsManagement();
		
		chooseGroupTab();
		
		selectGroup("Customers");
		
		click(ELEMENT_GROUP_SEARCH_USER_ICON);

		System.out.println("-- Search available user with completed user name--");

		type(ELEMENT_GROUP_SEARCH_POPUP_INPUT, "root", true);

		click(ELEMENT_GROUP_SEARCH_POPUP_SEARCH_ICON);
		
		waitForTextPresent("root@localhost");

		System.out.println("-- Search un-available user--");

		type(ELEMENT_GROUP_SEARCH_POPUP_INPUT, "test_prl_03_05_003", true);

		click(ELEMENT_GROUP_SEARCH_POPUP_SEARCH_ICON);
		
		waitForTextPresent("Empty data");

		System.out.println("-- Search with in completed word but has * to find the right--");

		type(ELEMENT_GROUP_SEARCH_POPUP_INPUT, "o*", true);

		click(ELEMENT_GROUP_SEARCH_POPUP_SEARCH_ICON);
		
		waitForTextPresent("Empty data");

		System.out.println("--Search with in completed word but has * to find the left--");

		type(ELEMENT_GROUP_SEARCH_POPUP_INPUT, "*o", true);

		click(ELEMENT_GROUP_SEARCH_POPUP_SEARCH_ICON);
		
		waitForTextPresent("demo@localhost");

		System.out.println("-- Search with not completed word--");

		type(ELEMENT_GROUP_SEARCH_POPUP_INPUT, "ro", true);

		click(ELEMENT_GROUP_SEARCH_POPUP_SEARCH_ICON);
		
		waitForTextPresent("root@localhost");

		System.out.println("-- Search with key word includes special characters--");

		type(ELEMENT_GROUP_SEARCH_POPUP_INPUT, "#$%$#%#", true);

		click(ELEMENT_GROUP_SEARCH_POPUP_SEARCH_ICON);
		
		waitForTextPresent("Empty data");

		click(ELEMENT_GROUP_SEARCH_POPUP_CLOSE_ICON);

		signOut();
	}

}
