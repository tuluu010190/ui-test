package org.jboss.gatein.selenium.applicationregistry;

import java.util.HashMap;
import java.util.Map;

import org.jboss.gatein.selenium.AbstractTestCase;
import org.testng.annotations.Test;

import static org.jboss.gatein.selenium.common.CommonHelper.*;
import static org.jboss.gatein.selenium.applicationregistry.ApplicationRegistryHelper.*;

public class Test_PRL_05_01_015_AddPrivateCategoryInApplicationRegistry extends AbstractTestCase {
	
	@Test(groups={"applicationregistry"})
	public void testPRL_05_01_015_AddPrivateCategoryInApplicationRegistry()
			throws Exception {
		System.out.println("-- Add private category in Application registry--");
		
		openPortal(true);

		signInAsRoot();
		
		goToApplicationRegistry();
		
		Map<String, String> permissions = new HashMap<String, String>();
		permissions.put("Platform/Administrators", "*");
		addNewCategory("Test_PRL_05_01_015", "Test_PRL_05_01_015", "Test_PRL_05_01_015", false, permissions, true);
		
		addApplicationToCategory("Test_PRL_05_01_015", PortletType.GADGET, "Currency Converter", "");

		deleteCategory("Test_PRL_05_01_015");

		signOut();
	}

}
