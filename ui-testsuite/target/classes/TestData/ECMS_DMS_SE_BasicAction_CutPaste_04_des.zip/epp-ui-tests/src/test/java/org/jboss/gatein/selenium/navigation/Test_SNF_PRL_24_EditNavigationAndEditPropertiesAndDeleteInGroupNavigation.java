package org.jboss.gatein.selenium.navigation;

import org.jboss.gatein.selenium.AbstractTestCase;
import org.testng.Assert;
import org.testng.annotations.Test;

import static org.jboss.gatein.selenium.common.CommonHelper.*;
import static org.jboss.gatein.selenium.navigation.NavigationHelper.*;

public class Test_SNF_PRL_24_EditNavigationAndEditPropertiesAndDeleteInGroupNavigation extends AbstractTestCase {
	
	@Test(groups={"sniff", "epp5.0", "navigation"})
	public void testSNF_PRL_24_EditNavigationAndEditPropertiesAndDeleteInGroupNavigation() throws Exception {
        
		String node = ELEMENT_NODE_LINK.replace("${nodeLabel}", "test_grp_label_24");
		
		System.out.println("-EditDeleteNavigation-");
		
		openPortal(true);

		signInAsRoot();
		
		goToGroup();

		click(ELEMENT_ADD_NAVIGATION_LINK);

		cancel();

		addNewNode("test_grp_node_24", "test_grp_label_24", true, null, null, null, false, true, false, null);
		
		System.out.println("--Edit navigation properties");

		click(ELEMENT_GROUP_EDIT_PROPERTIES_FIRST);

		waitForTextPresent("Page Navigation Form");
		
		save();

		waitForTextNotPresent("Page Navigation Form");
		
		click(ELEMENT_EDIT_FIRST_NAVIGATION);

		waitForTextPresent("Navigation Management");
		
		Assert.assertTrue(isElementPresent(node));
		
		save();
		
		waitForTextNotPresent("Navigation Management");
		
		deleteNodeFromFirstNavigation("test_grp_label_24", null, true);

		signOut();
	}

}
