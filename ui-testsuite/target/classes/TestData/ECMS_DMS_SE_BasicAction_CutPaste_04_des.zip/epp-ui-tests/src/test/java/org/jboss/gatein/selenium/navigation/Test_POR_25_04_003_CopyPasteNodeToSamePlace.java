package org.jboss.gatein.selenium.navigation;

import org.jboss.gatein.selenium.AbstractTestCase;
import org.testng.annotations.Test;

import static org.jboss.gatein.selenium.common.CommonHelper.*;
import static org.jboss.gatein.selenium.navigation.NavigationHelper.*;

public class Test_POR_25_04_003_CopyPasteNodeToSamePlace extends AbstractTestCase {
	
	@Test(groups={"epp5.0", "navigation"})
	public void testPOR_25_04_003_CopyPasteNodeToSamePlace() throws Exception {
        
		String organizationNode = ELEMENT_NODE_LINK.replace("${nodeLabel}", "Organization");
		
		System.out.println("--CopyPasteNodeToSamePlace--");

		openPortal(true);
		
		signInAsRoot();
		
		goToGroup();
		
		editNavigation("Executive Board");
		
		copyNode(CopyType.COPY, null, "New Staff", organizationNode, null);

		waitForMessage("This node name already exists.");
		
		closeMessageDialog();
		
		save();
		
		waitForTextNotPresent("Navigation Management");
		
		signOut();
	}

}
