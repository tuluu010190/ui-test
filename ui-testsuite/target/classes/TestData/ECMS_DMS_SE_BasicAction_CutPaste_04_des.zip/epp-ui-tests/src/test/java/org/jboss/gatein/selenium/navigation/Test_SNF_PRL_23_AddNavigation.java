package org.jboss.gatein.selenium.navigation;

import org.jboss.gatein.selenium.AbstractTestCase;
import org.testng.annotations.Test;

import static org.jboss.gatein.selenium.common.CommonHelper.*;
import static org.jboss.gatein.selenium.navigation.NavigationHelper.*;

public class Test_SNF_PRL_23_AddNavigation extends AbstractTestCase {
	
	@Test(groups={"sniff", "epp5.0", "navigation"})
	public void testSNF_PRL_23_AddNavigation() throws Exception {
        
		System.out.println("-AddNavigation-");
		
		openPortal(true);

		signInAsRoot();

		goToGroup();
		
		click(ELEMENT_ADD_NAVIGATION_LINK);

		cancel();

		addNewNode("test_grp_node_23", "test_grp_label_23", true, null, null, null, false, true, false, null);

		deleteNodeFromFirstNavigation("test_grp_label_23" ,null, true);
		
		signOut();
	}

}
