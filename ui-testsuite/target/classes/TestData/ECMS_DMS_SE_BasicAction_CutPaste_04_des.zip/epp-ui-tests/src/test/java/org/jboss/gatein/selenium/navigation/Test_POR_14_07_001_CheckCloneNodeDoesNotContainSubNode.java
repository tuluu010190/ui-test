package org.jboss.gatein.selenium.navigation;

import org.jboss.gatein.selenium.AbstractTestCase;
import org.testng.annotations.Test;

import static org.jboss.gatein.selenium.common.CommonHelper.*;
import static org.jboss.gatein.selenium.navigation.NavigationHelper.*;
import static org.jboss.gatein.selenium.page.PageHelper.*;


public class Test_POR_14_07_001_CheckCloneNodeDoesNotContainSubNode extends AbstractTestCase {
	
	@Test(groups={"navigation"})
	public void testPOR_14_07_001_CheckCloneNodeDoesNotContainSubNode()	throws Exception {
        
		String node = ELEMENT_NODE_LINK.replace("${nodeLabel}", "Test_POR_14_07_001");
		String clonedLink = ELEMENT_NAVIGATION_PORTLET_PAGE_LINK.replace("${number}", "3");
        String verification = BREADCRUMB_PORTLET_SELECTED_NODE.replace("${node_label}", "Test_POR_14_07_001");
		
		System.out.println("--CheckCloneNodeDoesNotContainSubNode--");
		
		openPortal(true);
		
		signInAsRoot();
		
		goToSite();
		
		addNewPageWithEditor("Home", "Test_POR_14_07_001", "Test_POR_14_07_001", null, null, false, null);
		
		goToSite();
		
		editFirstNavigation();
		
		copyNode(CopyType.CLONE, null, "Test_POR_14_07_001", ELEMENT_NAVIGATION_HOME_NODE, null);

		save();
		
		waitForTextNotPresent("Navigation Management");

		editFirstNavigation();
		
		contextMenuOnElement(node);
		
		click(ELEMENT_NODE_EDIT_NODE);
		
		System.out.println("--Choose Page Node Setting--");

		click(ELEMENT_PAGE_SELECTOR_TAB);

		click(ELEMENT_SEARCH_SELECT_PAGE_LINK);
		
		click(ELEMENT_SELECT_PAGE_FIRST);
		
		pause(500);
		
		save();
		
		waitForTextNotPresent("Page Node Setting");

		save();
		
		waitForTextNotPresent("Navigation Management");

		System.out.println("-- Show content of clone node after change--");

        //check this
		click(clonedLink);
		
		System.out.println("-- Check content of original node's page--");

        goToPage(verification, ELEMENT_LINK_SITE, ELEMENT_LINK_CLASSIC_PORTAL, ELEMENT_LINK_HOME, "Test_POR_14_07_001");
		
		goToSite();
		
		deleteNodeFromFirstNavigation("Test_POR_14_07_001", null, false);
		
		deleteNodeFromFirstNavigation("Test_POR_14_07_001", null, true);

		System.out.println("--Check page list in Manage Page--");

		goToPageManagement();

		searchAndDeletePage(PageType.PORTAL, "page", "Test_POR_14_07_001", false, null);
		
		searchAndDeletePage(PageType.PORTAL, "page", "Test_POR_14_07_001", true, "Test_POR_14_07_001");
		
		signOut();
	}

}
