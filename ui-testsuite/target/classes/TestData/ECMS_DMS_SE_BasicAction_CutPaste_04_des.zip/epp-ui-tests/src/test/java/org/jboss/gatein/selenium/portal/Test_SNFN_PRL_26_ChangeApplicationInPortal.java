package org.jboss.gatein.selenium.portal;

import static org.jboss.gatein.selenium.common.CommonHelper.*;
import static org.jboss.gatein.selenium.page.PageHelper.*;
import static org.jboss.gatein.selenium.portal.PortalHelper.*;

import java.util.HashMap;
import java.util.Map;

import org.jboss.gatein.selenium.AbstractTestCase;
import org.testng.annotations.Test;

public class Test_SNFN_PRL_26_ChangeApplicationInPortal extends AbstractTestCase {

    @Test(groups = {"sniff", "portal"})
    public void testSNFN_PRL_26_ChangeApplicationInPortal() throws Exception {

        String editLayoutIcon = ELEMENT_EDIT_LAYOUT_FROM_TABLE.replace("${portalName}", "Test_SNF_PRL_26");
        String gadgetsCategory = ELEMENT_EDIT_PAGE_CATEGORY_MENU.replace("${categoryLabel}", "Gadgets");
        String calculator = "//div[@id='Gadgets/Calculator']";
        String appDragIcon = ELEMENT_EDIT_PAGE_COMPONENT_DRAG_ICON.replace("${number}", "1");
        String dragAndDropVerificationPosition1 = ELEMENT_EDIT_PAGE_COMPONENT.replace("${portletNumber}", "1") + PORTLET_LABEL.replace("${portletName}", "Calculator");
        String dragAndDropVerificationPosition4 = ELEMENT_EDIT_PAGE_COMPONENT.replace("${portletNumber}", "4") + PORTLET_LABEL.replace("${portletName}", "Test_SNF_PRL_26");

        System.out.println("--Change application in portal--");

        openPortal(true);

        signInAsRoot();

        goToSite();

        Map<String, String> permissions = new HashMap<String, String>();
        permissions.put("Platform/Administrators", "*");
        createNewPortal("Test_SNF_PRL_26", "English", "Default", "On Demand", false, permissions, "Platform/Administrators", "manager");

        verifyPortalExists("Test_SNF_PRL_26");

        System.out.println("-- Choose new portal and click edit layout--");

        click(editLayoutIcon);

        System.out.println("-- Drag & drop applcation in portal--");

        click(gadgetsCategory);

        dragAndDropToObject(calculator, ELEMENT_EDIT_PAGE_COMPONENT_FIRST, dragAndDropVerificationPosition1);

        System.out.println("--Edit application --");

        editSpecifiedPortletOrContainer("1", false, ELEMENT_INPUT_TITLE);

        type(ELEMENT_INPUT_TITLE, "Test_SNF_PRL_26", true);

        System.out.println("-- Choose Select Icon tab --");

        click(ELEMENT_SELECT_ICON_TAB);

        click(ELEMENT_SELECT_ICON_FIRST);

        System.out.println("-- Choose Decoration Themes--");

        pause(500);

        click(ELEMENT_DECORATION_THEMES_TAB);

        pause(500);

        click(ELEMENT_DECORATION_THEME_FIRST);

        click(ELEMENT_SAVE_AND_CLOSE_BUTTON);

        System.out.println("-- View after change something in application --");

        click(ELEMENT_SWITCH_VIEW_MODE_PORTAL);

        pause(500);

        waitForTextPresent("Test_SNF_PRL_26");

        click(ELEMENT_SWITCH_VIEW_MODE_PORTAL);

        System.out.println("-- Move position of application --");

        String firstEditLayoutPortlet = ELEMENT_EDIT_LAYOUT_PORTLET.replace("${portletNumber}", "1");
        if (ieFlag) {
            actions.moveToElement(getElement(firstEditLayoutPortlet));
            actions.dragAndDrop(getElement(appDragIcon), getElement(ELEMENT_EDIT_PAGE_PAGE_BODY_COMPONENT)).build().perform();
        } else {
            mouseOver(firstEditLayoutPortlet, true);
            dragAndDropToObject(appDragIcon, ELEMENT_EDIT_PAGE_PAGE_BODY_COMPONENT, dragAndDropVerificationPosition4);
        }

        System.out.println("-- View after change position of application --");

        click(ELEMENT_SWITCH_VIEW_MODE_PORTAL);

        click(ELEMENT_SWITCH_VIEW_MODE_PORTAL);

        System.out.println("-- Delete application --");

        deleteSpecifiedPortletOrContainer(ContainerType.PORTLET, "4", false);

        click(ELEMENT_EDIT_LAYOUT_FINISH_BUTTON);

        System.out.println("-- Delete portal --");

        deletePortal("Test_SNF_PRL_26");

        signOut();
    }
}
