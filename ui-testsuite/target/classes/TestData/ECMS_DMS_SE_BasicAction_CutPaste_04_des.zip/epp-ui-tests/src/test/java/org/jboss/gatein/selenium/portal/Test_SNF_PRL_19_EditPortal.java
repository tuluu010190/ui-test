package org.jboss.gatein.selenium.portal;

import static org.jboss.gatein.selenium.common.CommonHelper.*;
import static org.jboss.gatein.selenium.portal.PortalHelper.*;
import static org.jboss.gatein.selenium.navigation.NavigationHelper.*;
import static org.jboss.gatein.selenium.permission.PermissionHelper.*;
import static org.jboss.gatein.selenium.page.PageHelper.*;

import org.jboss.gatein.selenium.AbstractTestCase;
import org.testng.annotations.Test;

public class Test_SNF_PRL_19_EditPortal extends AbstractTestCase {
	
	@Test(groups={"sniff", "epp5.0", "portal"})
	public void testSNF_PRL_19_EditPortal() throws Exception {
        
		String adminCategory = ELEMENT_EDIT_PAGE_CATEGORY_MENU.replace("${categoryLabel}", "Administration");
		String appRegPortlet = "//div[@id='Administration/ApplicationRegistryPortlet']";
        String goToPageVerification = BREADCRUMB_PORTLET_SELECTED_NODE.replace("${node_label}", "test_node_label_19");
        String dragAndDropVerification = PORTLET_LABEL.replace("${portletName}", "Application Registry");
        
		System.out.println("-EditPortalNavigation-");
		
		openPortal(true);

		signInAsRoot();

		goToSite();

		System.out.println("--Edit Portal layout, currently do not change anything");

		goToEditLayout();
		
		click(adminCategory);

		dragAndDropToObject(appRegPortlet, ELEMENT_EDIT_PAGE_PAGE_BODY_COMPONENT, dragAndDropVerification);
		
		pause(500);

		click(ELEMENT_EDIT_LAYOUT_ABORT_BUTTON);
		
		waitForPopupConfirmationAndConfirm("Modifications have been made. Are you sure you want to close without saving ?");

		goToSite();

		addNewNode("test_nodename_19", "test_node_label_19", true, null, null, null, false, true, false, null);
		
		System.out.println("--Edit Portal Properties");

		click(ELEMENT_EDIT_FIRST_PORTAL_CONFIG);

		click(ELEMENT_PERMISSION_SETTING_TAB);

		click(ELEMENT_LINK_EDIT_PERMISSION);
		
		setEditPermissions("Platform/Administrators", "*");
		
		save();

		waitForTextNotPresent("Portal Setting");

		System.out.println("--Select new node");

		goToPage(goToPageVerification, ELEMENT_LINK_SITE, ELEMENT_LINK_CLASSIC_PORTAL, ELEMENT_LINK_HOME, "test_node_label_19");

		goToSite();

		deleteNodeFromFirstNavigation("test_node_label_19", null, true);
		
		signOut();
	}

}
