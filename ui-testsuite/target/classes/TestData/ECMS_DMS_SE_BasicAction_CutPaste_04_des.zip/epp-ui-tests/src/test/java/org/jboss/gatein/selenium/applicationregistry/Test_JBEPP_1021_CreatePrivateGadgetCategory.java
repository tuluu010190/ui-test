package org.jboss.gatein.selenium.applicationregistry;

import java.util.Map;
import java.util.HashMap;
import org.jboss.gatein.selenium.AbstractTestCase;
import org.testng.annotations.Test;

import static org.jboss.gatein.selenium.common.CommonHelper.*;
import static org.jboss.gatein.selenium.dashboard.DashboardHelper.*;
import static org.jboss.gatein.selenium.applicationregistry.ApplicationRegistryHelper.*;

public class Test_JBEPP_1021_CreatePrivateGadgetCategory extends AbstractTestCase {

    @Test(groups = {"issues"})
    public void testJBEPP_1021_CreatePrivateGadgetCategory() throws Exception {
        
        System.out.println("--Jira issue: Create PrivateGadgetCategory--");
        
        openPortal(true);

		signInAsRoot();
        
        goToApplicationRegistry();
        
        Map<String, String> permissions = new HashMap<String, String>();
		permissions.put("Platform/Administrators", "*");
        
        addNewCategory("JBEPP_1021", "JBEPP_1021", "JBEPP_1021", false, permissions, true);
        
        addApplicationToCategory("JBEPP_1021", PortletType.GADGET, "Calendar", "");
        
        goToDashboard();
        
        click(ELEMENT_ADD_GADGETS_LINK);
        
        waitForAndGetElement("//div[@title='JBEPP_1021']");

        signOut();
        
        signInAsMary();
        
        goToDashboard();
        
        click(ELEMENT_ADD_GADGETS_LINK);
        
        waitForElementNotPresent("//div[@title='JBEPP_1021']");
        
        signOut();
        
        signInAsRoot();
        
        goToApplicationRegistry();
        
        deleteCategory("JBEPP_1021");
        
        signOut();
        
    }
}
