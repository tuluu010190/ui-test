package org.jboss.gatein.selenium.common;

import org.jboss.gatein.selenium.AbstractTestCase;
import org.testng.Assert;
import org.testng.annotations.Test;

import static org.jboss.gatein.selenium.common.CommonHelper.*;

public class Test_SNF_PRL_32_ChangeSkin extends AbstractTestCase {

	@Test(groups={"sniff", "epp5.0", "common"})
	public void testSNF_PRL_32_ChangeSkin() throws Exception {
		String firstSkin = "//div[@id='UITabContent']/div/div/div[1]/div[2]/div[1]/div/div/div";
		String secondSkin = "//div[@id='UITabContent']/div/div/div[1]/div[2]/div[2]/div/div/div";
		
		System.out.println("--ChangeSkin--");

		openPortal(true);

		signInAsRoot();

		goToChangeSkin();

		System.out.println("--Keep Default skin--");

        click(firstSkin);

		click(ELEMENT_APPLY_BUTTON);

		waitForTextNotPresent("Skin Setting");

		System.out.println("--Change to Simple skin--");

		goToChangeSkin();
		
		waitForTextPresent("Skin Setting");

		System.out.println("--Move from Defalut to Simple skin--");

		Assert.assertTrue(isTextAtElementEqual(firstSkin, "Default Style Skin"));

		Assert.assertTrue(isTextAtElementEqual(secondSkin, "SimpleSkin"));

		click(secondSkin);

		click(ELEMENT_APPLY_BUTTON);

		waitForTextNotPresent("Skin Setting");

		System.out.println("--Return to Default skin--");

		goToChangeSkin();
		
		System.out.println("--Move from Simple skin to Default skin--");

		click(firstSkin);

		click(ELEMENT_APPLY_BUTTON);

		waitForTextNotPresent("Skin Setting");

		signOut();
	}

}
