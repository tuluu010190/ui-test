package org.jboss.gatein.selenium.usersmanagement;

import org.jboss.gatein.selenium.AbstractTestCase;
import org.testng.annotations.Test;

import static org.jboss.gatein.selenium.common.CommonHelper.*;
import static org.jboss.gatein.selenium.usersmanagement.UsersManagementHelper.*;

public class Test_PRL_03_02_008_AddNewGroupWIthNameLessThan3OrOver30chars extends AbstractTestCase {
	
	@Test(groups={"usersmanagement","two"})
	public void testPRL_03_02_008_AddNewGroupWIthNameLessThan3OrOver30chars() throws Exception {
        
		System.out.println("-- Add new group when name less than 3 or over 30 characters--");
		
		openPortal(true);
		
		signInAsRoot();
		
		goToUsersAndGroupsManagement();
		
		chooseGroupTab();
		
		System.out.println("-- Add new group when name less than 3 characters--");
		
		addNewGroup("PR", "Test_PRL_03_02_008", "Test_PRL_03_02_008", false);
		
		waitForMessage("The length of the text in field \"Group Name\" must be between \"3\" and \"30\" characters.");
		closeMessageDialog();
		
		cancel();
		
		System.out.println("-- Add new group when name over 30 characters--");
		
		addNewGroup("Test_PRL_03_02_008 Test_PRL_03_02_008 Test_PRL_03_02_008 Test_PRL_03_02_008", "Test_PRL_03_02_008", "Test_PRL_03_02_008", false);
		
		waitForMessage("The length of the text in field \"Group Name\" must be between \"3\" and \"30\" characters.");
		closeMessageDialog();
		
		cancel();

		signOut();
	}

}
