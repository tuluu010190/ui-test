package org.jboss.gatein.selenium.usersmanagement;

import org.jboss.gatein.selenium.AbstractTestCase;
import org.testng.annotations.Test;

import static org.jboss.gatein.selenium.common.CommonHelper.*;
import static org.jboss.gatein.selenium.usersmanagement.UsersManagementHelper.*;

public class Test_PRL_02_03_005_CheckEditingPasswordInCommunityManagement extends AbstractTestCase {
	
	private final String CONFIRM_PASSWORD_COPIED_VALUE = getMessage("passwordconfirm.copiedvalue");
	
	@Test(groups={"usersmanagement","one"})
	public void testPRL_02_03_005_CheckEditingPasswordInCommunityManagement() throws Exception {
        
		System.out.println("-- Check Editing Password in Community Management--");

		openPortal(true);
		
		signInAsRoot();
		
		goToNewStaff();
		
		addNewAccountAtNewStaff("test_prl_02_03_005", "Test_PRL_02_03_005", "Test_PRL_02_03_005", "Test_PRL_02_03_005", "Test_PRL_02_03_005", "Test_PRL_02_03_005@localhost.com", "", "English", true);

		goToUsersAndGroupsManagement();

		System.out.println("-- Search new user in list--");
		
		editUserPassword();
		
		System.out.println("-- Edit with blank Confirm New Password--");
		
		type(ELEMENT_INPUT_NEW_PASSWORD, "Test_PRL_02_03_005", true);
		
		type(ELEMENT_INPUT_NEW_CONFIRM_PASSWORD, "", true);
		
		save();

		waitForMessage("The field \"Confirm Password\" is required.");
		closeMessageDialog();
		
		cancel();
		
		editUserPassword();
		
		System.out.println("-- Edit with blank New Password--");

		type(ELEMENT_INPUT_NEW_PASSWORD, "", true);
		
		type(ELEMENT_INPUT_NEW_CONFIRM_PASSWORD, "Test_PRL_02_03_005", true);

		save();

		waitForMessage("The field \"New Password\" is required.");
		closeMessageDialog();
		
		cancel();
		
		editUserPassword();
		
		System.out.println("-- Edit with New Password/Confirm Password less than 6 characters--");
		
		type(ELEMENT_INPUT_NEW_PASSWORD, "Test", true);

		type(ELEMENT_INPUT_NEW_CONFIRM_PASSWORD, "Test", true);
		
		save();

		waitForMessage("The length of the text in field \"New Password\" must be between \"6\" and \"30\" characters.");
		closeMessageDialog();
		
		cancel();
		
		editUserPassword();

		System.out.println("-- Edit with New Password/Confirm Password over 30 characters--");
		
		type(ELEMENT_INPUT_NEW_PASSWORD, "Test_PRL_02_03_005Test_PRL_02_03_005Test_PRL_02_03_005", true);

		type(ELEMENT_INPUT_NEW_CONFIRM_PASSWORD, "Test_PRL_02_03_005Test_PRL_02_03_005Test_PRL_02_03_005", true);
		
		save();

		waitForMessage("The length of the text in field \"New Password\" must be between \"6\" and \"30\" characters.");
		closeMessageDialog();
		
		cancel();
		
		editUserPassword();

		System.out.println("-- Edit with New Password & Confirm Password are not the same--");
		
		type(ELEMENT_INPUT_NEW_PASSWORD, "Test_PRL_02_03_005", true);

		type(ELEMENT_INPUT_NEW_CONFIRM_PASSWORD, "Test_PRL_02_03", true);
		
		save();

		waitForMessage("Password and Confirm Password must be the same.");
		closeMessageDialog();
		
		cancel();
		
		editUserPassword();

		System.out.println("-- Edit when copy from New Password and paste to Confirm Password field--");
		
		type(ELEMENT_INPUT_NEW_PASSWORD, "Test_PRL_02_03_005", true);

		type(ELEMENT_INPUT_NEW_CONFIRM_PASSWORD, CONFIRM_PASSWORD_COPIED_VALUE, true);

		save();

		waitForMessage("Password and Confirm Password must be the same.");
		closeMessageDialog();
		
		cancel();
		
		editUserPassword();
		
		System.out.println("-- Edit password with valid values-- ");
		
		type(ELEMENT_INPUT_NEW_PASSWORD, "Test_PRL_02_03_005", true);

		type(ELEMENT_INPUT_NEW_CONFIRM_PASSWORD, "Test_PRL_02_03_005", true);
		
		save();
		
		waitForMessage("The user profile has been updated.");
		closeMessageDialog();

		System.out.println("-- Delete user--");
		
		deleteUser("test_prl_02_03_005");
        
        waitForMessage("No result found.");
        closeMessageDialog();
		
		signOut();
	}
	
	private static void editUserPassword() throws Exception {
		searchUserByUserName("test_prl_02_03_005");
		editUser("test_prl_02_03_005");
		if (!isSelected(ELEMENT_CHECKBOX_CHANGE_PASSWORD)) {
			check(ELEMENT_CHECKBOX_CHANGE_PASSWORD);
		}
	}
}
