package org.jboss.gatein.selenium.usersmanagement;

import org.jboss.gatein.selenium.AbstractTestCase;
import org.testng.Assert;
import org.testng.annotations.Test;

import static org.jboss.gatein.selenium.common.CommonHelper.*;
import static org.jboss.gatein.selenium.usersmanagement.UsersManagementHelper.*;

public class Test_PRL_02_04_003_DeleteSpecificUserFormSearchResultInCommunityManagement extends AbstractTestCase {
	
	@Test(groups={"usersmanagement","one"})
	public void testPRL_02_04_003_DeleteSpecificUserFormSearchResultInCommunityManagement()	throws Exception {
        
		String signedUserlink = ELEMENT_SIGNED_USER_LINK.replace("${name}", "Test_PRL_02_04_003").replace("${surname}", "Test_PRL_02_04_003");
		
		System.out.println("-- Delete specific user from search result in Community Management--");
		
		openPortal(true);
		
		signInAsRoot();

		goToNewStaff();
		
		addNewAccountAtNewStaff("test_prl_02_04_003", "Test_PRL_02_04_003", "Test_PRL_02_04_003", "Test_PRL_02_04_003", "Test_PRL_02_04_003", "Test_PRL_02_04_003@localhost.com", "", "English", true);

		signOut();
		
		System.out.println("-- Login with new user--");
		
		signIn("test_prl_02_04_003", "Test_PRL_02_04_003");

		Assert.assertTrue(isTextAtElementEqual(signedUserlink, "Test_PRL_02_04_003 Test_PRL_02_04_003"));
		
		signOut();
		
		System.out.println("-- Check existing registered users list--");

		signInAsRoot();

		goToUsersAndGroupsManagement();

		System.out.println("-- New user is updated into existing users list --");

		waitForTextPresent("test_prl_02_04_003");

		System.out.println("-- Search new user in list --");

		searchUserByUserName("test_prl_02_04_003");
		
		System.out.println("-- Delete new user--");

		deleteUser("test_prl_02_04_003");
		
		waitForMessage("No result found.");
		closeMessageDialog();

		System.out.println("-- Check all existing users list after delete new user--");

		searchUserByUserName("");

		waitForTextNotPresent("test_prl_02_04_003");
		
		signOut();
	}

}
