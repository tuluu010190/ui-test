package org.jboss.gatein.selenium.usersmanagement;

import org.jboss.gatein.selenium.AbstractTestCase;
import org.testng.annotations.Test;

import static org.jboss.gatein.selenium.common.CommonHelper.*;
import static org.jboss.gatein.selenium.usersmanagement.UsersManagementHelper.*;

public class Test_SNFN_PRL_08_SearchUser extends AbstractTestCase {
	
	@Test(groups={"sniff", "usersmanagement","one"})
	public void testSNF_PRL_08_SearchUser() throws Exception {
        
		System.out.println("-- Search User--");
		
		openPortal(true);
		
		signInAsRoot();
		
		goToUsersAndGroupsManagement();
		
		System.out.println("-- Search by user name--");
		
		searchUserByUserName("john");
		
		waitForTextPresent("john");
		
		System.out.println("-- Return to Users list--");
		
		searchUserByUserName("");
		
		System.out.println("-- Search by Last Name--");
		
		searchUser("Anthony", "Last Name");
		
		waitForTextPresent("Anthony");
		
		System.out.println("-- Return to Users list--");
		
		searchUserByUserName("");

		System.out.println("-- Search by First Name--");
		
		searchUser("John", "First Name");
		
		waitForTextPresent("John");
		
		System.out.println("-- Return to Users list--");
		
		searchUserByUserName("");

		System.out.println("-- Search by email--");
		
		searchUser("john@localhost", "Email");
		
		waitForTextPresent("john@localhost");
		
		System.out.println("-- Return to Users list--");
		
		searchUserByUserName("");

		signOut();
	}

}
