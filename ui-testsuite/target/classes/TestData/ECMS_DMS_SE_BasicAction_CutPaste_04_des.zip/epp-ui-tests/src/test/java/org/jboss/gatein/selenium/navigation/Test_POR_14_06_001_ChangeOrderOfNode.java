package org.jboss.gatein.selenium.navigation;

import static org.jboss.gatein.selenium.common.CommonHelper.*;
import static org.jboss.gatein.selenium.navigation.NavigationHelper.*;

import org.jboss.gatein.selenium.AbstractTestCase;
import org.testng.annotations.Test;

public class Test_POR_14_06_001_ChangeOrderOfNode extends AbstractTestCase {
	
	@Test(groups={"navigation"})
	public void testPOR_14_06_001_ChangeOrderOfNode() throws Exception {
        
		String node = ELEMENT_NODE_LINK.replace("${nodeLabel}", "Test_POR_14_06_001");
		String nodePosition = ELEMENT_NODE_ITEM + "[${position}]/div/a[@title='Test_POR_14_06_001']"; 
		
		System.out.println("--ChangeOrderOfNode--");
		
		openPortal(true);

		signInAsRoot();
		
		goToSite();

		addNewNode("Test_POR_14_06_001", "Test_POR_14_06_001", false, ELEMENT_NAVIGATION_HOME_NODE, null, null, false, true, false, null);

		System.out.println("--Edit node's position--");

		goToSite();
		
		editFirstNavigation();
		
		waitForAndGetElement(node);

		String nodeLvl = getCountOfElements(ELEMENT_NODE_ITEM);

		System.out.println("--Node is at level " + nodeLvl + "--");
		
		contextMenuOnElement(node);
		
		click(ELEMENT_NODE_MOVE_UP);
		
		String position = nodePosition.replace("${position}", nodeLvl);
        waitForElementNotPresent(position);

		System.out.println("--Node is not at level " + nodeLvl + "--");

		System.out.println("--Move node down");
		
		contextMenuOnElement(node);
		
		click(ELEMENT_NODE_MOVE_DOWN);
		
		waitForAndGetElement(position);

		System.out.println("Node is back at level " + nodeLvl + "");

		deleteNodeFromFirstNavigation("Test_POR_14_06_001", null, true);

		signOut();
	}

}
