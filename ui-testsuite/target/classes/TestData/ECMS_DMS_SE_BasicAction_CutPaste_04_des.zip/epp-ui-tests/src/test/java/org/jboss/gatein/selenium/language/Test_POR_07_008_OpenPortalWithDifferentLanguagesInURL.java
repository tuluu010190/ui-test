package org.jboss.gatein.selenium.language;

import static org.jboss.gatein.selenium.common.CommonHelper.*;
import static org.jboss.gatein.selenium.language.LanguageHelper.*;

import org.jboss.gatein.selenium.AbstractTestCase;
import org.testng.Assert;
import org.testng.annotations.Test;

public class Test_POR_07_008_OpenPortalWithDifferentLanguagesInURL extends AbstractTestCase {
	
	@Test(groups={"language"})
	public void testPOR_07_008_OpenPortalWithDifferentLanguagesInURL() throws Exception {
        
		System.out.println("-OpenPortalWithDifferentLanguagesInURL-");
		
		openPortalInLanguage(LanguageAbbreviation.ar);
        System.out.println("--Verify--");
        Assert.assertTrue(isTextPresent(CHANGE_LANGUAGE_ARABIC));

		openPortalInLanguage(LanguageAbbreviation.cs);
        System.out.println("--Verify--");
        Assert.assertTrue(isTextPresent(CHANGE_LANGUAGE_CZECH));

		openPortalInLanguage(LanguageAbbreviation.nl);
        System.out.println("--Verify--");
        Assert.assertTrue(isTextPresent(CHANGE_LANGUAGE_DUTCH));

		openPortalInLanguage(LanguageAbbreviation.fr);
        System.out.println("--Verify--");
        Assert.assertTrue(isTextPresent(CHANGE_LANGUAGE_FRENCH));

		openPortalInLanguage(LanguageAbbreviation.de);
        System.out.println("--Verify--");
        Assert.assertTrue(isTextPresent(CHANGE_LANGUAGE_GERMAN));

		openPortalInLanguage(LanguageAbbreviation.it);
        System.out.println("--Verify--");
        Assert.assertTrue(isTextPresent(CHANGE_LANGUAGE_ITALIAN));

		openPortalInLanguage(LanguageAbbreviation.ja);
        System.out.println("--Verify--");
        Assert.assertTrue(isTextPresent(CHANGE_LANGUAGE_JAPANESE));

		openPortalInLanguage(LanguageAbbreviation.ko);
        System.out.println("--Verify--");
        Assert.assertTrue(isTextPresent(CHANGE_LANGUAGE_KOREAN));

		openPortalInLanguage(LanguageAbbreviation.ne);
        System.out.println("--Verify--");
        Assert.assertTrue(isTextPresent(CHANGE_LANGUAGE_NEPALI));

		openPortalInLanguage(LanguageAbbreviation.pt_BR);
        System.out.println("--Verify--");
        Assert.assertTrue(isTextPresent(CHANGE_LANGUAGE_PORTUGUESE_BRAZIL));

		openPortalInLanguage(LanguageAbbreviation.ru);
        System.out.println("--Verify--");
        Assert.assertTrue(isTextPresent(CHANGE_LANGUAGE_RUSSIAN));

		openPortalInLanguage(LanguageAbbreviation.zh_CN);
        System.out.println("--Verify--");
        Assert.assertTrue(isTextPresent(CHANGE_LANGUAGE_SIMPLIFIED_CHINESE));

		openPortalInLanguage(LanguageAbbreviation.es);
        System.out.println("--Verify--");
        Assert.assertTrue(isTextPresent(CHANGE_LANGUAGE_SPANISH));

		openPortalInLanguage(LanguageAbbreviation.zh_TW);
        System.out.println("--Verify--");
        Assert.assertTrue(isTextPresent(CHANGE_LANGUAGE_TRADITIONAL_CHINESE));

		openPortalInLanguage(LanguageAbbreviation.uk);
        System.out.println("--Verify--");
        Assert.assertTrue(isTextPresent(CHANGE_LANGUAGE_UKRANIAN));

		openPortalInLanguage(LanguageAbbreviation.vi);
        System.out.println("--Verify--");
        Assert.assertTrue(isTextPresent(CHANGE_LANGUAGE_VIETNAMESE));

        openPortalInLanguage(LanguageAbbreviation.en);
        System.out.println("--Verify--");
        Assert.assertTrue(isTextPresent(CHANGE_LANGUAGE_ENGLISH));
	}

}
