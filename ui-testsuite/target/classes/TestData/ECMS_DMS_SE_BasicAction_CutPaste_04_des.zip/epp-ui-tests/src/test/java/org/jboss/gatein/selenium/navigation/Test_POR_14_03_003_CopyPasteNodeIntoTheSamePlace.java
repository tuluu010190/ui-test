package org.jboss.gatein.selenium.navigation;

import org.jboss.gatein.selenium.AbstractTestCase;
import org.testng.annotations.Test;

import static org.jboss.gatein.selenium.common.CommonHelper.*;
import static org.jboss.gatein.selenium.navigation.NavigationHelper.*;

public class Test_POR_14_03_003_CopyPasteNodeIntoTheSamePlace extends AbstractTestCase {
	
	@Test(groups={"navigation"})
	public void testPOR_14_03_003_CopyPasteNodeIntoTheSamePlace() throws Exception {
        
		System.out.println("--CopyPasteNodeIntoTheSamePlace--");

		openPortal(true);
		
		signInAsRoot();
		
		goToSite();
		
		editFirstNavigation();
		
		copyNode(CopyType.COPY, null, "Home", ELEMENT_NAVIGATION_HOME_NODE, null);

		waitForMessage("This node name already exists.");
		
		closeMessageDialog();
		
		save();
		
		waitForTextNotPresent("Navigation Management");
		
		signOut();
	}
}
