package org.jboss.gatein.selenium.usersmanagement;

import org.jboss.gatein.selenium.AbstractTestCase;
import org.testng.annotations.Test;

import static org.jboss.gatein.selenium.common.CommonHelper.*;
import static org.jboss.gatein.selenium.usersmanagement.UsersManagementHelper.*;

public class Test_PRL_03_05_010_AddUserIntoGroupWIthoutSelectCheckboxUserInSelectUserForm extends AbstractTestCase {
	
	@Test(groups={"usersmanagement","two"})
	public void testPRL_03_05_010_AddUserIntoGroupWIthoutSelectCheckboxUserInSelectUserForm() throws Exception {
        
		System.out.println("-- Add user into group without select check box user in Select User form--");
		
		openPortal(true);
		
		signInAsRoot();
		
		goToUsersAndGroupsManagement();
		
		chooseGroupTab();
		
		selectGroup("Customers");
		
		click(ELEMENT_GROUP_SEARCH_USER_ICON);
		waitForTextPresent("Select User");
		
		click(ELEMENT_GROUP_SEARCH_POPUP_ADD_ICON);
		
		waitForMessage("Please check at least one user.");
		closeMessageDialog();
		
		click(ELEMENT_GROUP_SEARCH_POPUP_CLOSE_ICON);

		signOut();
	}

}
