package org.jboss.gatein.selenium.portal;

import static org.jboss.gatein.selenium.common.CommonHelper.*;
import static org.jboss.gatein.selenium.portal.PortalHelper.*;

import org.jboss.gatein.selenium.AbstractTestCase;
import org.testng.annotations.Test;

public class Test_POR_09_004_CreateNewPortalWithNameStartNumber extends AbstractTestCase {

	@Test(groups={"epp5.0", "portal"})
	public void testPOR_09_004_CreateNewPortalWithNameStartNumber() throws Exception {
        
		System.out.println("--Create new portal with name start by number--");
		
		openPortal(true);

		signInAsRoot();

		goToSite();

		createNewPortal("09_004", "English", "Default", "On Demand", true, null, "Platform/Administrators", "*");

		waitForMessage("The \"Portal Name\" field must start with a letter and must not contain special characters.");
		
		closeMessageDialog();

		cancel();

		signOut();
	}

}
