package org.jboss.gatein.selenium.usersmanagement;

import org.jboss.gatein.selenium.AbstractTestCase;
import org.testng.annotations.Test;

import static org.jboss.gatein.selenium.common.CommonHelper.*;
import static org.jboss.gatein.selenium.usersmanagement.UsersManagementHelper.*;

public class Test_PRL_01_004_CreateNewAccountWithBlankRequireFields extends AbstractTestCase {
	
	@Test(groups={"usersmanagement","one"})
	public void testPRL_01_004_CreateNewAccountWithBlankRequireFields()	throws Exception {
        
		System.out.println("-- Create new account with blank required fields--");

		openPortal(true);
		
		signInAsRoot();
		
		goToNewStaff();

		addNewAccountAtNewStaff("Test_PRL_01_004", "Test_PRL_01_004", "Test_PRL_01_004", "", "", "", "", "English", false);
		
		waitForMessage("The field \"First Name\" is required.");
		waitForMessage("The field \"Last Name\" is required.");
		waitForMessage("The field \"Email Address\" is required.");
		closeMessageDialog();
		
		signOut();
	}

}
