package org.jboss.gatein.selenium.applicationregistry;

import static org.jboss.gatein.selenium.applicationregistry.ApplicationRegistryHelper.*;
import static org.jboss.gatein.selenium.common.CommonHelper.*;

import org.jboss.gatein.selenium.AbstractTestCase;
import org.testng.annotations.Test;

public class Test_SNF_PRL_13_AddRemoteAndCreateNewGadget extends AbstractTestCase {
	
	@Test(groups={"sniff", "epp5.0", "applicationregistry"})
	public void testSNF_PRL_13_AddRemoteAndCreateNewGadget() throws Exception {
		String dateTimeGadgetLink = ELEMENT_APPLICATION_IN_CATEGORY.replace("${applicationName}", "Date & Time");
		
		System.out.println("--AddGadget--");
		
		openPortal(true);

		signInAsRoot();

		goToApplicationRegistry();
		
		click(ELEMENT_GADGETS_TAB_LINK);

		waitForAndGetElement(ELEMENT_GADGET_CREATE_ICON);
		
		System.out.println("--Verify gadget present--");
		
        pause(1000);
        
		if (isElementPresent(dateTimeGadgetLink)) {
			deleteGadget("Date & Time");
		}

		addRemoteGadget(URL_GADGET_DATETIME, true);
		
		System.out.println("--Delete remote gadget--");
		
		deleteGadget("Date & Time");

		addNewGadget("SNF_PRL_13", null, true);
		
		deleteGadget("hello world example");
		
		signOut();
	}

}
