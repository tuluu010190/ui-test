package org.jboss.gatein.selenium.usersmanagement;

import org.jboss.gatein.selenium.AbstractTestCase;
import org.testng.annotations.Test;

import static org.jboss.gatein.selenium.common.CommonHelper.*;
import static org.jboss.gatein.selenium.usersmanagement.UsersManagementHelper.*;

public class Test_SNFN_PRL_67_ChangePassword extends AbstractTestCase {
	
	@Test(groups={"sniff", "usersmanagement","one"})
	public void testSNFN_PRL_67_ChangePassword() throws Exception {
        
		String signedUserLink = ELEMENT_SIGNED_USER_LINK.replace("${name}", "Test SNF PRL").replace("${surname}", "Test SNF PRL");
		
		System.out.println("-- Change Password --");
		
		openPortal(true);
		
		signInAsRoot();
		
		goToNewStaff();
		
		addNewAccountAtNewStaff("test_snf_prl_67", "Test_SNF_PRL_67", "Test_SNF_PRL_67", "Test SNF PRL", "Test SNF PRL", "Test_SNF_PRL_67@localhost.com", "", "English", true);
		
		signOut();
		
		System.out.println("-- Login by new user --");
		
		signIn("test_snf_prl_67", "Test_SNF_PRL_67");
		
		waitForTextPresent("Test SNF PRL Test SNF PRL");
		
		click(signedUserLink);

		System.out.println("-- Change Password--");

		click(ELEMENT_USER_CHANGE_PASSWORD_LINK);
		
		waitForTextPresent("Current Password");
		
		type(ELEMENT_INPUT_USER_PROFILE_CURRENT_PASSWORD, "Test_SNF_PRL_67", true);

		type(ELEMENT_INPUT_USER_PROFILE_NEW_PASSWORD, "Test_SNF_PRL_67_edit", true);

		type(ELEMENT_INPUT_USER_PROFILE_CONFIRM_NEW_PASSWORD, "Test_SNF_PRL_67_edit", true);

		click(ELEMENT_USER_PROFILE_CHANGE_PASSWORD_SAVE_BUTTON);
		
		waitForMessage("The password has been changed.");

		closeMessageDialog();
		
		close();

		signOut();

		System.out.println("-- Login by new user after change password --");

		signIn("test_snf_prl_67", "Test_SNF_PRL_67_edit");
		
		waitForTextPresent("Test SNF PRL Test SNF PRL");
		
		signOut();
		
		System.out.println("-- Login by admin--");

		signInAsRoot();
		
		goToUsersAndGroupsManagement();
		
		searchUserByUserName("test_snf_prl_67");

		deleteUser("test_snf_prl_67");

		waitForMessage("No result found.");
		closeMessageDialog();
		
		signOut();
	}

}
