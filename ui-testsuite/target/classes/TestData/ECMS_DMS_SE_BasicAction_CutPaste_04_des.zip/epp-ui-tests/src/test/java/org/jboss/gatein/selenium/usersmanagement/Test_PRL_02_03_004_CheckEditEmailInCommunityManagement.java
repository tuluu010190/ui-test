package org.jboss.gatein.selenium.usersmanagement;

import org.jboss.gatein.selenium.AbstractTestCase;
import org.testng.annotations.Test;

import static org.jboss.gatein.selenium.common.CommonHelper.*;
import static org.jboss.gatein.selenium.usersmanagement.UsersManagementHelper.*;

public class Test_PRL_02_03_004_CheckEditEmailInCommunityManagement extends AbstractTestCase {
	
	@Test(groups={"usersmanagement","one"})
	public void testPRL_02_03_004_CheckEditEmailInCommunityManagement()	throws Exception {
        
		System.out.println("-- Check Editing Email in Community Management--");

		openPortal(true);
		
		signInAsRoot();
		
		goToNewStaff();
		
		addNewAccountAtNewStaff("test_prl_02_03_004", "Test_PRL_02_03_004", "Test_PRL_02_03_004", "Test_PRL_02_03_004", "Test_PRL_02_03_004", "Test_PRL_02_03_004@localhost.com", "", "English", true);
		
		goToUsersAndGroupsManagement();
		
		searchUserByUserName("test_prl_02_03_004");
		
		System.out.println("-- Click Edit user--");

		editUser("test_prl_02_03_004");
		
		System.out.println("--  Change current value of Email with valid value--");

		type(ELEMENT_INPUT_EMAIL, "Test_PRL_02_03_004_edit@localhost.com", true);
		
		save();
		
		waitForMessage("The user profile has been updated.");
		closeMessageDialog();

		waitForTextPresent("Test_PRL_02_03_004_edit@localhost.com");

		editUser("test_prl_02_03_004");
		
		System.out.println("-- Edit with blank Email--");
		
		type(ELEMENT_INPUT_EMAIL, "", true);
		
		save();
		
		waitForMessage("The field \"Email Address\" is required.");
		closeMessageDialog();

		System.out.println("-- Change current value of Email with invalid format--");
		
		type(ELEMENT_INPUT_EMAIL, "Test_PRL_02_03_004", true);
		
		save();
		
		waitForMessage("Your email address is invalid. Please enter a different address.");
		closeMessageDialog();

		cancel();

		deleteUser("test_prl_02_03_004");
        
        waitForMessage("No result found.");
        closeMessageDialog();
		
		signOut();
	}

}
