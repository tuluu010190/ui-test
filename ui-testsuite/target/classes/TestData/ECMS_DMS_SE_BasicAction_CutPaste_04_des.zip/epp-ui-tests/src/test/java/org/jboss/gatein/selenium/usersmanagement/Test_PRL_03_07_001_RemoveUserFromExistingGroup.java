package org.jboss.gatein.selenium.usersmanagement;

import org.jboss.gatein.selenium.AbstractTestCase;
import org.testng.annotations.Test;

import static org.jboss.gatein.selenium.common.CommonHelper.*;
import static org.jboss.gatein.selenium.usersmanagement.UsersManagementHelper.*;

public class Test_PRL_03_07_001_RemoveUserFromExistingGroup extends AbstractTestCase {
	
	@Test(groups={"usersmanagement","two"})
	public void testPRL_03_07_001_RemoveUserFromExistingGroup()	throws Exception {
        
		System.out.println("-- Remove user from existing group--");
		
		openPortal(true);
		
		signInAsRoot();

		goToUsersAndGroupsManagement();

		chooseGroupTab();
		
		System.out.println("-- Add user into group--");

		selectGroup("Customers");
		
		addUsersAtGroup("demo", "member", true, true);
		
		deleteUserFromGroup("demo", "member", "customers", true);
		
		signOut();
	}

}
