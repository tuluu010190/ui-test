package org.jboss.gatein.selenium.common;

import org.jboss.gatein.selenium.AbstractTestCase;
import org.testng.annotations.Test;

import static org.jboss.gatein.selenium.common.CommonHelper.*;
import static org.jboss.gatein.selenium.page.PageHelper.*;

public class Test_POR_12_02_049_CheckFinishFunctionAfterEditedPortlet extends AbstractTestCase {
	
	@Test(groups={"common"})
	public void testPOR_12_02_049_CheckFinishFunctionAfterEditedPortlet() throws Exception {
        
		String iconElement = "//div[@class='IconSelector CategoryContainer']/div/a";
		String decorationElement = "//div[@id='UIItemThemeSelector']/div[2]/div/div";
        
        String getDefaultLinkInSelectIcon = "//div[@class='ItemDetailTitle']/div[3]/a";
        String getDefaultLinkInDecorationThemes = "//div[@id='Theme']/div/div[2]/div/div[3]/a";
		
		openPortal(true);
		
		signInAsRoot();
		
		goToSite();

		click(ELEMENT_EDIT_LAYOUT_FROM_TABLE_FIRST);

        editSpecifiedPortletOrContainer("1", false, ELEMENT_INPUT_TEMPLATE_URL);

		System.out.println("--Go to Portlet Setting--");

        waitForTextPresent("Portlet Setting");
        
		click(ELEMENT_PORLET_SETTING_TAB);

		type(ELEMENT_INPUT_TITLE, "POR_Test_12_02_049", true);

		type(ELEMENT_TEXTAREA_DESCRIPTION, "POR_Test_12_02_049", true);

		System.out.println("--Go to Select Icon--");

		click(ELEMENT_SELECT_ICON_TAB);

		click(iconElement);

		System.out.println("-- Go to Decoration Themes--");

		click(ELEMENT_DECORATION_THEMES_TAB);
		
		click(decorationElement);
		
		click(ELEMENT_SAVE_AND_CLOSE_BUTTON);
		
		pause(500);

		click(ELEMENT_EDIT_LAYOUT_FINISH_BUTTON);

		System.out.println("--Return to default--");

		click(ELEMENT_EDIT_LAYOUT_FROM_TABLE_FIRST);

		editSpecifiedPortletOrContainer("1", false, ELEMENT_INPUT_TEMPLATE_URL);
        
		System.out.println("-- Choose Portlet Setting--");

		click(ELEMENT_PORLET_SETTING_TAB);

		type(ELEMENT_INPUT_TITLE, "", true);

		type(ELEMENT_TEXTAREA_DESCRIPTION, "", true);

		System.out.println("--Choose Select Icon--");
	
		click(ELEMENT_SELECT_ICON_TAB);

		click(getDefaultLinkInSelectIcon);

		System.out.println("--Choose Decoration Themes--");

		click(ELEMENT_DECORATION_THEMES_TAB);
	
		click(getDefaultLinkInDecorationThemes);
		
		click(ELEMENT_SAVE_AND_CLOSE_BUTTON);
		
        waitForElementNotPresent(ELEMENT_SAVE_AND_CLOSE_BUTTON);
	
		click(ELEMENT_EDIT_LAYOUT_FINISH_BUTTON);

		signOut();
	}

}
