package org.jboss.gatein.selenium.usersmanagement;

import org.jboss.gatein.selenium.AbstractTestCase;
import org.testng.annotations.Test;

import static org.jboss.gatein.selenium.common.CommonHelper.*;
import static org.jboss.gatein.selenium.usersmanagement.UsersManagementHelper.*;

public class Test_PRL_01_011_CreateNewAccountWithPasswordandConfirmpasswordAreNotTheSame extends AbstractTestCase {
	
	@Test(groups={"usersmanagement","one"})
	public void testPRL_01_011_CreateNewAccountWithPasswordandConfirmpasswordAreNotTheSame() throws Exception {
        
		System.out.println("-- Create new account with Password and Confirm Password fields are not the same --");

		openPortal(true);
		
		signInAsRoot();
		
		goToNewStaff();

		addNewAccountAtNewStaff("test_prl_01_011", "Test_PRL_01_011", "01_011_Test", "Test_PRL_01_011", "Test_PRL_01_011", "Test_PRL_01_011@localhost.com", "", "English", false);
		
		waitForMessage("Password and Confirm Password must be the same.");
		closeMessageDialog();
		
		signOut();
	}

}
