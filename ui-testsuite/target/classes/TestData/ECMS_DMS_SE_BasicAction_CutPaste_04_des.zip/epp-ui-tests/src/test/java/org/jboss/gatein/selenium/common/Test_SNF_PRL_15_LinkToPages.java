package org.jboss.gatein.selenium.common;

import static org.jboss.gatein.selenium.common.CommonHelper.*;

import org.jboss.gatein.selenium.AbstractTestCase;
import org.testng.annotations.Test;

public class Test_SNF_PRL_15_LinkToPages extends AbstractTestCase {
	
	@Test(groups={"sniff", "epp5.0", "common"})
	public void testSNF_PRL_15_LinkToPages() throws Exception {
		String firstExpandIconItem = "//div[@class='ExpandIcon ClearFix']";
		String firstSubItemLink = "//div[@class='ChildrenContainer']//a";
		
		System.out.println("-SiteMapAndLinkToPage-");
		
		openPortal(true);

		signInAsRoot();

		goToSiteMap();
		
		System.out.println("--Expand the first submenu");

		click(firstExpandIconItem);

		System.out.println("--Select the first link of submenu");

		click(firstSubItemLink);
		
		waitForElementNotPresent(firstSubItemLink);
		
		signOut();
	}

}
