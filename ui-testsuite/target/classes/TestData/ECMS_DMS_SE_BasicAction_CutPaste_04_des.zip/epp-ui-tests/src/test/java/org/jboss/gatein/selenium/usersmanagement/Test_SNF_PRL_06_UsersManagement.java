package org.jboss.gatein.selenium.usersmanagement;

import static org.jboss.gatein.selenium.common.CommonHelper.*;
import static org.jboss.gatein.selenium.usersmanagement.UsersManagementHelper.*;

import org.jboss.gatein.selenium.AbstractTestCase;
import org.testng.annotations.Test;

public class Test_SNF_PRL_06_UsersManagement extends AbstractTestCase {
	
	@Test(groups={"sniff", "epp5.0", "usersmanagement","one"})
	public void testSNF_PRL_06_UsersManagement() throws Exception {
        
		String userEditIcon = ELEMENT_USER_EDIT_ICON.replace("${username}", "mary");
		
		System.out.println("--UserManagement--");
		
		openPortal(true);

		signInAsRoot();
		
		goToUsersAndGroupsManagement();

		waitForTextPresent("User Name");
		
		waitForTextPresent("First Name");
		
		waitForTextPresent("Last Name");
		
		waitForTextPresent("Email");

		System.out.println("--Edit fields (for third user)--");
		
		searchUserByUserName("mary");
		
		editUser("mary");

		type(ELEMENT_INPUT_FIRSTNAME, "test_user_06", true);
        
        type(ELEMENT_INPUT_EMAIL, "mary@localhost.com", true);
		
		save();
		
		waitForMessage("The user profile has been updated.");
		closeMessageDialog();
		
		click(userEditIcon);

		click(ELEMENT_USER_PROFILE_TAB);

		type(ELEMENT_INPUT_USER_NAME_GIVEN, "test_name_given_06", true);

		type(ELEMENT_INPUT_USER_NAME_FAMILY, "test_name_family_06", true);

		type(ELEMENT_INPUT_USER_NAME_NICK, "test_name_nick_06", true);

		save();
		
		waitForMessage("The user profile has been updated.");
		closeMessageDialog();

		System.out.println("--Verify changes--");
		
		searchUserByUserName("mary");

		waitForTextPresent("test_user_06");
		
		System.out.println("--Delete data--");
		
		editUser("mary");
		
		click(ELEMENT_USER_PROFILE_TAB);
		
		type(ELEMENT_INPUT_USER_NAME_GIVEN, "", true);

		type(ELEMENT_INPUT_USER_NAME_FAMILY, "", true);

		type(ELEMENT_INPUT_USER_NAME_NICK, "", true);
		
		click(ELEMENT_ACCOUNT_INFO_TAB);
		
		type(ELEMENT_INPUT_FIRSTNAME, "Mary", true);

		save();

		waitForMessage("The user profile has been updated.");
		closeMessageDialog();
		
		searchUserByUserName("mary");
		
		waitForTextPresent("Mary");
		
		signOut();
	}
}
