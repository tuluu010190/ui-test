package org.jboss.gatein.selenium.applicationregistry;

import java.util.HashMap;
import java.util.Map;

import org.jboss.gatein.selenium.AbstractTestCase;
import org.testng.annotations.Test;

import static org.jboss.gatein.selenium.common.CommonHelper.*;
import static org.jboss.gatein.selenium.applicationregistry.ApplicationRegistryHelper.*;

public class Test_PRL_05_01_008_AddCategoryWithNameTheSameWithExistingButDifferentByUpperLowerCase extends AbstractTestCase {
	
	// failing for mssql, sybase15.5 - JBEPP-334, JBEPP-1359, excluded at testng-upper_lower-case.xml
	@Test(groups={"applicationregistry"})
	public void testPRL_05_01_008_AddCategoryWithNameTheSameWithExistingButDifferentByUpperLowerCase() throws Exception {
        
		System.out.println("-- Add new category with category name the same with existing but different by lower/upper case--");

		openPortal(true);
		
		signInAsRoot();
		
		goToApplicationRegistry();
		
		Map<String, String> permissions = new HashMap<String, String>();
		permissions.put("Customers", "*");
		addNewCategory("test_prl_05_01_008", "test_prl_05_01_008", "test_prl_05_01_008", false, permissions, true);
		
		addApplicationToCategory("test_prl_05_01_008", PortletType.PORTLET, "HomePage Portlet", "");
		
		System.out.println("-- Add category with name is upper case--");
		
		Map<String, String> permissions2 = new HashMap<String, String>();
		permissions2.put("Platform/Administrators", "manager");
		addNewCategory("Test_PRL_05_01_008", "Test_PRL_05_01_008", "Test_PRL_05_01_008", false, permissions2, true);
		
		addApplicationToCategory("Test_PRL_05_01_008", PortletType.GADGET, "Todo", "");

		System.out.println("-- Delete category is lower case--");
		
		selectApplicationInCategory("test_prl_05_01_008", "HomePage Portlet");
		
		deleteCategory("test_prl_05_01_008");

		System.out.println("-- Delete category is upper case--");
		
		selectApplicationInCategory("Test_PRL_05_01_008", "Todo");
		
		deleteCategory("Test_PRL_05_01_008");

		signOut();
	}

}
