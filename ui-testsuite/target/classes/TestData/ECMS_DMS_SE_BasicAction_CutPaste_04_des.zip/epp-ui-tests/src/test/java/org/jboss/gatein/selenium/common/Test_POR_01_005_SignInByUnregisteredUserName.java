package org.jboss.gatein.selenium.common;

import static org.jboss.gatein.selenium.common.CommonHelper.*;

import org.jboss.gatein.selenium.AbstractTestCase;
import org.testng.annotations.Test;

public class Test_POR_01_005_SignInByUnregisteredUserName extends AbstractTestCase {

	@Test(groups={"epp5.0", "common"})
	public void testPOR_01_005_SignInByUnregisteredUserName() throws Exception {
		System.out.println("--Sign in with nonregistered account--");

		openPortal(true);

		signIn("POR_01_005", "POR_01_005");

		waitForTextPresent("Sign in failed. Wrong username or password.");

		type(ELEMENT_INPUT_USERNAME, "root", true);

		type(ELEMENT_INPUT_PASSWORD, "gtn", true);

		click(ELEMENT_SIGN_IN_BUTTON);

		waitForAndGetElement(ELEMENT_LINK_SITE);
		
		signOut();
	}

}
