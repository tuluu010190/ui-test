package org.jboss.gatein.selenium.page;

import org.jboss.gatein.selenium.AbstractTestCase;
import org.testng.Assert;
import org.testng.annotations.Test;

import static org.jboss.gatein.selenium.common.CommonHelper.*;
import static org.jboss.gatein.selenium.permission.PermissionHelper.*;
import static org.jboss.gatein.selenium.page.PageHelper.*;

public class Test_SNF_PRL_22_CreateAndEditPageAndEditSiteLayoutForPortal extends AbstractTestCase {
	
	@Test(groups={"sniff", "epp5.0", "page"})
	public void testSNF_PRL_22_CreateAndEditPageAndEditSiteLayoutForPortal() throws Exception {
        
		String selectedMembership = ELEMENT_SELECTED_EDIT_PERM_MEMBERSHIP.replace("${membership}", "*");
		
		System.out.println("-EditPortalLayout-");
		
		openPortal(true);

		signInAsRoot();

		goToSite();

		goToEditLayout();

		click(ELEMENT_SITE_CONFIG_LINK);

		select(ELEMENT_SELECT_LOCALE, "French");

		click(ELEMENT_PERMISSION_SETTING_TAB);

		waitForAndGetElement(ELEMENT_CHECKBOX_PUBLIC_MODE);
		
		click(ELEMENT_LINK_EDIT_PERMISSION);

		setEditPermissions("Platform/Administrators", "*");

		waitForAndGetElement(selectedMembership);
		
		save();

		click(ELEMENT_EDIT_LAYOUT_FINISH_BUTTON);

		System.out.println("--Verify");

		goToSite();
		
		goToEditLayout();

		click(ELEMENT_SITE_CONFIG_LINK);

		Assert.assertTrue(isSelected(ELEMENT_SELECT_LOCALE + "//option[@value='fr']"));

		select(ELEMENT_SELECT_LOCALE, "English");

		click(ELEMENT_PERMISSION_SETTING_TAB);

		waitForAndGetElement(ELEMENT_CHECKBOX_PUBLIC_MODE);
		
		save();

		click(ELEMENT_EDIT_LAYOUT_FINISH_BUTTON);
		
		signOut();
	}

}
