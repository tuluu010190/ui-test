package org.jboss.gatein.selenium.usersmanagement;

import org.jboss.gatein.selenium.AbstractTestCase;
import org.testng.Assert;
import org.testng.annotations.Test;

import static org.jboss.gatein.selenium.common.CommonHelper.*;
import static org.jboss.gatein.selenium.usersmanagement.UsersManagementHelper.*;


public class Test_SNF_PRL_35_CreateNewAccountPrivateMode extends
		AbstractTestCase {

	@Test(groups={"sniff", "epp5.0", "usersmanagement","one"})
	public void testSNF_PRL_35_CreateNewAccountPrivateMode() throws Exception {
        
		System.out.println("-CreateNewAccountInPrivateMode-");
		
		openPortal(true);

		signInAsRoot();

		goToNewStaff();

		addNewAccountAtNewStaff("test_user_35", "test_pwd_35", "test_pwd_35", "test name first", "test name last", "test_user_35@yahoo.com", "test_name_given_35", "English", true);

		System.out.println("--Verify");

		goToUsersAndGroupsManagement();
		
		searchUserByUserName("test_user_35");

		waitForTextPresent("test_user_35");
		
		Assert.assertTrue(isTextPresent("test_user_35"));

		deleteUser("test_user_35");
		
        waitForMessage("No result found.");
        closeMessageDialog();
        
		signOut();
	}

}
