package org.jboss.gatein.selenium.navigation;

import static org.jboss.gatein.selenium.common.CommonHelper.*;
import static org.jboss.gatein.selenium.navigation.NavigationHelper.*;

import org.jboss.gatein.selenium.AbstractTestCase;
import org.testng.annotations.Test;

public class Test_POR_14_04_006_CutPasteSystemNode extends AbstractTestCase {
	
	@Test(groups={"navigation"})
	public void testPOR_14_04_006_CutPasteSystemNode() throws Exception {
        
		String registerNode = ELEMENT_NODE_LINK.replace("${nodeLabel}", "Register");
		
		System.out.println("--CutPasteSystemNode--");

		openPortal(true);
		
		signInAsRoot();
		
		goToSite();
		
		editFirstNavigation();
		
		contextMenuOnElement(registerNode);

        click(ELEMENT_NODE_CUT);
		
		waitForMessage("Cannot cut a system node");
		
		closeMessageDialog();
		
		save();

		signOut();
	}

}
