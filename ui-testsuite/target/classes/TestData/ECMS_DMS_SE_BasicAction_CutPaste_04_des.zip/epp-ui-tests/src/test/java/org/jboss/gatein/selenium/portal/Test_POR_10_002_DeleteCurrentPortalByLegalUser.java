package org.jboss.gatein.selenium.portal;

import static org.jboss.gatein.selenium.common.CommonHelper.*;
import static org.jboss.gatein.selenium.portal.PortalHelper.*;

import org.jboss.gatein.selenium.AbstractTestCase;
import org.testng.annotations.Test;

public class Test_POR_10_002_DeleteCurrentPortalByLegalUser extends AbstractTestCase {

	@Test(groups={"epp5.0", "portal"})
	public void testPOR_10_002_DeleteCurrentPortalByLegalUser() throws Exception {
		System.out.println("--Create new portal with valid value--");
		
		openPortal(true);

		signInAsRoot();

		goToSite();

		createNewPortal("Test_POR_10_002", "English", "Default", "On Demand", true, null, "Platform/Administrators", "*");

		verifyPortalExists("Test_POR_10_002");

		deletePortal("Test_POR_10_002");

		signOut();
	}
}
