package org.jboss.gatein.selenium.usersmanagement;

import org.jboss.gatein.selenium.AbstractTestCase;
import org.testng.annotations.Test;

import static org.jboss.gatein.selenium.common.CommonHelper.*;
import static org.jboss.gatein.selenium.usersmanagement.UsersManagementHelper.*;

public class Test_PRL_03_04_003_DeleteGroupWithoutSelectingGroup extends AbstractTestCase {
	
	@Test(groups={"usersmanagement","two"})
	public void testPRL_03_04_003_DeleteGroupWithoutSelectingGroup() throws Exception {
        
		System.out.println("-- Delete group without selecting group --");
		
		openPortal(true);
		
		signInAsRoot();
		
		goToUsersAndGroupsManagement();
		
		chooseGroupTab();
		
		click(ELEMENT_GROUP_LEVEL_UP_ICON);
		
		click(ELEMENT_GROUP_DELETE_SELECTED);
		
		waitForConfirmation("Are you sure you want to delete this group?");
		
		waitForMessage("You must select a group.");
		closeMessageDialog();
		
		signOut();
	}

}
