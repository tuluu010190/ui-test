package org.jboss.gatein.selenium.navigation;

import java.util.Map;
import java.util.HashMap;
import org.jboss.gatein.selenium.AbstractTestCase;
import org.testng.annotations.Test;

import static org.jboss.gatein.selenium.common.CommonHelper.*;
import static org.jboss.gatein.selenium.language.LanguageHelper.*;
import static org.jboss.gatein.selenium.navigation.NavigationHelper.*;

public class Test_SNF_PRL_36_CreateNewNodeInExtendelLabelMode extends AbstractTestCase {
	
	@Test(groups={"sniff", "navigation"})
	public void testSNF_PRL_36_CreateNewNodeInExtendelLabelMode() throws Exception {
                
        Map<String, String> labels = new HashMap<String, String>();
        labels.put("Czech", "test_label_CZ");
        labels.put("English", "test_label_EN");
        labels.put("French", "test_label_FR");
        labels.put("German", "test_label_DE");
        labels.put("Italian", "test_label_IT");
        labels.put("Russian", "test_label_RU");
        labels.put("Spanish", "test_label_ES");
        
		System.out.println("-AddEditGroupPageWizard-");
		
		openPortal(true);

		signInAsRoot();

		goToSite();

		addNewNode("SNF_PRL_36", "test_label_EN", false, ELEMENT_NAVIGATION_HOME_NODE, null, null, false, true, true, labels);
        
        System.out.println("--Check label in English--");

        waitForTextPresent("test_label_EN");

		changeLanguage(LANGUAGE_CZECH);

        System.out.println("--Check label in Czech--");
		waitForTextPresent("test_label_CZ");

		changeLanguage(LANGUAGE_FRENCH);
		
        System.out.println("--Check label in French--");
		waitForTextPresent("test_label_FR");
        
		changeLanguage(LANGUAGE_GERMAN);
		
        System.out.println("--Check label in German--");
		waitForTextPresent("test_label_DE");
        
		changeLanguage(LANGUAGE_ITALIAN);
		
        System.out.println("--Check label in Italian--");
		waitForTextPresent("test_label_IT");
        
		changeLanguage(LANGUAGE_RUSSIAN);
		
        System.out.println("--Check label in Russian--");
		waitForTextPresent("test_label_RU");
        
		changeLanguage(LANGUAGE_SPANISH);
		
        System.out.println("--Check label in Spanish--");
		waitForTextPresent("test_label_ES");
         
		changeLanguage(LANGUAGE_ENGLISH);
        
        goToSite();
        
        editFirstNavigation();
		
		deleteNode("test_label_EN", true);
		
		signOut();
	}

}
