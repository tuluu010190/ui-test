package org.jboss.gatein.selenium.applicationregistry;

import org.jboss.gatein.selenium.AbstractTestCase;
import org.testng.annotations.Test;

import static org.jboss.gatein.selenium.common.CommonHelper.*;
import static org.jboss.gatein.selenium.applicationregistry.ApplicationRegistryHelper.*;

public class Test_PRL_07_04_003_CreateNewGadgetWithBlankSource extends AbstractTestCase {
	
	@Test(groups={"applicationregistry"})
	public void testPRL_07_04_003_CreateNewGadgetWithBlankSource()
			throws Exception {
		System.out.println("-- Create new gadget with blank source--");
		
		openPortal(true);

		signInAsRoot();
		
		goToApplicationRegistry();

		System.out.println("-- Choose Gadget tab--");

		click(ELEMENT_GADGETS_TAB_LINK);

		waitForAndGetElement("//div[@class='IconControl AddNewIcon']");

		addNewGadget("Test_PRL_07_04_003", "", false);

		waitForMessage("The field \"XML Source Code\" is required.");
		closeMessageDialog();
		
		cancel();

		signOut();
	}

}
