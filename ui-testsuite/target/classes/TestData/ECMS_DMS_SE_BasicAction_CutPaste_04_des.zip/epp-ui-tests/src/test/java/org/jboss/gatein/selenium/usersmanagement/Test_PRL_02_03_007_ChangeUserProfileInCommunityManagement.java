package org.jboss.gatein.selenium.usersmanagement;

import org.jboss.gatein.selenium.AbstractTestCase;
import org.testng.annotations.Test;

import static org.jboss.gatein.selenium.common.CommonHelper.*;
import static org.jboss.gatein.selenium.usersmanagement.UsersManagementHelper.*;

public class Test_PRL_02_03_007_ChangeUserProfileInCommunityManagement extends AbstractTestCase {
	
	@Test(groups={"usersmanagement","one"})
	public void testPRL_02_03_007_ChangeUserProfileInCommunityManagement() throws Exception {
        
		System.out.println("--Add new user--");

		openPortal(true);
		
		signInAsRoot();
		
		goToNewStaff();
		
		addNewAccountAtNewStaff("test_prl_02_03_007", "Test_PRL_02_03_007", "Test_PRL_02_03_007", "Test_PRL_02_03_007", "Test_PRL_02_03_007", "Test_PRL_02_03_007@localhost.com", "", "Vietnamese", true);
		
		goToUsersAndGroupsManagement();
		
		System.out.println("--Change normal User Profile information--");

		searchUserByUserName("test_prl_02_03_007");

		editUser("test_prl_02_03_007");
		
		type(ELEMENT_INPUT_FIRSTNAME, "Test_PRL_02_03_007_edit", true);

		type(ELEMENT_INPUT_LASTNAME, "Test_PRL_02_03_007_edit", true);

		save();

		waitForMessage("The user profile has been updated.");
		closeMessageDialog();
		
		System.out.println("--Change displaying language for user--");

		editUser("test_prl_02_03_007");
		
		click(ELEMENT_USER_PROFILE_TAB);

		select(ELEMENT_SELECT_USER_LANGUAGE, "English");
		
		save();
		
		waitForMessage("The user profile has been updated.");
		closeMessageDialog();

		signOut();
		
		System.out.println("--Login with user which edited--");

		signIn("test_prl_02_03_007", "Test_PRL_02_03_007");
		
		signOut();
		
		System.out.println("--Delete new user--");

		signInAsRoot();
		
		goToUsersAndGroupsManagement();
		
		searchUserByUserName("test_prl_02_03_007");
		
		deleteUser("test_prl_02_03_007");
		
		waitForMessage("No result found.");
		closeMessageDialog();
		
		signOut();
	}

}
