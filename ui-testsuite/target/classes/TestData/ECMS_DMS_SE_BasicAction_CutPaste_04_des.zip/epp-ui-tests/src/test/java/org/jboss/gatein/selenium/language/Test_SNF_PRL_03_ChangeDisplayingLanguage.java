package org.jboss.gatein.selenium.language;

import static org.jboss.gatein.selenium.common.CommonHelper.*;
import static org.jboss.gatein.selenium.language.LanguageHelper.*;

import org.jboss.gatein.selenium.AbstractTestCase;
import org.testng.annotations.Test;

public class Test_SNF_PRL_03_ChangeDisplayingLanguage extends AbstractTestCase {

	@Test(groups={"sniff", "epp5.0", "language"})
	public void testSNF_PRL_03_ChangeDisplayingLanguage() throws Exception {
		System.out.println("-Change Language-");
		
		openPortal(true);

		changeLanguage(LANGUAGE_VIETNAMESE);
		
		waitForTextPresent(HOME_LABEL_VIETNAMESE);
		
		changeLanguage(LANGUAGE_ENGLISH);
	}
}