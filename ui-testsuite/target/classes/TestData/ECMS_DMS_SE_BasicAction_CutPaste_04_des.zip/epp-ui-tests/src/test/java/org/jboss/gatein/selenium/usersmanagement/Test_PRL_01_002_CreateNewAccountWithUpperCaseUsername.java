package org.jboss.gatein.selenium.usersmanagement;

import org.jboss.gatein.selenium.AbstractTestCase;
import org.testng.annotations.Test;

import static org.jboss.gatein.selenium.common.CommonHelper.*;
import static org.jboss.gatein.selenium.usersmanagement.UsersManagementHelper.*;

public class Test_PRL_01_002_CreateNewAccountWithUpperCaseUsername extends AbstractTestCase {
	
	@Test(groups={"usersmanagement","one"})
	public void testPRL_01_002_CreateNewAccountWithUpperCaseUsername() throws Exception {
        
		System.out.println("-- Create new user with lower case--");

		openPortal(true);
		
		signInAsRoot();
		
		goToNewStaff();

		addNewAccountAtNewStaff("TEST_PRL_01_001_TEST", "test_prl_01_001", "test_prl_01_001", "test_prl_01_001", "test_prl_01_001", "test_prl_01_001@localhost.com", "", "Czech", false);
		waitForMessage("Only lowercase letters, digits, dot and underscore characters are allowed for the field \"User Name\".");
        waitForMessage("The field \"User Name\" must end with a lowercase letter or digit instead of \"T\".");
        waitForMessage("The \"User Name\" field must start with a lowercase letter.");
        
		closeMessageDialog();
		
		signOut();
	}

}
