package org.jboss.gatein.selenium.dashboard;

import org.jboss.gatein.selenium.AbstractTestCase;
import org.testng.annotations.Test;

import static org.jboss.gatein.selenium.common.CommonHelper.*;
import static org.jboss.gatein.selenium.dashboard.DashboardHelper.*;

public class Test_SNF_PRL_28_AddDragDropInDashboard extends AbstractTestCase {
	
	@Test(groups={"sniff", "epp5.0", "dashboard"})
	public void testSNF_PRL_28_AddDragDropInDashboard() throws Exception {
        
		String gadget2Drag = ELEMENT_ADD_GADGETS_GADGET.replace("${title}", "Calculator");
		String gadget2Title = ELEMENT_GADGET_TITLE.replace("${title}", "Calculator");
		String gadget2Delete = ELEMENT_GADGET_DELETE_ICON.replace("${title}", "Calculator");
		
		System.out.println("-ActionsDashboardpage-");
		
		openPortal(true);

		signInAsRoot();

		goToDashboard();
		
		System.out.println("--Add gadgets into dashboard page by drag and drop");

		click(ELEMENT_ADD_GADGETS_LINK);
		
        dradAndDropBy(gadget2Drag, -100, 50);
        
		waitForAndGetElement(gadget2Title);
		
		click(ELEMENT_ADD_GADGETS_CLOSE_BUTTON);

		click(gadget2Delete);

		waitForConfirmation("Are you sure to delete this gadget?");
		
        waitForTextPresent("Drag your gadgets here.");
		
		signOut();
	}

}
