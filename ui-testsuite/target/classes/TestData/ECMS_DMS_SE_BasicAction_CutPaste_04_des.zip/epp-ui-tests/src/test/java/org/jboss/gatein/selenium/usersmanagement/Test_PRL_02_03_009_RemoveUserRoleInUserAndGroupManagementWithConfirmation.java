package org.jboss.gatein.selenium.usersmanagement;

import org.jboss.gatein.selenium.AbstractTestCase;
import org.testng.annotations.Test;

import static org.jboss.gatein.selenium.common.CommonHelper.*;
import static org.jboss.gatein.selenium.usersmanagement.UsersManagementHelper.*;

public class Test_PRL_02_03_009_RemoveUserRoleInUserAndGroupManagementWithConfirmation extends AbstractTestCase {
	
	@Test(groups={"usersmanagement","one"})
	public void testPRL_02_03_009_RemoveUserRoleInUserAndGroupManagementWithConfirmation() throws Exception {
        
		System.out.println("-- Remove user role in User and group management with confirmation--");

		openPortal(true);
		
		signInAsRoot();
		
		goToUsersAndGroupsManagement();
		
		chooseMembershipTab();
		
		System.out.println("-- Add new membership--");
		
		addNewMembership("test_prl_02_03_009", "Test_PRL_02_03_009", true);

		chooseGroupTab();

		selectGroup("Customers");
		
		addUsersAtGroup("root", "test_prl_02_03_009", false, true);
		
		chooseUserTab();

		System.out.println("-- Check user after add new membership--");
		
		searchUserByUserName("root");
		
		editUser("root");

		System.out.println("-- Choose User Membership--");

		click(ELEMENT_USER_MEMBERSHIP_TAB);
        
        //TODO: add paging
		
		waitForTextPresent("test_prl_02_03_009");

		cancel();
		
		pause(500);

		chooseMembershipTab();

		deleteMembership("test_prl_02_03_009", true);
		
		chooseUserTab();

		System.out.println("-- Check user after delete new membership--");
		
		searchUserByUserName("root");
		
		editUser("root");

		System.out.println("-- Choose User Membership--");

		click(ELEMENT_USER_MEMBERSHIP_TAB);
		
		waitForTextPresent("Group Id");
		
		waitForTextNotPresent("test_prl_02_03_009");

		cancel();

		signOut();
	}

}
