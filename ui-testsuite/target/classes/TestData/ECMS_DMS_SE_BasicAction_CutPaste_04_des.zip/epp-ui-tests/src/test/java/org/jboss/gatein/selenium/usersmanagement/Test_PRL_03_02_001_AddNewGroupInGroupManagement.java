package org.jboss.gatein.selenium.usersmanagement;

import static org.jboss.gatein.selenium.common.CommonHelper.*;
import static org.jboss.gatein.selenium.usersmanagement.UsersManagementHelper.*;

import org.jboss.gatein.selenium.AbstractTestCase;
import org.testng.annotations.Test;

public class Test_PRL_03_02_001_AddNewGroupInGroupManagement extends AbstractTestCase {
	@Test(groups={"usersmanagement","two"})
	public void testPRL_03_02_001_AddNewGroupInGroupManagement() throws Exception {
        
		System.out.println("-- Add new group--");

		openPortal(true);
		
		signInAsRoot();

		goToUsersAndGroupsManagement();
		
		chooseGroupTab();
		
		addNewGroup("PRL_03_02_001", "PRL_03_02_001", "PRL_03_02_001", true);
		
		selectGroup("PRL_03_02_001");
		
		deleteGroup("PRL_03_02_001", true);
		
		signOut();
	}

}
