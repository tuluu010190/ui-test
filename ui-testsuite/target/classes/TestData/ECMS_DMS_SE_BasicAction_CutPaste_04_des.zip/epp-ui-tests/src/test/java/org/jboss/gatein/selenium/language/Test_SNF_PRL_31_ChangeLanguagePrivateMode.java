package org.jboss.gatein.selenium.language;

import org.jboss.gatein.selenium.AbstractTestCase;
import org.testng.annotations.Test;

import static org.jboss.gatein.selenium.common.CommonHelper.*;
import static org.jboss.gatein.selenium.language.LanguageHelper.*;

public class Test_SNF_PRL_31_ChangeLanguagePrivateMode extends AbstractTestCase {
	
	@Test(groups={"sniff", "epp5.0", "language"})
	public void testSNF_PRL_31_ChangeLanguagePrivateMode() throws Exception {
		System.out.println("-ChangeLanguagePrivateMode-");
		
		openPortal(true);

		signInAsRoot();
		
		changeLanguage(LANGUAGE_FRENCH);
		
		System.out.println("--Verify");
		
        waitForTextPresent(HOME_LABEL_FRENCH);

		changeLanguage(LANGUAGE_ENGLISH);
		
		System.out.println("--Verify");
		
		goToSiteClassicHome();

		signOut();
	}

}
