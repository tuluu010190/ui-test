package org.jboss.gatein.selenium.portal;

import org.jboss.gatein.selenium.AbstractTestCase;
import org.testng.annotations.Test;

import static org.jboss.gatein.selenium.common.CommonHelper.*;
import static org.jboss.gatein.selenium.portal.PortalHelper.*;


public class Test_SNF_PRL_20_DeletePortal extends AbstractTestCase {

	@Test(groups={"sniff", "epp5.0", "portal"})
	public void testSNF_PRL_20_DeletePortal() throws Exception {
        
		System.out.println("-DeletePortal-");
		
		openPortal(true);
		
		signInAsRoot();
		
		goToSite();
		
		createNewPortal("test_portal_name_20", "English", "Default", "On Demand", true, null, "Platform/Administrators", "*");
		
		verifyPortalExists("test_portal_name_20");
		
		deletePortal("test_portal_name_20");

		signOut();
	}

}
