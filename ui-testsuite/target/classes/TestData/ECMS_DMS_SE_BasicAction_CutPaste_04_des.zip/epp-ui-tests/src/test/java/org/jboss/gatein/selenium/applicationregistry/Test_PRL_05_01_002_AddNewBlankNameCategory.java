package org.jboss.gatein.selenium.applicationregistry;

import java.util.HashMap;
import java.util.Map;

import org.jboss.gatein.selenium.AbstractTestCase;
import org.testng.annotations.Test;

import static org.jboss.gatein.selenium.common.CommonHelper.*;
import static org.jboss.gatein.selenium.applicationregistry.ApplicationRegistryHelper.*;

public class Test_PRL_05_01_002_AddNewBlankNameCategory extends AbstractTestCase {
	
	@Test(groups={"applicationregistry"})
	public void testPRL_05_01_002_AddNewBlankNameCategory() throws Exception {
		System.out.println("-- Add new blank name category--");

		openPortal(true);
		
		signInAsRoot();
		
		goToApplicationRegistry();
		
		Map<String, String> permissions = new HashMap<String, String>();
		permissions.put("Customers", "*");
		addNewCategory("", "Test_PRL_05_01_002", "Test_PRL_05_01_002", false, permissions, false);
		
		waitForMessage("The field \"Category name\" is required.");
		closeMessageDialog();
	
		cancel();

		signOut();
	}

}
