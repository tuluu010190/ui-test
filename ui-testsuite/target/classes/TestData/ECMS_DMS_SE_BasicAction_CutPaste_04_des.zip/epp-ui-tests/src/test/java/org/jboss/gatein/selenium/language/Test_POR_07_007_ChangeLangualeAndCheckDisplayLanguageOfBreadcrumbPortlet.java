package org.jboss.gatein.selenium.language;

import static org.jboss.gatein.selenium.common.CommonHelper.*;
import static org.jboss.gatein.selenium.language.LanguageHelper.*;

import org.jboss.gatein.selenium.AbstractTestCase;
import org.testng.annotations.Test;

public class Test_POR_07_007_ChangeLangualeAndCheckDisplayLanguageOfBreadcrumbPortlet extends AbstractTestCase {
	
	@Test(groups={"language"})
	public void testPOR_07_007_ChangeLangualeAndCheckDisplayLanguageOfBreadcrumbPortlet() throws Exception {
        
        String home_node_in_frech_in_breadcrumb_portlet = BREADCRUMB_PORTLET_SELECTED_NODE.replace("${node_label}", HOME_LABEL_FRENCH);
        String home_node_in_english_in_breadcrumb_portlet = BREADCRUMB_PORTLET_SELECTED_NODE.replace("${node_label}", HOME_LABEL_ENGLISH);
        
		System.out.println("-Change Language from English to French-");
		
		openPortal(true);
        
        waitForAndGetElement(home_node_in_english_in_breadcrumb_portlet);
        
		changeLanguage(LANGUAGE_FRENCH);
		
		waitForAndGetElement(home_node_in_frech_in_breadcrumb_portlet);
        
        changeLanguage(LANGUAGE_ENGLISH);
        
        waitForAndGetElement(home_node_in_english_in_breadcrumb_portlet);
	}
}
