package org.jboss.gatein.selenium.page;

import org.jboss.gatein.selenium.AbstractTestCase;
import org.testng.annotations.Test;

import static org.jboss.gatein.selenium.common.CommonHelper.*;
import static org.jboss.gatein.selenium.page.PageHelper.*;

public class Test_POR_20_019_CreateSameNameGroupPagesInSameGroup extends AbstractTestCase {

	@Test(groups={"epp5.0", "page"})
	public void testPOR_20_019_CreateSameNameGroupPagesInSameGroup() throws Exception {
        
		System.out.println("--CreateSameNameGroupPagesInSameGroup--");

		openPortal(true);
		
		signInAsRoot();

		goToPageManagement();

		addNewPageAtPageManagement("POR_20_019", "POR_20_019", PageType.GROUP, "/platform/users", "group::/platform/users::POR_20_019");

		addNewPageAtPageManagement("POR_20_019", "POR_20_019", PageType.GROUP, "/platform/users", null);

		waitForMessage("This page name already exists.");
		
		closeMessageDialog();
		
		cancel();
		
        pause(500);
        
		waitForTextNotPresent("Page Setting");

		searchAndDeletePage(PageType.GROUP, "POR_20_019", "POR_20_019", true, "group::/platform/users::POR_20_019");
		
		signOut();
	}

}
