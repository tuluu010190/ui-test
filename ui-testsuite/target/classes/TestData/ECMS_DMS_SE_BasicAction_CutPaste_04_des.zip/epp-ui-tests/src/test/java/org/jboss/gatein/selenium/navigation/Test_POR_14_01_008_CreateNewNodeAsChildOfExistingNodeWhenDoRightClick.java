package org.jboss.gatein.selenium.navigation;

import static org.jboss.gatein.selenium.common.CommonHelper.*;
import static org.jboss.gatein.selenium.navigation.NavigationHelper.*;

import org.jboss.gatein.selenium.AbstractTestCase;
import org.testng.annotations.Test;

public class Test_POR_14_01_008_CreateNewNodeAsChildOfExistingNodeWhenDoRightClick extends AbstractTestCase {
	
	@Test(groups={"navigation"})
	public void testPOR_14_01_008_CreateNewNodeAsChildOfExistingNodeWhenDoRightClick() throws Exception {
        
		String homeNode = ELEMENT_NODE_LINK.replace("${nodeLabel}", "Home");
        String verification = BREADCRUMB_PORTLET_SELECTED_NODE.replace("${node_label}", "Test_POR_14_01_008");
		
		System.out.println("--CreateNewNodeAsChildOfExistingNodeWhenDoRightClick--");

		openPortal(true);
		
		signInAsRoot();

		goToSite();

		System.out.println("--Create new node in the first level when do right click--");
		
		addNewNode("Test_POR_14_01_008", "Test_POR_14_01_008", false, homeNode, null, null, false, true, false, null);
		
		System.out.println("--View page (node)--");

        goToPage(verification, ELEMENT_LINK_SITE, ELEMENT_LINK_CLASSIC_PORTAL, ELEMENT_LINK_HOME, "Test_POR_14_01_008");
		
		goToSite();

		deleteNodeFromFirstNavigation("Test_POR_14_01_008", null, true); //"Home");
		
		signOut();
	}

}
