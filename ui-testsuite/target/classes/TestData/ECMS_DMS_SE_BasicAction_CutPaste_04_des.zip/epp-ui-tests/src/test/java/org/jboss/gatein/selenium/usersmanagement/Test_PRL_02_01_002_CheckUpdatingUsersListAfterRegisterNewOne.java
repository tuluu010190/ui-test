package org.jboss.gatein.selenium.usersmanagement;

import org.jboss.gatein.selenium.AbstractTestCase;
import org.testng.annotations.Test;

import static org.jboss.gatein.selenium.common.CommonHelper.*;
import static org.jboss.gatein.selenium.language.LanguageHelper.*;
import static org.jboss.gatein.selenium.usersmanagement.UsersManagementHelper.*;


public class Test_PRL_02_01_002_CheckUpdatingUsersListAfterRegisterNewOne extends AbstractTestCase {
	
	@Test(groups={"usersmanagement","one"})
	public void testPRL_02_01_002_CheckUpdatingUsersListAfterRegisterNewOne() throws Exception {
        
		System.out.println("-- Check updating users list after registering new one--");
		
		openPortal(true);
		
		signInAsRoot();
		
		goToNewStaff();
		
		addNewAccountAtNewStaff("test_prl_02_01_002", "Test_PRL_02_01_002", "Test_PRL_02_01_002", "Test_PRL_02_01_002", "Test_PRL_02_01_002", "Test_PRL_02_01_002@localhost.com", "", "Spanish", true);
		
		signOut();
		
		signIn("test_prl_02_01_002", "Test_PRL_02_01_002");

		waitForTextPresent(HOME_LABEL_SPANISH);
		
		signOut();
		
		System.out.println("-- Check existing registered users list--");

		signInAsRoot();
		
		goToUsersAndGroupsManagement();
		
		System.out.println("-- New user is updated into existing users list --");
		
		waitForTextPresent("test_prl_02_01_002");
		
		searchUserByUserName("test_prl_02_01_002");
		
		deleteUser("test_prl_02_01_002");
		
		waitForMessage("No result found.");
		closeMessageDialog();

		signOut();
	}

}
