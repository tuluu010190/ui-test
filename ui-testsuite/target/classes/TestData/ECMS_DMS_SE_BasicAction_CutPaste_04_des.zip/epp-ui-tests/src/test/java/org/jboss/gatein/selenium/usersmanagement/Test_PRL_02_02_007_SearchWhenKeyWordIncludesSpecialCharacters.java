package org.jboss.gatein.selenium.usersmanagement;

import org.jboss.gatein.selenium.AbstractTestCase;
import org.testng.annotations.Test;

import static org.jboss.gatein.selenium.common.CommonHelper.*;
import static org.jboss.gatein.selenium.usersmanagement.UsersManagementHelper.*;

public class Test_PRL_02_02_007_SearchWhenKeyWordIncludesSpecialCharacters extends AbstractTestCase {
	
	@Test(groups={"usersmanagement","one"})
	public void testPRL_02_02_007_SearchWhenKeyWordIncludesSpecialCharacters() throws Exception {
        
		System.out.println("-- Search when key word includes special characters--");

		openPortal(true);
		
		signInAsRoot();
		
		goToUsersAndGroupsManagement();
		
		System.out.println("-- Search User Name includes special characters--");
		
		searchUserByUserName("#$@$@$");

		waitForMessage("No result found.");
		closeMessageDialog();
		
		System.out.println("-- Return to user list--");
		
		searchUserByUserName("");

		System.out.println("-- Search Last Name includes special characters--");
		
		searchUser("#$@$@$", "Last Name");

		waitForMessage("No result found.");
		closeMessageDialog();
		
		System.out.println("-- Return to user list--");
		
		searchUserByUserName("");

		System.out.println("-- Search First Name includes special charactes--");
		
		searchUser("#$@$@$", "First Name");

		waitForMessage("No result found.");
		closeMessageDialog();
		
		System.out.println("-- Return to user list--");
		
		searchUserByUserName("");

		System.out.println("-- Search Email includes special characters--");

		searchUser("#@$%#%^#", "Email");

		waitForMessage("No result found.");
		closeMessageDialog();
		
		System.out.println("-- Return to user list--");
		
		searchUserByUserName("");
		
		signOut();
	}

}
