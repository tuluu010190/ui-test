package org.jboss.gatein.selenium.usersmanagement;

import org.jboss.gatein.selenium.AbstractTestCase;
import org.testng.annotations.Test;

import static org.jboss.gatein.selenium.common.CommonHelper.*;
import static org.jboss.gatein.selenium.language.LanguageHelper.*;
import static org.jboss.gatein.selenium.usersmanagement.UsersManagementHelper.*;

public class Test_PRL_02_04_001_DeleteSpecificUserFromExistingUsersListInCommunityManagement extends AbstractTestCase {
	
	@Test(groups={"usersmanagement","one"})
	public void testPRL_02_04_001_DeleteSpecificUserFromExistingUsersListInCommunityManagement() throws Exception {
        
		System.out.println("-- Add new user--");

		openPortal(true);
		
		signInAsRoot();
		
		goToNewStaff();
		
		addNewAccountAtNewStaff("test_prl_02_04_001", "Test_PRL_02_04_001", "Test_PRL_02_04_001", "Test_PRL_02_04_001", "Test_PRL_02_04_001", "Test_PRL_02_04_001@localhost.com", "", "German", true);
		
		signOut();
		
		System.out.println("-- Login in with new user--");
		
		signIn("test_prl_02_04_001", "Test_PRL_02_04_001");
		
        waitForTextPresent(HOME_LABEL_GERMAN);
        
		signOut();
		
		signInAsRoot();
		
		goToUsersAndGroupsManagement();
		
		searchUserByUserName("test_prl_02_04_001");
		
		deleteUser("test_prl_02_04_001");
		
		waitForMessage("No result found");
		closeMessageDialog();
		
		signOut();
	}

}
