package org.jboss.gatein.selenium.applicationregistry;

import java.util.HashMap;
import java.util.Map;

import org.jboss.gatein.selenium.AbstractTestCase;
import org.testng.Assert;
import org.testng.annotations.Test;

import static org.jboss.gatein.selenium.common.CommonHelper.*;
import static org.jboss.gatein.selenium.applicationregistry.ApplicationRegistryHelper.*;
import static org.jboss.gatein.selenium.page.PageHelper.*;
import static org.jboss.gatein.selenium.navigation.NavigationHelper.*;
import static org.jboss.gatein.selenium.dashboard.DashboardHelper.*;
import static org.jboss.gatein.selenium.permission.PermissionHelper.*;

public class Test_PRL_05_06_004_LimitAccessRightInNonPublicCategoryGroupMembershipCategoryAreDifferent extends AbstractTestCase {
	
	@Test(groups={"applicationregistry"})
	public void testPRL_05_06_004_LimitAccessRightInNonPublicCategoryGroupMembershipCategoryAreDifferent() throws Exception {
        
        String verification = ELEMENT_DASHBOARD_SELECTED_PAGE_WITH_SPECIFIED_NAME.replace("${dashboardName}", "Test_PRL_05_06_004");
        
		System.out.println("-- Limit access right for application in not public category group/membership to access application & category are not the same--");

		openPortal(true);
		
		signInAsRoot();
		
		goToApplicationRegistry();
		
		Map<String, String> permissions = new HashMap<String, String>();
		permissions.put("Platform/Administrators", "*");
		addNewCategory("Test_PRL_05_06_004", "Test_PRL_05_06_004", "Test_PRL_05_06_004", false, permissions, true);
		
		addApplicationToCategory("Test_PRL_05_06_004", PortletType.PORTLET, "Dashboard Portlet", "");
		
		Assert.assertTrue(isSelected(ELEMENT_CHECKBOX_PUBLIC_MODE));
		
		signOut();

		System.out.println("-- Add new page which user has right to access category but does not have right to access application--");

		signInAsJohn();

		goToNewStaff();
		
        Map<String, String> portletIdsAndVerifications = new HashMap<String, String>();
        portletIdsAndVerifications.put("Test_PRL_05_06_004/DashboardPortlet", "Dashboard Portlet");
		addNewPageWithEditorAtFirstLevel("Test_PRL_05_06_004", "Test_PRL_05_06_004", "Test_PRL_05_06_004", portletIdsAndVerifications, false, null);
		
		signOut();

		System.out.println("-- Add new page which user has right to access the application but does not have right to access the category--");

		signInAsMary();
		
		goToDashboard();
		
		addNewPageWithEditor(null, "Test_PRL_05_06_004", "Test_PRL_05_06_004", null, null, false, null);

		signOut();

		System.out.println("-- Delete category--");

		signInAsRoot();
		
		goToApplicationRegistry();
		
		deleteCategory("Test_PRL_05_06_004");
		
		System.out.println("-- Delete page user has right to access category but does not have right to access application --");

		goToGroup();
		
		deleteNodeFromNavigation("Executive Board", "Test_PRL_05_06_004", "New Staff", true);
		
		signOut();

		System.out.println("-- Delete page which user has right to access the application but does not have right to access the category--");

		signInAsMary();
		
		goToDashboard();
		
		goToPage(verification, ELEMENT_LINK_DASHBOARD, "Test_PRL_05_06_004");
		
		deleteSelectedPage("Test_PRL_05_06_004");

		signOut();
		
		signInAsRoot();
		
		goToPageManagement();
		
		searchAndDeletePage(PageType.GROUP, "page", "Test_PRL_05_06_004", true, "Test_PRL_05_06_004");
		
		signOut();
	}

}
