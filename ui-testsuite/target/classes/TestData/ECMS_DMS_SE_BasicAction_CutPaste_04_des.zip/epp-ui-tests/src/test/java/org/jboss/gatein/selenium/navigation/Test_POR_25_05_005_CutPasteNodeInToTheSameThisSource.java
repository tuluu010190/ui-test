package org.jboss.gatein.selenium.navigation;

import static org.jboss.gatein.selenium.common.CommonHelper.*;
import static org.jboss.gatein.selenium.navigation.NavigationHelper.*;

import org.jboss.gatein.selenium.AbstractTestCase;
import org.jboss.gatein.selenium.navigation.NavigationHelper.CopyType;
import org.testng.annotations.Test;

public class Test_POR_25_05_005_CutPasteNodeInToTheSameThisSource extends AbstractTestCase {
	
	@Test(groups={"navigation"})
	public void testPOR_25_05_005_CutPasteNodeInToTheSameThisSource() throws Exception {
        
		String newStaffNode = ELEMENT_NODE_LINK.replace("${nodeLabel}", "New Staff");
		
		System.out.println("--CutPasteNodeInToTheSameSource--");

		openPortal(true);
		
		signInAsRoot();
		
		goToGroup();
		
		editNavigation("Executive Board");
		
		copyNode(CopyType.CUT, null, "New Staff", newStaffNode, null);

		waitForMessage("The source and the destination must be different.");
		
		closeMessageDialog();
		
		save();
		
		waitForTextNotPresent("Navigation Management");
		
		signOut();
	}

}
