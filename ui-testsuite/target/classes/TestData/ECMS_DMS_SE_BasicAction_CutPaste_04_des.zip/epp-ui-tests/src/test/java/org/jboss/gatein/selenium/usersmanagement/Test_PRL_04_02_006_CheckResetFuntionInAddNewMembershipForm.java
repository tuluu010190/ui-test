package org.jboss.gatein.selenium.usersmanagement;

import org.jboss.gatein.selenium.AbstractTestCase;
import org.testng.Assert;
import org.testng.annotations.Test;

import static org.jboss.gatein.selenium.common.CommonHelper.*;
import static org.jboss.gatein.selenium.usersmanagement.UsersManagementHelper.*;

public class Test_PRL_04_02_006_CheckResetFuntionInAddNewMembershipForm extends AbstractTestCase {
	
	@Test(groups={"usersmanagement","two"})
	public void testPRL_04_02_006_CheckResetFuntionInAddNewMembershipForm()	throws Exception {
        
		System.out.println("-- Check reset function in membership form --");
		
		openPortal(true);
		
		signInAsRoot();
		
		goToUsersAndGroupsManagement();
		
		chooseMembershipTab();
		
		type(ELEMENT_INPUT_NAME, "Test_PRL_04_02_006", true);
		
		type(ELEMENT_TEXTAREA_DESCRIPTION, "Test_PRL_04_02_006", true);
		
		click(ELEMENT_RESET_BUTTON);
		
		pause(500);
		
		Assert.assertEquals(getValue(ELEMENT_INPUT_NAME), "");
		
		Assert.assertEquals(getValue(ELEMENT_TEXTAREA_DESCRIPTION), "");
		
		signOut();
	}

}
