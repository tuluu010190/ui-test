package org.jboss.gatein.selenium.usersmanagement;

import org.jboss.gatein.selenium.AbstractTestCase;
import org.testng.annotations.Test;

import static org.jboss.gatein.selenium.common.CommonHelper.*;
import static org.jboss.gatein.selenium.usersmanagement.UsersManagementHelper.*;

public class Test_PRL_03_06_001_EditMembershipForUserFromExistingGroup extends AbstractTestCase {
	
	@Test(groups={"usersmanagement","two"})
	public void testPRL_03_06_001_EditMembershipForUserFromExistingGroup() throws Exception {
        
		String userEditIcon = ELEMENT_GROUP_USER_IN_TABLE_EDIT_ICON.replace("${membership}", "manager").replace("${username}", "root");
		
		System.out.println("-- Edit Membership for user from existing group--");
		
		openPortal(true);
		
		signInAsRoot();
		
		goToUsersAndGroupsManagement();
		
		chooseGroupTab();

		selectGroup("Platform/Administrators");
		
		System.out.println("-- Edit membership--");

		click(userEditIcon);
		
        pause(500);
        
		select(ELEMENT_SELECT_MEMBERSHIP, "manager");

		save();
        
        waitForMessage("Membership type already exists, please enter another one.");
        closeMessageDialog();

		signOut();
	}

}
