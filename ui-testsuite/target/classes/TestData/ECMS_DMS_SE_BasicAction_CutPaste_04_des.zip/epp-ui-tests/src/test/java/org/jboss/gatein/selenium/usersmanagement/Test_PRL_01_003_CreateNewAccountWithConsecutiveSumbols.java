package org.jboss.gatein.selenium.usersmanagement;

import org.jboss.gatein.selenium.AbstractTestCase;
import org.testng.annotations.Test;

import static org.jboss.gatein.selenium.common.CommonHelper.*;
import static org.jboss.gatein.selenium.usersmanagement.UsersManagementHelper.*;

public class Test_PRL_01_003_CreateNewAccountWithConsecutiveSumbols extends AbstractTestCase {
	
	@Test(groups={"usersmanagement","one"})
	public void testPRL_01_003_CreateNewAccountWithConsecutiveSumbols() throws Exception {
        
		System.out.println("-- Create new account with user name contains consecutive symbols.--");

		openPortal(true);
		
		signInAsRoot();
		
		goToNewStaff();

		addNewAccountAtNewStaff("test_prl_01___003", "Test_POR_01_003", "Test_POR_01_003", "Test_POR_01_003", "Test_POR_01_003", "Test_POR_01_003@localhost.com", "", "English", false);
		
		waitForMessage("The field \"User Name\" cannot contain consecutive symbols. Allowed symbols are: '_', '.'.");
		closeMessageDialog();
		
		signOut();
	}

}
