package org.jboss.gatein.selenium.usersmanagement;

import org.jboss.gatein.selenium.AbstractTestCase;
import org.testng.annotations.Test;

import static org.jboss.gatein.selenium.common.CommonHelper.*;
import static org.jboss.gatein.selenium.usersmanagement.UsersManagementHelper.*;
import static org.jboss.gatein.selenium.page.PageHelper.*;
import static org.jboss.gatein.selenium.navigation.NavigationHelper.*;

public class Test_PRL_03_07_004_CheckShowGroupPageListAfterUserWasRemovedFromGroupWith1Role extends AbstractTestCase {
	
	@Test(groups={"usersmanagement","two"})
	public void testPRL_03_07_004_CheckShowGroupPageListAfterUserWasRemovedFromGroupWith1Role()	throws Exception {
        
        String verification = LOGO_PORTLET.replace("${text}", "Executive Board");
		
		System.out.println("-- Check showing group's pages list after user was removed from group with 1 role--");
		
		openPortal(true);
		
		signInAsRoot();
		
		goToNewStaff();
		
		addNewAccountAtNewStaff("test_prl_03_07_004", "Test_PRL_03_07_004", "Test_PRL_03_07_004", "Test_PRL_03_07_004", "Test_PRL_03_07_004", "Test_PRL_03_07_004@localhost.com", "", "English", true);
		
		System.out.println("-- Go to Users and group Management--");
		
		goToUsersAndGroupsManagement();
		
		chooseGroupTab();

		System.out.println("-- Add existing user in a specific group with 1 or more roles--");

		selectGroup("Organization/Management/Executive Board");
		
		addUsersAtGroup("test_prl_03_07_004", "manager", true, true);
		
		addUsersAtGroup("test_prl_03_07_004", "member", true, true);
		
		signOut();
		
		signIn("test_prl_03_07_004", "Test_PRL_03_07_004");
		
		goToUsersAndGroupsManagement();

		addNewPageWithEditor(null, "Test_PRL_03_07_004", "Test_PRL_03_07_004", null, null, false, null);
		
		goToUsersAndGroupsManagement();

		addNewPageWithEditor(null, "Test_PRL_03_07_004_add", "Test_PRL_03_07_004_add", null, null, false, null);

		signOut();
		
		signInAsRoot();
		
		goToUsersAndGroupsManagement();
		
		chooseGroupTab();
		
		selectGroup("Organization/Management/Executive Board");
		
		System.out.println("-- Delete user in group with 1 role--");
		
		deleteUserFromGroup("test_prl_03_07_004", "member", "organization/management/executive-board", false);
		
		signOut();
		
		signIn("test_prl_03_07_004", "Test_PRL_03_07_004");

		goToPage(verification, ELEMENT_LINK_GROUP, ELEMENT_LINK_ORGANIZATION, ELEMENT_LINK_USERS_MANAGEMENT, "Test_PRL_03_07_004");
		
        goToSiteClassicHome();
        
		goToPage(verification, ELEMENT_LINK_GROUP, ELEMENT_LINK_ORGANIZATION, ELEMENT_LINK_USERS_MANAGEMENT, "Test_PRL_03_07_004_add");
		
		signOut();
		
		signInAsRoot();
		
		goToUsersAndGroupsManagement();
		
		chooseGroupTab();
		
		selectGroup("Organization/Management/Executive Board");
		
		deleteUserFromGroup("test_prl_03_07_004", "manager", "organization/management/executive-board", true);
		
		signOut();
		
		signIn("test_prl_03_07_004", "Test_PRL_03_07_004");

		mouseOver(ELEMENT_LINK_GROUP, true);
		
		waitForTextNotPresent("//a[text()='Organization']");
		
		waitForTextNotPresent("//a[text()='Test_PRL_03_07_004']");
		
		waitForTextNotPresent("//a[text()='Test_PRL_03_07_004_add']");
		
		signOut();
		
		signInAsRoot();
		
		goToUsersAndGroupsManagement();
		
		deleteUser("test_prl_03_07_004");
		
		goToGroup();
		
		deleteNodeFromNavigation("Executive Board", "Test_PRL_03_07_004", "Users and groups management", true);
		
		deleteNodeFromNavigation("Executive Board", "Test_PRL_03_07_004_add", "Users and groups management", true);
		
		goToPageManagement();
		
		searchAndDeletePage(PageType.GROUP, "page", "Test_PRL_03_07_004_add", true, "Test_PRL_03_07_004_add");
		
		searchAndDeletePage(PageType.GROUP, "page", "Test_PRL_03_07_004", true, "Test_PRL_03_07_004");
		
		signOut();
	}

}
