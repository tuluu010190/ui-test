package org.jboss.gatein.selenium.page;

import org.jboss.gatein.selenium.AbstractTestCase;
import org.testng.annotations.Test;

import static org.jboss.gatein.selenium.common.CommonHelper.*;
import static org.jboss.gatein.selenium.page.PageHelper.*;

public class Test_POR_20_020_CreateSameNameGroupPagesInDifferentGroups extends AbstractTestCase {
	
	@Test(groups={"epp5.0", "page"})
	public void testPOR_20_020_CreateSameNameGroupPagesInDifferentGroups() throws Exception {
        
		System.out.println("--CreateSameNameGroupPagesInDifferentGroups--");

		openPortal(true);
		
		signInAsRoot();

		goToPageManagement();

		addNewPageAtPageManagement("POR_20_020", "POR_20_020", PageType.GROUP, "/platform/users", "group::/platform/users::POR_20_020");
		
		addNewPageAtPageManagement("POR_20_020", "POR_20_020", PageType.GROUP, "/organization", "group::/organization::POR_20_020");

		searchAndDeletePage(PageType.GROUP, "POR_20_020", "POR_20_020", false, "group::/organization::POR_20_020");
		
		searchAndDeletePage(PageType.GROUP, "POR_20_020", "POR_20_020", true, "group::/platform/users::POR_20_020");

		signOut();
	}

}
