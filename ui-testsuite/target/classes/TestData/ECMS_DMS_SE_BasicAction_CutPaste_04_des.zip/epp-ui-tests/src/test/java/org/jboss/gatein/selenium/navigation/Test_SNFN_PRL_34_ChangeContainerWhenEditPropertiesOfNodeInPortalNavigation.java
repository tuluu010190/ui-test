package org.jboss.gatein.selenium.navigation;

import org.jboss.gatein.selenium.AbstractTestCase;
import org.testng.annotations.Test;

import static org.jboss.gatein.selenium.common.CommonHelper.*;
import static org.jboss.gatein.selenium.navigation.NavigationHelper.*;
import static org.jboss.gatein.selenium.page.PageHelper.*;

public class Test_SNFN_PRL_34_ChangeContainerWhenEditPropertiesOfNodeInPortalNavigation extends AbstractTestCase {
	
	@Test(groups={"sniff", "navigation"})
	public void testSNFN_PRL_34_ChangeContainerWhenEditPropertiesOfNodeInPortalNavigation()	throws Exception {
        
		String node = ELEMENT_NODE_LINK.replace("${nodeLabel}", "Test_SNF_PRL_34");
        String pageVerification = BREADCRUMB_PORTLET_SELECTED_NODE.replace("${node_label}", "Test_SNF_PRL_34");
        String emptyContainerPosition1 = EMPTY_CONTAINER.replace("${portletNumber}", "1");
		
		System.out.println("-- Edit Node page's properties in portal navigation--");
		
		openPortal(true);
		
		signInAsRoot();
		
		goToSite();
		
		addNewNode("Test_SNF_PRL_34", "Test_SNF_PRL_34", true, null, "Test_SNF_PRL_34", "Test_SNF_PRL_34", true, true, false, null);

		System.out.println("-- View new node--");
		
        goToPage(pageVerification, ELEMENT_LINK_SITE, ELEMENT_LINK_CLASSIC_PORTAL, ELEMENT_LINK_HOME, "Test_SNF_PRL_34");

		goToSite();
		
		System.out.println("-- Change container when edit page properties of node --");

		editFirstNavigation();
		
		contextMenuOnElement(node);
		
		click(ELEMENT_NODE_EDIT_NODE_PAGE);

		System.out.println("-- View layout of node before Change container--");

		click(ELEMENT_SWITCH_VIEW_MODE_PAGE);
		
		click(ELEMENT_SWITCH_VIEW_MODE_PAGE);
		
		System.out.println("-- Change container--");

		click(ELEMENT_CONTAINERS_TAB);

        String elementEditPagePage = ELEMENT_EDIT_PAGE_PAGE;

        if (ieFlag) {
            elementEditPagePage = ELEMENT_EDIT_PAGE_PAGE + "/..";
        }
		
		dragAndDropToObject(ELEMENT_ONE_ROW_CONTAINER, elementEditPagePage, emptyContainerPosition1);
		
		click(ELEMENT_SWITCH_VIEW_MODE_PAGE);
		
		click(ELEMENT_SWITCH_VIEW_MODE_PAGE);
		
		System.out.println("--Edit container --");

        editSpecifiedPortletOrContainer("1", false, ELEMENT_INPUT_TITLE);

		type(ELEMENT_INPUT_TITLE, "Test_SNF_PRL_34", true);

		type(ELEMENT_INPUT_WIDTH, "300px", true);

		type(ELEMENT_INPUT_HEIGHT, "100px", true);

		save();

		click(ELEMENT_SWITCH_VIEW_MODE_PAGE);
		
		click(ELEMENT_SWITCH_VIEW_MODE_PAGE);
		
		System.out.println("--Delete container --");
		
        deleteSpecifiedPortletOrContainer(ContainerType.CONTAINER, "1", false);
		
		finishPageEdit();
		
		System.out.println("-- Close Navigation Management form --");

		save();

		System.out.println("-- View node after change container --");
        
		pause(500);
        
        goToPage(pageVerification, ELEMENT_LINK_SITE, ELEMENT_LINK_CLASSIC_PORTAL, ELEMENT_LINK_HOME, "Test_SNF_PRL_34");

		goToSite();

		deleteNodeFromFirstNavigation("Test_SNF_PRL_34", null, true);
		
		goToPageManagement();
		
		searchAndDeletePage(PageType.PORTAL, "Test_SNF_PRL_34", "Test_SNF_PRL_34", true, "Test_SNF_PRL_34");
		
		signOut();
	}

}
