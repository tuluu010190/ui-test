package org.jboss.gatein.selenium.language;

import static org.jboss.gatein.selenium.common.CommonHelper.*;
import static org.jboss.gatein.selenium.language.LanguageHelper.*;

import org.jboss.gatein.selenium.AbstractTestCase;
import org.testng.annotations.Test;

public class Test_POR_07_004_CheckDisplayLanguageOfPortalInPrivateModeWithDemoAccount extends AbstractTestCase {
	
    @Test(groups={"epp5.0", "language"})
	public void testPOR_07_004_CheckDisplayLanguageOfPortalInPrivateModeWithDemoAccount() throws Exception {
		System.out.println("--ChangeLanguagePrivateMode by root--");
		
		openPortal(true);
		
        signInAsRoot();
        changeLanguage(LANGUAGE_FRENCH);
        System.out.println("--Verify--");
        waitForTextPresent(HOME_LABEL_FRENCH);
        changeLanguage(LANGUAGE_ENGLISH);
        signOut();
        
		System.out.println("--ChangeLanguagePrivateMode by john--");

		signInAsJohn();
        changeLanguage(LANGUAGE_GERMAN);
        System.out.println("--Verify--");
        waitForTextPresent(HOME_LABEL_GERMAN);
        changeLanguage(LANGUAGE_ENGLISH);
        signOut();
                
        System.out.println("--ChangeLanguagePrivateMode by demo--");
		
		signInAsDemo();
        changeLanguage(LANGUAGE_SPANISH);
        System.out.println("--Verify--");
        waitForTextPresent(HOME_LABEL_SPANISH);
        changeLanguage(LANGUAGE_ENGLISH);
        signOut();
	}
}
