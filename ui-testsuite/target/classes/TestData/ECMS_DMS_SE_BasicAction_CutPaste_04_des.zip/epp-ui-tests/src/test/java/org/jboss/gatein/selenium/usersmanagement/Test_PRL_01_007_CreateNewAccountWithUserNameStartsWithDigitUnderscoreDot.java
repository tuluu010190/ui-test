package org.jboss.gatein.selenium.usersmanagement;

import org.jboss.gatein.selenium.AbstractTestCase;
import org.testng.annotations.Test;

import static org.jboss.gatein.selenium.common.CommonHelper.*;
import static org.jboss.gatein.selenium.usersmanagement.UsersManagementHelper.*;

public class Test_PRL_01_007_CreateNewAccountWithUserNameStartsWithDigitUnderscoreDot extends AbstractTestCase {
	
	@Test(groups={"usersmanagement","one"})
	public void testPRL_01_007_CreateNewAccountWithUserNameStartsWithDigitUnderscoreDot() throws Exception {
        
		System.out.println("-- Create new account with user name starts with digit, underscore, dot--");
		
		openPortal(true);
		
		signInAsRoot();
		
		goToNewStaff();

		addNewAccountAtNewStaff("_test_prl_01_007", "Test_PRL_01_007", "Test_PRL_01_007", "Test_PRL_01_007", "Test_PRL_01_007", "Test_PRL_01_007@localhost.com", "", "Russian", false);
		
		waitForMessage("The \"User Name\" field must start with a lowercase letter.");
		closeMessageDialog();
		
		addNewAccountAtNewStaff(".test_prl_01_007", "Test_PRL_01_007", "Test_PRL_01_007", "Test_PRL_01_007", "Test_PRL_01_007", "Test_PRL_01_007@localhost.com", "", "Russian", false);
		
		waitForMessage("The \"User Name\" field must start with a lowercase letter.");
		closeMessageDialog();
		
		addNewAccountAtNewStaff("01_007_test", "Test_PRL_01_007", "Test_PRL_01_007", "Test_PRL_01_007", "Test_PRL_01_007", "Test_PRL_01_007@localhost.com", "", "Russian", false);
		
		waitForMessage("The \"User Name\" field must start with a lowercase letter.");
		closeMessageDialog();
		
		signOut();
	}

}
