package org.jboss.gatein.selenium.usersmanagement;

import static org.jboss.gatein.selenium.common.CommonHelper.*;
import static org.jboss.gatein.selenium.usersmanagement.UsersManagementHelper.*;

import org.jboss.gatein.selenium.AbstractTestCase;
import org.testng.annotations.Test;

public class Test_PRL_03_02_005_AddNewGroupIsTheSameWithExistingButDifferentWithLowerAndUpperCase extends AbstractTestCase {
	
	@Test(groups={"usersmanagement"})
	public void testPRL_03_02_005_AddNewGroupIsTheSameWithExistingButDifferentWithLowerAndUpperCase() throws Exception {
        
		System.out.println("--Add new group is lower case--");

		openPortal(true);
		
		signInAsRoot();

		goToUsersAndGroupsManagement();
		
		chooseGroupTab();
		
		addNewGroup("test_prl_03_02_005", "test_prl_03_02_005", "test_prl_03_02_005", true);
		
		click(ELEMENT_GROUP_LEVEL_UP_ICON);
		
		System.out.println("-- Add new group is upper case--");
		
		addNewGroup("TEST_PRL_03_02_005", "TEST_PRL_03_02_005", "TEST_PRL_03_02_005", false);
		
        if (allowedNotCaseSensitiveSearch) {
            waitForMessage("This group name already exists, please enter another one");
            closeMessageDialog();
        } else {
            selectGroup("TEST_PRL_03_02_005");

            deleteGroup("TEST_PRL_03_02_005", true);
        }
        selectGroup("test_prl_03_02_005");

        deleteGroup("test_prl_03_02_005", true);
        
		signOut();
	}

}
