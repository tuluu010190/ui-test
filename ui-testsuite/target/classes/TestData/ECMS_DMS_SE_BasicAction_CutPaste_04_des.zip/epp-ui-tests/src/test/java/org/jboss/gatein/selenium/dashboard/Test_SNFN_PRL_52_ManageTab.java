package org.jboss.gatein.selenium.dashboard;

import org.jboss.gatein.selenium.AbstractTestCase;
import org.testng.annotations.Test;

import static org.jboss.gatein.selenium.common.CommonHelper.*;
import static org.jboss.gatein.selenium.dashboard.DashboardHelper.*;

public class Test_SNFN_PRL_52_ManageTab extends AbstractTestCase {
	
	@Test(groups={"sniff", "dashboard"})
	public void testSNFN_PRL_52_ManageTab() throws Exception {
		System.out.println("-- Manage Tab--");
		
		openPortal(true);
		
		signInAsRoot();
		
		goToDashboard();
		
		System.out.println("-- Add new tab--");

		addNewPageOnDashboard("Test_SNF_PRL_52", true);

		System.out.println("-- Edit tab--");
		
		editPageNameOnDashboard("Test_SNF_PRL_52", "Test_SNF_PRL_52_edit");

		deleteSelectedPage("Test_SNF_PRL_52_edit");

		signOut();
	}

}
