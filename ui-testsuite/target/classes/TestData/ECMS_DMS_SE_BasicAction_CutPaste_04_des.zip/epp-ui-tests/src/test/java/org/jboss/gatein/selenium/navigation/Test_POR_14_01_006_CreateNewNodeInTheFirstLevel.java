package org.jboss.gatein.selenium.navigation;

import org.jboss.gatein.selenium.AbstractTestCase;
import org.testng.annotations.Test;

import static org.jboss.gatein.selenium.common.CommonHelper.*;
import static org.jboss.gatein.selenium.navigation.NavigationHelper.*;

public class Test_POR_14_01_006_CreateNewNodeInTheFirstLevel extends AbstractTestCase {
	
	@Test(groups={"epp5.0", "navigation"})
	public void testPOR_14_01_006_CreateNewNodeInTheFirstLevel() throws Exception {
        
		System.out.println("-CreateNewNodeInTheFirstLevel-");
		
		openPortal(true);

		signInAsRoot();

		goToGroup();
		
		addNewNode("POR_14_01_006", "POR_14_01_006", true, null, null, null, false, true, false, null);

		deleteNodeFromFirstNavigation("POR_14_01_006", null, true);
		
		signOut();
	}

}
