package org.jboss.gatein.selenium.navigation;

import static org.jboss.gatein.selenium.common.CommonHelper.*;
import static org.jboss.gatein.selenium.navigation.NavigationHelper.*;
import static org.jboss.gatein.selenium.page.PageHelper.*;

import org.jboss.gatein.selenium.AbstractTestCase;
import org.jboss.gatein.selenium.page.PageHelper.PageType;
import org.testng.annotations.Test;

public class Test_POR_14_01_032_CreateNewNodeWithPageNameTheSameWithExisting extends AbstractTestCase {
	
	@Test(groups={"navigation"})
	public void testPOR_14_01_032_CreateNewNodeWithPageNameTheSameWithExisting() throws Exception {
        
		System.out.println("--CreateNewNodeWithPageNameTheSameWithExisting--");

		openPortal(true);
		
		signInAsRoot();

		goToSite();
		
		addNewNode("POR_14_01_032", "POR_14_01_032", true, null, "POR_14_01_032", "POR_14_01_032", true, true, false, null);
		
		addNewNode("POR_14_01_032_add", "POR_14_01_032_add", true, null, "POR_14_01_032", "POR_14_01_032", false, false, false, null);
		
		waitForMessage("This page name already exists.");
		
		closeMessageDialog();
		
		click(ELEMENT_BACK_BUTTON);
		
		waitForTextNotPresent("Page Node Setting");

		save();
		
		waitForTextNotPresent("Navigation Management");
		
		deleteNodeFromFirstNavigation("POR_14_01_032", null, true);
		
		goToPageManagement();
		
		searchAndDeletePage(PageType.PORTAL, "POR_14_01_032", "POR_14_01_032", true, "portal::classic::POR_14_01_032");
		
		signOut();
	}

}
