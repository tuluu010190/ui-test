package org.jboss.gatein.selenium.applicationregistry;

import static org.jboss.gatein.selenium.common.CommonHelper.*;
import static org.jboss.gatein.selenium.page.PageHelper.*;
import static org.jboss.gatein.selenium.applicationregistry.ApplicationRegistryHelper.*;

import org.jboss.gatein.selenium.AbstractTestCase;
import org.testng.annotations.Test;

public class Test_SNF_PRL_14_ShowOrNotImportApplicationIcon extends AbstractTestCase {
	
	@Test(groups={"sniff", "epp5.0", "applicationregistry"})
	public void testSNF_PRL_14_ShowOrNotImportApplicationIcon() throws Exception {
        
		System.out.println("--Show or not show Import Application Icon--");
		
		openPortal(true);

		signInAsRoot();

		goToApplicationRegistry();
		
		waitForAndGetElement(ELEMENT_IMPORT_ICON);

		System.out.println("--Uncheck icon presence by editing the page");

		goToEditPage();
		
        editSpecifiedPortletOrContainer("1", false, ELEMENT_CHECKBOX_SHOW_IMPORT_EDIT_MODE);
		
		uncheck(ELEMENT_CHECKBOX_SHOW_IMPORT_EDIT_MODE);
		
		save();
		
		close();
		
		finishPageEdit();
		
		System.out.println("--Verify");

		waitForElementNotPresent(ELEMENT_IMPORT_ICON);

		System.out.println("--Edit to bring back Icon");

		goToEditPage();
		
        editSpecifiedPortletOrContainer("1", false, ELEMENT_CHECKBOX_SHOW_IMPORT_EDIT_MODE);
		
		check(ELEMENT_CHECKBOX_SHOW_IMPORT_EDIT_MODE);
		
		save();
		
		close();
		
		finishPageEdit();
		
		System.out.println("--Verify");
		
		waitForAndGetElement(ELEMENT_IMPORT_ICON);

		signOut();
	}
}
