package org.jboss.gatein.selenium.usersmanagement;

import org.jboss.gatein.selenium.AbstractTestCase;
import org.testng.annotations.Test;

import static org.jboss.gatein.selenium.common.CommonHelper.*;
import static org.jboss.gatein.selenium.usersmanagement.UsersManagementHelper.*;

public class Test_PRL_01_005_CreateNewAccountWithUserNameIncludesSpecialCharacers extends AbstractTestCase {
	
	@Test(groups={"usersmanagement","one"})
	public void testPRL_01_005_CreateNewAccountWithUserNameIncludesSpecialCharacers() throws Exception {
        
		System.out.println("-- Create new account with user name includes special characters--");

		openPortal(true);
		
		signInAsRoot();
		
		goToNewStaff();

		addNewAccountAtNewStaff("@%$%^&!", "Test_POR_01_005", "Test_POR_01_005", "Test_POR_01_005", "Test_POR_01_005", "Test_POR_01_005@localhost.com", "", "Russian", false);
		
		waitForMessage("Only lowercase letters, digits, dot and underscore characters are allowed for the field \"User Name\".");
		waitForMessage("The field \"User Name\" must end with a lowercase letter or digit instead of \"!\".");
		closeMessageDialog();
		
		signOut();
	}

}
