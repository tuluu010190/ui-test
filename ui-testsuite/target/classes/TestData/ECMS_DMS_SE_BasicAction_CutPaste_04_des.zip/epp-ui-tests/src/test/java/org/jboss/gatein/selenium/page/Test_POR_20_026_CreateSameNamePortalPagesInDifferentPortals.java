package org.jboss.gatein.selenium.page;

import org.jboss.gatein.selenium.AbstractTestCase;
import org.testng.annotations.Test;

import static org.jboss.gatein.selenium.common.CommonHelper.*;
import static org.jboss.gatein.selenium.page.PageHelper.*;
import static org.jboss.gatein.selenium.portal.PortalHelper.*;

public class Test_POR_20_026_CreateSameNamePortalPagesInDifferentPortals extends AbstractTestCase {
	
	@Test(groups={"epp5.0", "page"})
	public void testPOR_20_026_CreateSameNamePortalPagesInDifferentPortals() throws Exception {
        
		System.out.println("--CreateSameNamePortalPagesInDifferentPortals--");

		openPortal(true);
		
		signInAsRoot();
		
		goToPageManagement();

		System.out.println("--Add new page for current portal --");

		addNewPageAtPageManagement("POR_20_026", "POR_20_026", PageType.PORTAL, null, "portal::classic::POR_20_026");
		
		goToSite();

		createNewPortal("Test_POR_20_026", "English", "Default", "On Demand", true, null, "Platform/Administrators", "*");

		verifyPortalExists("Test_POR_20_026");

		System.out.println("--View new portal");

		goToPage(ELEMENT_TEST_USER_ADMIN, ELEMENT_LINK_SITE, "Test_POR_20_026");
        
        goToSite();
        
		goToPage(ELEMENT_TEST_USER_ADMIN, ELEMENT_LINK_SITE, "Test_POR_20_026", ELEMENT_LINK_HOME);

		goToPageManagement();
		
		addNewPageAtPageManagement("POR_20_026", "POR_20_026", PageType.PORTAL, null, "portal::Test_POR_20_026::POR_20_026");

		searchAndDeletePage(PageType.PORTAL, "POR_20_026", "POR_20_026", false, "portal::Test_POR_20_026::POR_20_026");
		
		searchAndDeletePage(PageType.PORTAL, "POR_20_026", "POR_20_026", true, "portal::classic::POR_20_026");

		System.out.println("--Go to Site--");

		openPortal(false);

		goToSite();
		
		deletePortal("Test_POR_20_026");

		signOut();
	}

}
