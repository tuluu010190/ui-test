package org.jboss.gatein.selenium.dashboard;

import org.jboss.gatein.selenium.AbstractTestCase;
import static org.jboss.gatein.selenium.common.CommonHelper.*;
import static org.jboss.gatein.selenium.dashboard.DashboardHelper.*;
import static org.jboss.gatein.selenium.page.PageHelper.*;

import org.testng.annotations.Test;

public class Test_SNF_PRL_29_AddAndEditAndDeleteTab extends AbstractTestCase {
	
	@Test(groups={"sniff", "epp5.0", "dashboard"})
	public void testSNF_PRL_29_AddAndEditAndDeleteTab() throws Exception {
        
        String editedDashboardPage = ELEMENT_DASHBOARD_UNSELECTED_PAGE_WITH_SPECIFIED_NAME.replace("${dashboardName}", "test_dashboardpage_edit_29");
        
		System.out.println("-AddEditPageEditLayoutDashboard-");
		
		openPortal(true);

		signInAsRoot();

		goToDashboard();
		
		System.out.println("--Add new page in dashboard");
		
		addNewPageOnDashboardWithEditor("test_dashboardpage_29", "test_dashboardpage_name_29", false, null);
		
		editPageNameOnDashboard("test_dashboardpage_name_29", "test_dashboardpage_edit_29");
		
        goToDashboard();
        
		click(editedDashboardPage);

		waitForAndGetElement(ELEMENT_DASHBOARD_SELECTED);
		
		System.out.println("--Go to Edit layout");
		
		goToEditLayout();

		System.out.println("--Choose Portal Properties--");

		click(ELEMENT_SITE_CONFIG_LINK);

		select(ELEMENT_SELECT_LOCALE, "English");
		
		click(ELEMENT_PROPERTIES_TAB);

		save();
		
		click(ELEMENT_EDIT_LAYOUT_FINISH_BUTTON);

		deleteSelectedPage("test_dashboardpage_edit_29");

		signOut();
	}

}
