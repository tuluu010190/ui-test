package org.jboss.gatein.selenium.usersmanagement;

import org.jboss.gatein.selenium.AbstractTestCase;
import org.testng.annotations.Test;

import static org.jboss.gatein.selenium.common.CommonHelper.*;
import static org.jboss.gatein.selenium.usersmanagement.UsersManagementHelper.*;

public class Test_PRL_03_03_006_EditDescriptionOfGroup extends AbstractTestCase {
	
	@Test(groups={"usersmanagement","two"})
	public void testPRL_03_03_006_EditDescriptionOfGroup() throws Exception {
        
		System.out.println("-- Edit Description of group--");
		
		openPortal(true);
		
		signInAsRoot();
		
		goToUsersAndGroupsManagement();
		
		chooseGroupTab();

		addNewGroup("Test_PRL_03_03_006", "Test_PRL_03_03_006", "Test_PRL_03_03_006", true);
		
		System.out.println("-- edit description--");
		
		click(ELEMENT_GROUP_EDIT_SELECTED);

		type(ELEMENT_TEXTAREA_DESCRIPTION, "Test_PRL_03_03_006_edit", true);

		save();

		deleteGroup("Test_PRL_03_03_006", true);
		
		signOut();
	}

}
