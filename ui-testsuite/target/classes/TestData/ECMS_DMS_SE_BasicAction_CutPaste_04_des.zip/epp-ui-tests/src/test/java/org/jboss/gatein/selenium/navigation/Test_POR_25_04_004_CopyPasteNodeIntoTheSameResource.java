package org.jboss.gatein.selenium.navigation;

import org.jboss.gatein.selenium.AbstractTestCase;
import org.testng.annotations.Test;

import static org.jboss.gatein.selenium.common.CommonHelper.*;
import static org.jboss.gatein.selenium.navigation.NavigationHelper.*;

public class Test_POR_25_04_004_CopyPasteNodeIntoTheSameResource extends AbstractTestCase {
	
	@Test(groups={"epp5.0", "navigation"})
	public void testPOR_25_04_004_CopyPasteNodeIntoTheSameResource() throws Exception {
        
		String newStaffNode = ELEMENT_NODE_LINK.replace("${nodeLabel}", "New Staff");
		
		System.out.println("--CopyPasteNodeIntoTheSameResource--");
		
		openPortal(true);
		
		signInAsRoot();
		
		goToGroup();
		
		editNavigation("Executive Board");

		copyNode(CopyType.COPY, null, "New Staff", newStaffNode, null);

		waitForMessage("The source and the destination must be different.");
		
		closeMessageDialog();
		
		save();
		
		waitForTextNotPresent("Navigation Management");
		
		signOut();
	}

}
