package org.jboss.gatein.selenium.common;

import static org.jboss.gatein.selenium.common.CommonHelper.*;

import org.jboss.gatein.selenium.AbstractTestCase;
import org.testng.annotations.Test;

public class Test_POR_01_008_SignInByClickTheseAcountOnHomepage extends AbstractTestCase {
	
	@Test(groups={"epp5.0", "common"})
	public void testPOR_01_008_SignInByClickTheseAcountOnHomepage() throws Exception {
		System.out.println("--Login by Root--");
		
		openPortal(true);

		click(ELEMENT_TEST_USER_ADMIN);
		
		signOut();

		System.out.println("--Login by John--");

		click(ELEMENT_TEST_USER_MANAGER);

		signOut();
		
		System.out.println("--Login by Mary--");

		click(ELEMENT_TEST_USER_USER);

		signOut();
		
		System.out.println("--Login by Demo--");

		click(ELEMENT_TEST_USER_DEMO);

		signOut();	
    }
}
