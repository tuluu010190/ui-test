package org.jboss.gatein.selenium.applicationregistry;

import static org.jboss.gatein.selenium.applicationregistry.ApplicationRegistryHelper.*;
import static org.jboss.gatein.selenium.common.CommonHelper.*;

import org.jboss.gatein.selenium.AbstractTestCase;
import org.testng.annotations.Test;

public class Test_SNF_PRL_12_Portlet extends AbstractTestCase {
	
	@Test(groups={"sniff", "epp5.0", "applicationregistry"})
	public void testSNF_PRL_12_Portlet() throws Exception {
		System.out.println("--View Portlets--");
		
		openPortal(true);

		signInAsRoot();
		
		goToApplicationRegistry();

		System.out.println("--Verify details of Administration>>Application Registry");
		
		selectApplicationInCategory("Administration", "Application Registry");

		waitForTextPresent("ApplicationRegistryPortlet");
		
		System.out.println("--Verify details of Administration>>NewAccount");
		
		selectApplicationInCategory("Administration", "New Account");

		waitForTextPresent("AccountPortlet");
		
		System.out.println("--Verify details of Administration>>Organisation Management");
		
		selectApplicationInCategory("Administration", "Organization Management");

		waitForTextPresent("OrganizationPortlet");

		System.out.println("--Verify details of Dashboard>>Dashboard Portlet");
		
		selectApplicationInCategory("Dashboard", "Dashboard Portlet");

		waitForTextPresent("DashboardPortlet");

		System.out.println("--Verify details of Dashboard>>Gadget Wrapper Portlet");

		selectApplicationInCategory("Dashboard", "Gadget Wrapper Portlet");

		waitForTextPresent("GadgetPortlet");
		
		System.out.println("--It is possible to verify some portlets.......");

		signOut();
	}

}
