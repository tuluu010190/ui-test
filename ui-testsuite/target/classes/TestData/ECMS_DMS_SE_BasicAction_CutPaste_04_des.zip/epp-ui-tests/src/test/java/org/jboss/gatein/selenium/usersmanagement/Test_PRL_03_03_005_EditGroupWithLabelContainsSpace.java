package org.jboss.gatein.selenium.usersmanagement;

import org.jboss.gatein.selenium.AbstractTestCase;
import org.testng.annotations.Test;

import static org.jboss.gatein.selenium.common.CommonHelper.*;
import static org.jboss.gatein.selenium.usersmanagement.UsersManagementHelper.*;

public class Test_PRL_03_03_005_EditGroupWithLabelContainsSpace extends AbstractTestCase {
	
	@Test(groups={"usersmanagement","two"})
	public void testPRL_03_03_005_EditGroupWithLabelContainsSpace() throws Exception {
        
		System.out.println("-- Edit group with Label contains space--");
		
		openPortal(true);
		
		signInAsRoot();
		
		goToUsersAndGroupsManagement();
		
		chooseGroupTab();

		addNewGroup("Test_PRL_03_03_005", "Test_PRL_03_03_005", "Test_PRL_03_03_005", true);
		
		System.out.println("-- Edit group with label contains space--");
		
		click(ELEMENT_GROUP_EDIT_SELECTED);

		type(ELEMENT_INPUT_LABEL, "Test PRL 03 03 005", true);

		save();

		deleteGroup("Test_PRL_03_03_005", true);
		
		signOut();
	}

}
