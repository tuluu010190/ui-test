package org.jboss.gatein.selenium.usersmanagement;

import org.jboss.gatein.selenium.AbstractTestCase;
import org.testng.annotations.Test;

import static org.jboss.gatein.selenium.common.CommonHelper.*;
import static org.jboss.gatein.selenium.usersmanagement.UsersManagementHelper.*;

public class Test_PRL_03_05_006_AddUserIntoGroupWithTheSameExitingRole extends AbstractTestCase {
		
	@Test(groups={"usersmanagement","two"})
	public void testPRL_03_05_006_AddUserIntoGroupWithTheSameExitingRole() throws Exception {
        
		System.out.println("--Add an user into a group with the same exiting role--");
		
		openPortal(true);
		
		signInAsRoot();
		
		goToUsersAndGroupsManagement();
		
		chooseGroupTab();
		
		selectGroup("Customers");
		
		addUsersAtGroup("root", "manager", true, true);

		System.out.println("-- Add user into group with the same role--");
		
		addUsersAtGroup("root", "manager", true, false);
		
		waitForMessage("User \"root\" has already the same membership in the group \"customers\", please select an other membership.");
		closeMessageDialog();

		deleteUserFromGroup("root", "manager", "customers", true);
		
		signOut();
	}

}
