package org.jboss.gatein.selenium.portal;

import java.util.HashMap;
import java.util.Map;

import org.jboss.gatein.selenium.AbstractTestCase;
import org.testng.annotations.Test;

import static org.jboss.gatein.selenium.common.CommonHelper.*;
import static org.jboss.gatein.selenium.portal.PortalHelper.*;
import static org.jboss.gatein.selenium.page.PageHelper.*;

public class Test_SNFN_PRL_25_ChangeContainerInPortal extends AbstractTestCase {

    @Test(groups = {"sniff", "portal"})
    public void testSNFN_PRL_25_ChangeContainerInPortal() throws Exception {

        String editLayoutIcon = ELEMENT_EDIT_LAYOUT_FROM_TABLE.replace("${portalName}", "Test_SNF_PRL_25");
        String containerDragIcon = ELEMENT_EDIT_PAGE_COMPONENT_DRAG_ICON.replace("${number}", "1");
        String emptyContainerPosition1 = EMPTY_CONTAINER.replace("${portletNumber}", "1");
        String emptyContainerPosition4 = EMPTY_CONTAINER.replace("${portletNumber}", "4");

        System.out.println("--Change container in portal--");

        openPortal(true);

        signInAsRoot();

        goToSite();

        Map<String, String> permissions = new HashMap<String, String>();
        permissions.put("Platform/Administrators", "*");
        createNewPortal("Test_SNF_PRL_25", "English", "Default", "On Demand", false, permissions, "Platform/Administrators", "manager");

        verifyPortalExists("Test_SNF_PRL_25");

        System.out.println("-- Choose new portal and click edit layout--");

        click(editLayoutIcon);

        System.out.println("-- View layout of portal before Change container in portal--");

        click(ELEMENT_SWITCH_VIEW_MODE_PORTAL);

        pause(500);
        
        click(ELEMENT_SWITCH_VIEW_MODE_PORTAL);

        System.out.println("-- Change container in portal--");

        click(ELEMENT_CONTAINERS_TAB);

        dragAndDropToObject(ELEMENT_ONE_ROW_CONTAINER, ELEMENT_EDIT_PAGE_COMPONENT_FIRST, emptyContainerPosition1);

        click(ELEMENT_SWITCH_VIEW_MODE_PORTAL);
        
        pause(500);

        click(ELEMENT_SWITCH_VIEW_MODE_PORTAL);

        editSpecifiedPortletOrContainer("1", false, ELEMENT_INPUT_TITLE);

        type(ELEMENT_INPUT_TITLE, "Test_SNF_PRL_25", true);

        type(ELEMENT_INPUT_WIDTH, "300px", true);

        type(ELEMENT_INPUT_HEIGHT, "100px", true);

        save();

        waitForTextNotPresent("Container Setting");

        System.out.println("-- Move position of container --");

        if (ieFlag) {
            actions.moveToElement(getElement(ELEMENT_EDIT_PAGE_COMPONENT_FIRST));
            actions.dragAndDrop(getElement(containerDragIcon), getElement(ELEMENT_EDIT_PAGE_PAGE_BODY_COMPONENT)).build().perform();
        } else {
            mouseOver(ELEMENT_EDIT_PAGE_COMPONENT_FIRST, true);
            dragAndDropToObject(containerDragIcon, ELEMENT_EDIT_PAGE_PAGE_BODY_COMPONENT, emptyContainerPosition4);
        }

        System.out.println("-- View after change position of container --");

        click(ELEMENT_SWITCH_VIEW_MODE_PORTAL);

        click(ELEMENT_SWITCH_VIEW_MODE_PORTAL);

        System.out.println("-- Delete container --");

        deleteSpecifiedPortletOrContainer(ContainerType.CONTAINER, "4", false);

        click(ELEMENT_EDIT_LAYOUT_FINISH_BUTTON);

        deletePortal("Test_SNF_PRL_25");

        signOut();
    }
}
