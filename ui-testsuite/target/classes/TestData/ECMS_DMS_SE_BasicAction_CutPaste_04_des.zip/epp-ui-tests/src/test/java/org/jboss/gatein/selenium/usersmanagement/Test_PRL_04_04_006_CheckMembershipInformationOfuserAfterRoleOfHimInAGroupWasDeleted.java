package org.jboss.gatein.selenium.usersmanagement;

import org.jboss.gatein.selenium.AbstractTestCase;
import org.testng.annotations.Test;

import static org.jboss.gatein.selenium.common.CommonHelper.*;
import static org.jboss.gatein.selenium.usersmanagement.UsersManagementHelper.*;

public class Test_PRL_04_04_006_CheckMembershipInformationOfuserAfterRoleOfHimInAGroupWasDeleted extends AbstractTestCase {
	
	@Test(groups={"usersmanagement","two"})
	public void testPRL_04_04_006_CheckMembershipInformationOfuserAfterRoleOfHimInAGroupWasDeleted() throws Exception {
        
		String userEditIcon = ELEMENT_USER_EDIT_ICON.replace("${username}", "Test_PRL_04_04_006");
		String deleteMembershipInEditUser = ELEMENT_USER_EDIT_DELETE_MEMBERSHIP_ICON.replace("${membershipId}", "test_plr_04_04_006:test_prl_04_04_006:/platform");
		
		System.out.println("-- Check membership information of user after role of him in a group was deleted--");
		
		openPortal(true);
		
		signInAsRoot();

		goToNewStaff();
		
		addNewAccountAtNewStaff("test_prl_04_04_006", "Test_PRL_04_04_006", "Test_PRL_04_04_006", "Test_PRL_04_04_006", "Test_PRL_04_04_006", "Test_PRL_04_04_006@localhost.com", "", "English", true);
		
		goToUsersAndGroupsManagement();
		
		chooseMembershipTab();

		addNewMembership("test_plr_04_04_006", "test_plr_04_04_006", true);

		System.out.println("-- Add an user into a specific group with new membership--");
		
		chooseGroupTab();

		selectGroup("Platform");
		
		addUsersAtGroup("test_prl_04_04_006", "test_plr_04_04_006", true, true);

		System.out.println("-- Check membership information of user after assign into group--");

		chooseUserTab();
		
		searchUserByUserName("test_prl_04_04_006");
		
		System.out.println("-- Click edit user icon --");

		click(userEditIcon);

		System.out.println("-- Choose User Profile tab--");

		click(ELEMENT_USER_PROFILE_TAB);
		
		System.out.println("-- User Membership tab--");
                
		click(ELEMENT_USER_MEMBERSHIP_TAB);

		click(deleteMembershipInEditUser);

		waitForConfirmation("Are you sure you want to delete this membership?");

		cancel();
		
		System.out.println("-- Delete user --");

		deleteUser("test_prl_04_04_006");
        
        waitForMessage("No result found.");
        closeMessageDialog();
		
		System.out.println("-- Delete membership --");
		
		chooseMembershipTab();
		
		deleteMembership("test_plr_04_04_006", true);
		
		signOut();
	}

}
