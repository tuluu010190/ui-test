package org.jboss.gatein.selenium.navigation;

import static org.jboss.gatein.selenium.common.CommonHelper.*;
import static org.jboss.gatein.selenium.navigation.NavigationHelper.*;

import org.jboss.gatein.selenium.AbstractTestCase;
import org.jboss.gatein.selenium.navigation.NavigationHelper.CopyType;
import org.testng.annotations.Test;

public class Test_POR_14_03_001_CopyPasteNodeIntoTheSameNavigation extends AbstractTestCase {
	
	@Test(groups={"navigation"})
	public void testPOR_14_03_001_CopyPasteNodeIntoTheSameNavigation() throws Exception {
        
		String siteMapNode = ELEMENT_NODE_LINK.replace("${nodeLabel}", "SiteMap");
		
		System.out.println("--CopyPasteNodeIntoTheSameNavigation--");
		
		openPortal(true);
		
		signInAsRoot();

		goToSite();
		
		addNewNode("Test_POR_14_03_001", "Test_POR_14_03_001", true, null, null, null, false, true, false, null);

		editFirstNavigation();
		
		copyNode(CopyType.COPY, null, "Test_POR_14_03_001", siteMapNode, null);

		save();
		
		waitForTextNotPresent("Navigation Management");
		
		deleteNodeFromFirstNavigation("Test_POR_14_03_001", null, true);

		deleteNodeFromFirstNavigation("Test_POR_14_03_001", "SiteMap", true);
		
		signOut();
	}

}
