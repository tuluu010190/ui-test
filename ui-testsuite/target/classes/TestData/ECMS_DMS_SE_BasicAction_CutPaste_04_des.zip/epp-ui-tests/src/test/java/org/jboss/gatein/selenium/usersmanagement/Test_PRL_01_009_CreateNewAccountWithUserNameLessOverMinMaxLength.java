package org.jboss.gatein.selenium.usersmanagement;

import org.jboss.gatein.selenium.AbstractTestCase;
import org.testng.annotations.Test;

import static org.jboss.gatein.selenium.common.CommonHelper.*;
import static org.jboss.gatein.selenium.usersmanagement.UsersManagementHelper.*;

public class Test_PRL_01_009_CreateNewAccountWithUserNameLessOverMinMaxLength extends AbstractTestCase {
	
	@Test(groups={"usersmanagement","one"})
	public void testPRL_01_009_CreateNewAccountWithUserNameLessOverMinMaxLength() throws Exception {
        
		System.out.println("-- Create new account with user name less/over min/max length--");
		
		openPortal(true);
		
		signInAsRoot();
		
		goToNewStaff();

		addNewAccountAtNewStaff("te", "Test_PRL_01_009", "Test_PRL_01_009", "Test_PRL_01_009", "Test_PRL_01_009", "Test_PRL_01_009@localhost.com", "", "English", false);
		
		waitForMessage("The length of the text in field \"User Name\" must be between \"3\" and \"30\" characters.");
		closeMessageDialog();
		
		addNewAccountAtNewStaff("test_prl_01_009test_prl_01_009test_prl_01_009test_prl_01_009", "Test_PRL_01_009", "Test_PRL_01_009", "Test_PRL_01_009", "Test_PRL_01_009", "Test_PRL_01_009@localhost.com", "", "English", false);
		
		waitForMessage("The length of the text in field \"User Name\" must be between \"3\" and \"30\" characters.");
		closeMessageDialog();
		
		signOut();
	}

}
