package org.jboss.gatein.selenium.usersmanagement;

import org.jboss.gatein.selenium.AbstractTestCase;
import org.testng.annotations.Test;

import static org.jboss.gatein.selenium.common.CommonHelper.*;
import static org.jboss.gatein.selenium.usersmanagement.UsersManagementHelper.*;

public class Test_PRL_03_02_013_AddNewGroupWhenGroupNameStartsWithDot extends AbstractTestCase {
	
	@Test(groups={"usersmanagement","two"})
	public void testPRL_03_02_013_AddNewGroupWhenGroupNameStartsWithDot() throws Exception {
        
		System.out.println("-- Add new group when Group Name starts with dot--");
		
		openPortal(true);
		
		signInAsRoot();

		goToUsersAndGroupsManagement();
		
		chooseGroupTab();
		
		System.out.println("-- Add new group with Name start by dot--");
		
		addNewGroup("...............", "Test_PRL_02_03_013", "Test_PRL_02_03_013", false);
		
		waitForMessage("Only alpha, digit, dash and underscore characters allowed for the field \"Group Name\".");
		closeMessageDialog();
		
		cancel();

		signOut();
	}

}
