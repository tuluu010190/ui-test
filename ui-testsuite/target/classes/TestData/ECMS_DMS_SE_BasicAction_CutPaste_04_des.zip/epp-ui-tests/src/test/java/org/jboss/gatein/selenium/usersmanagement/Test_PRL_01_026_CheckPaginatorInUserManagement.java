package org.jboss.gatein.selenium.usersmanagement;

import org.jboss.gatein.selenium.AbstractTestCase;
import org.testng.annotations.Test;

import static org.jboss.gatein.selenium.common.CommonHelper.*;
import static org.jboss.gatein.selenium.usersmanagement.UsersManagementHelper.*;

public class Test_PRL_01_026_CheckPaginatorInUserManagement extends AbstractTestCase {
	
	@Test(groups={"usersmanagement","one"})
	public void testPRL_01_026_CheckResetFunctionWhileCreatingNewAccout() throws Exception {
        
		System.out.println("-- Check Reset function while creating new account--");
		
		openPortal(true);
		
		signInAsRoot();
		
		goToNewStaff();
		
		addNewAccountAtNewStaff("test_prl_01_026_01", "Test_PRL_01_026", "Test_PRL_01_026", "Test_PRL_01_026", "Test_PRL_01_026", "Test_PRL_01_026Test_PRL_01_026_01@localhost.com", "Test_PRL_01_026", "English", true);
		addNewAccountAtNewStaff("test_prl_01_026_02", "Test_PRL_01_026", "Test_PRL_01_026", "Test_PRL_01_026", "Test_PRL_01_026", "Test_PRL_01_026Test_PRL_01_026_02@localhost.com", "Test_PRL_01_026", "English", true);
		addNewAccountAtNewStaff("test_prl_01_026_03", "Test_PRL_01_026", "Test_PRL_01_026", "Test_PRL_01_026", "Test_PRL_01_026", "Test_PRL_01_026Test_PRL_01_026_03@localhost.com", "Test_PRL_01_026", "English", true);
		addNewAccountAtNewStaff("test_prl_01_026_04", "Test_PRL_01_026", "Test_PRL_01_026", "Test_PRL_01_026", "Test_PRL_01_026", "Test_PRL_01_026Test_PRL_01_026_04@localhost.com", "Test_PRL_01_026", "English", true);
		addNewAccountAtNewStaff("test_prl_01_026_05", "Test_PRL_01_026", "Test_PRL_01_026", "Test_PRL_01_026", "Test_PRL_01_026", "Test_PRL_01_026Test_PRL_01_026_05@localhost.com", "Test_PRL_01_026", "English", true);
		addNewAccountAtNewStaff("test_prl_01_026_06", "Test_PRL_01_026", "Test_PRL_01_026", "Test_PRL_01_026", "Test_PRL_01_026", "Test_PRL_01_026Test_PRL_01_026_06@localhost.com", "Test_PRL_01_026", "English", true);
		addNewAccountAtNewStaff("test_prl_01_026_07", "Test_PRL_01_026", "Test_PRL_01_026", "Test_PRL_01_026", "Test_PRL_01_026", "Test_PRL_01_026Test_PRL_01_026_07@localhost.com", "Test_PRL_01_026", "English", true);
		addNewAccountAtNewStaff("test_prl_01_026_08", "Test_PRL_01_026", "Test_PRL_01_026", "Test_PRL_01_026", "Test_PRL_01_026", "Test_PRL_01_026Test_PRL_01_026_08@localhost.com", "Test_PRL_01_026", "English", true);
		addNewAccountAtNewStaff("test_prl_01_026_09", "Test_PRL_01_026", "Test_PRL_01_026", "Test_PRL_01_026", "Test_PRL_01_026", "Test_PRL_01_026Test_PRL_01_026_09@localhost.com", "Test_PRL_01_026", "English", true);
		addNewAccountAtNewStaff("test_prl_01_026_10", "Test_PRL_01_026", "Test_PRL_01_026", "Test_PRL_01_026", "Test_PRL_01_026", "Test_PRL_01_026Test_PRL_01_026_10@localhost.com", "Test_PRL_01_026", "English", true);
		addNewAccountAtNewStaff("test_prl_01_026_11", "Test_PRL_01_026", "Test_PRL_01_026", "Test_PRL_01_026", "Test_PRL_01_026", "Test_PRL_01_026Test_PRL_01_026_11@localhost.com", "Test_PRL_01_026", "English", true);

        System.out.println("--Deleting user on second page--");
        
        goToUsersAndGroupsManagement();
        deleteUser("test_prl_01_026_11");
        
        System.out.println("--Deleting other users--");
        deleteUser("test_prl_01_026_01");
        deleteUser("test_prl_01_026_02");
        deleteUser("test_prl_01_026_03");
        deleteUser("test_prl_01_026_04");
        deleteUser("test_prl_01_026_05");
        deleteUser("test_prl_01_026_06");
        deleteUser("test_prl_01_026_07");
        deleteUser("test_prl_01_026_08");
        deleteUser("test_prl_01_026_09");
        deleteUser("test_prl_01_026_10");
        
		signOut();
	}

}
