package org.jboss.gatein.selenium.usersmanagement;

import static org.jboss.gatein.selenium.common.CommonHelper.*;
import static org.jboss.gatein.selenium.usersmanagement.UsersManagementHelper.*;

import org.jboss.gatein.selenium.AbstractTestCase;
import org.testng.annotations.Test;

public class Test_PRL_01_014_CreateNewAccountWithPasswordAndConfirmPasswordLess6OrOver30Characters extends AbstractTestCase {
	
	@Test(groups={"usersmanagement","one"})
	public void testPRL_01_014_CreateNewAccountWithPasswordAndConfirmPasswordLess6OrOver30Characters() throws Exception {
        
		System.out.println("-- Create new account with Password/Confirm Password less 6 or over 30 characters--");
		
		openPortal(true);
		
		signInAsRoot();
		
		goToNewStaff();

		addNewAccountAtNewStaff("test_prl_01_014", "Test_PRL_01_014Test_PRL_01_014Test_PRL_01_014", "Test_PRL_01_014Test_PRL_01_014Test_PRL_01_014", "Test_PRL_01_014", "Test_PRL_01_014", "Test_PRL_01_014@localhost.com", "", "English", false);
		
		waitForMessage("The length of the text in field \"Password\" must be between \"6\" and \"30\" characters.");
		waitForMessage("The length of the text in field \"Confirm Password\" must be between \"6\" and \"30\" characters.");
		closeMessageDialog();
		
		addNewAccountAtNewStaff("Test_PRL_01_014", "1_014", "1_014", "Test_PRL_01_014", "Test_PRL_01_014", "Test_PRL_01_014@localhost.com", "", "English", false);
		
		waitForMessage("The length of the text in field \"Password\" must be between \"6\" and \"30\" characters.");
		waitForMessage("The length of the text in field \"Confirm Password\" must be between \"6\" and \"30\" characters.");
		closeMessageDialog();

		signOut();		
	}

}
