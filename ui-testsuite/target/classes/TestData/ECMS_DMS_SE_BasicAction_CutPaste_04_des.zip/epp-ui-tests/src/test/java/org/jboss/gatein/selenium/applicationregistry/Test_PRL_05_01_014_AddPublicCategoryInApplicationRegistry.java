package org.jboss.gatein.selenium.applicationregistry;

import org.jboss.gatein.selenium.AbstractTestCase;
import org.testng.annotations.Test;

import static org.jboss.gatein.selenium.common.CommonHelper.*;
import static org.jboss.gatein.selenium.applicationregistry.ApplicationRegistryHelper.*;

public class Test_PRL_05_01_014_AddPublicCategoryInApplicationRegistry extends AbstractTestCase {
	
	@Test(groups={"applicationregistry"})
	public void testPRL_05_01_014_AddPublicCategoryInApplicationRegistry()
			throws Exception {
		System.out.println("-- Add public category  in Application registry--");
		
		openPortal(true);
		
		signInAsRoot();
		
		goToApplicationRegistry();
		
		addNewCategory("Test_PRL_05_01_014", "Test_PRL_05_01_014", "Test_PRL_05_01_014", true, null, true);
		
		addApplicationToCategory("Test_PRL_05_01_014", PortletType.GADGET, "Calculator", "");

		deleteCategory("Test_PRL_05_01_014");
		
		signOut();
	}

}
