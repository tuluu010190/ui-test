package org.jboss.gatein.selenium.common;

import static org.jboss.gatein.selenium.common.CommonHelper.*;

import org.jboss.gatein.selenium.AbstractTestCase;
import org.testng.annotations.Test;

public class Test_POR_01_002_SignInByAdminAccount extends AbstractTestCase {

	@Test(groups={"epp5.0", "common"})
	public void testPOR_01_002_SignInByAdminAccount() throws Exception {
		System.out.println("--Login by Admin account--");
		
		openPortal(true);
		
		signInAsRoot();

		waitForAndGetElement(ELEMENT_LINK_SITE);

		signOut();
	}

}
