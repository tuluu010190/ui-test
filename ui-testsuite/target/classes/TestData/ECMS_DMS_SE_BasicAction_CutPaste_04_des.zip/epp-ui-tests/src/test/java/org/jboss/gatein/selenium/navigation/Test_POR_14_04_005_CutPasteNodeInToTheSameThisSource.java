package org.jboss.gatein.selenium.navigation;

import static org.jboss.gatein.selenium.common.CommonHelper.*;
import static org.jboss.gatein.selenium.navigation.NavigationHelper.*;

import org.jboss.gatein.selenium.AbstractTestCase;
import org.testng.annotations.Test;

public class Test_POR_14_04_005_CutPasteNodeInToTheSameThisSource extends AbstractTestCase {

	@Test(groups={"navigation"})
	public void testPOR_14_04_005_CutPasteNodeInToTheSameThisSource()
			throws Exception {
		String homeNode = ELEMENT_NODE_LINK.replace("${nodeLabel}", "Home");
		
		System.out.println("--CutPasteNodeInToTheSameThisSource--");

		openPortal(true);
		
		signInAsRoot();
		
		goToSite();
		
		editFirstNavigation();
		
		copyNode(CopyType.CUT, null, "Home", homeNode, null);

		waitForMessage("The source and the destination must be different.");
		
		closeMessageDialog();
		
		save();

		signOut();
	}

}
