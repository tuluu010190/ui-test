package org.jboss.gatein.selenium.usersmanagement;

import org.jboss.gatein.selenium.AbstractTestCase;
import org.testng.annotations.Test;

import static org.jboss.gatein.selenium.common.CommonHelper.*;
import static org.jboss.gatein.selenium.usersmanagement.UsersManagementHelper.*;

public class Test_PRL_01_023_CreateNewAccountWhenFirstAndLastNameLessThan1OrOver45Characters extends AbstractTestCase {
	
	@Test(groups={"usersmanagement","one"})
	public void testPRL_01_023_CreateNewAccountWhenFirstAndLastNameLessThan1OrOver45Characters() throws Exception {
        
		System.out.println("-- Create new account when First/Last Name less than 1 or over 45 characters--");

		openPortal(true);
		
		signInAsRoot();
		
		goToNewStaff();
		
		addNewAccountAtNewStaff("test_prl_01_023", "Test_PRL_01_023", "Test_PRL_01_023", "", "Test_PRL_01_023 Test_PRL_01_023 Test_PRL_01_023 Test_PRL_01_023 Test_PRL_01_023 Test_PRL_01_023 Test_PRL_01_023", "Test_PRL_01_023@localhost.com", "", "English", false);
		
		waitForMessage("The field \"First Name\" is required.");
		waitForMessage("The length of the text in field \"Last Name\" must be between \"1\" and \"45\" characters.");
		closeMessageDialog();

		signOut();
	}

}
