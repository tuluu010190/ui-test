package org.jboss.gatein.selenium.usersmanagement;

import org.jboss.gatein.selenium.AbstractTestCase;
import org.testng.annotations.Test;

import static org.jboss.gatein.selenium.common.CommonHelper.*;
import static org.jboss.gatein.selenium.usersmanagement.UsersManagementHelper.*;

public class Test_PRL_03_02_004_AddNewGroupWhenGroupNameStartsWithDash extends AbstractTestCase {
	
	@Test(groups={"usersmanagement","two"})
	public void testPRL_03_02_004_AddNewGroupWhenGroupNameStartsWithDash() throws Exception {
        
		System.out.println("-- Add new group when Group Name starts with  dash --");
		
		openPortal(true);
		
		signInAsRoot();

		goToUsersAndGroupsManagement();
		
		chooseGroupTab();
		
		System.out.println("-- Add new group with name start by dash--");
		
		addNewGroup("---------", "Test_PRL_02_03_004", "Test_PRL_02_03_004", false);
		
		waitForMessage("The \"Group Name\" field must start with a letter and must not contain special characters.");
		closeMessageDialog();
		
		cancel();

		signOut();
	}

}
