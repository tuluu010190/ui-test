package org.jboss.gatein.selenium.dashboard;

import org.jboss.gatein.selenium.AbstractTestCase;
import static org.jboss.gatein.selenium.common.CommonHelper.*;
import static org.jboss.gatein.selenium.dashboard.DashboardHelper.*;
import static org.jboss.gatein.selenium.page.PageHelper.*;

import org.testng.annotations.Test;

public class Test_SNF_PRL_30_CreateAndEditPageAndEditSiteLayoutForUser extends AbstractTestCase {
	
	@Test(groups={"sniff", "epp5.0", "dashboard"})
	public void testSNF_PRL_30_CreateAndEditPageAndEditSiteLayoutForUser() throws Exception {
        
        String verification = ELEMENT_DASHBOARD_SELECTED_PAGE_WITH_SPECIFIED_NAME.replace("${dashboardName}", "test_dashboardpage_name_30");
        
		System.out.println("-DashboardSiteManagement-");
		
		openPortal(true);

		signInAsRoot();

		goToDashboard();

		waitForAndGetElement(ELEMENT_ADD_GADGETS_LINK);
		
		addNewPageOnDashboardWithEditor("test_dashboardpage_30", "test_dashboardpage_name_30", false, null);

		System.out.println("--Edit page in dashboard");

		goToEditPage();

		click(ELEMENT_VIEW_PAGE_PROPERTIES);
		
		type(ELEMENT_INPUT_TITLE, "test_dashboardpage_edit_30", true);
		
		save();
		
        finishPageEdit();

		System.out.println("--Verify page edit");

		goToEditPage();

		click(ELEMENT_VIEW_PAGE_PROPERTIES);

		waitForAndGetElement(ELEMENT_INPUT_TITLE);
		
		waitForAndGetElement("//input[@value='test_dashboardpage_edit_30']");

		cancel();
		
		click(ELEMENT_PAGE_ABORT_BUTTON);
		
        if (!gateinFlag) {
            waitForPopupConfirmationAndConfirm("Modifications have been made. Are you sure you want to close without saving ?");
        }
        
        pause(500);

		goToPage(verification, ELEMENT_LINK_DASHBOARD, "test_dashboardpage_name_30");

		deleteSelectedPage("test_dashboardpage_name_30");

		signOut();
	}

}
