package org.jboss.gatein.selenium.applicationregistry;

import java.util.HashMap;
import java.util.Map;

import org.jboss.gatein.selenium.AbstractTestCase;
import org.testng.annotations.Test;

import static org.jboss.gatein.selenium.common.CommonHelper.*;
import static org.jboss.gatein.selenium.applicationregistry.ApplicationRegistryHelper.*;
import static org.jboss.gatein.selenium.page.PageHelper.*;
import static org.jboss.gatein.selenium.permission.PermissionHelper.*;

public class Test_PRL_05_02_004_ChangeAccessRightOnCategoryFromLimitedGroupToBePublic extends AbstractTestCase {
	
	@Test(groups={"applicationregistry"})
	public void testPRL_05_02_004_ChangeAccessRightOnCategoryFromLimitedGroupToBePublic() throws Exception {
        
		String categoryEditIcon = ELEMENT_CATEGORY_EDIT_ICON.replace("${categoryTitle}", "Test_PRL_05_02_004");
		String categoryMenuInEditPage = ELEMENT_EDIT_PAGE_CATEGORY_MENU.replace("${categoryLabel}", "Test_PRL_05_02_004");
		
		System.out.println("-- Change access right on category from limited by group(s) to be public--");
		
		openPortal(true);

		signInAsRoot();
		
		goToApplicationRegistry();
		
		Map<String, String> permissions = new HashMap<String, String>();
		permissions.put("Organization/Management/Executive Board", "*");
		addNewCategory("Test_PRL_05_02_004", "Test_PRL_05_02_004", "Test_PRL_05_02_004", false, permissions, true);
		
		System.out.println("-- Add application into category--");

		addApplicationToCategory("Test_PRL_05_02_004", PortletType.GADGET, "Calculator", "");
		
		System.out.println("-- Edit permission from private to public--");
		
		click(categoryEditIcon);
		
		click(ELEMENT_PERMISSION_SETTING_TAB);
		
		check(ELEMENT_CHECKBOX_PUBLIC_MODE);
		
		save();

		signOut();

		System.out.println("-- Check accessing public category--");

		signInAsJohn();
		
		goToEditPage();

        if (ieFlag) {
            resize(ELEMENT_RESIZE_BUTTON, 0, 100);
        }
		click(categoryMenuInEditPage);
		
		finishPageEdit();

		signOut();
		
		System.out.println("-- Delete category--");

		signInAsRoot();
		
		goToApplicationRegistry();

		deleteCategory("Test_PRL_05_02_004");
		
		signOut();
	}

}
