package org.jboss.gatein.selenium.navigation;

import org.jboss.gatein.selenium.AbstractTestCase;
import org.testng.Assert;
import org.testng.annotations.Test;

import static org.jboss.gatein.selenium.common.CommonHelper.*;
import static org.jboss.gatein.selenium.permission.PermissionHelper.*;
import static org.jboss.gatein.selenium.navigation.NavigationHelper.*;
import static org.jboss.gatein.selenium.page.PageHelper.*;

public class Test_SNF_PRL_27_CreateAndEditPageAndEditSiteLayoutForGroup extends AbstractTestCase {
	
	@Test(groups={"sniff", "epp5.0", "navigation"})
	public void testSNF_PRL_27_CreateAndEditPageAndEditSiteLayoutForGroup()
			throws Exception {
		System.out.println("-AddEditGroupPageWizard-");
		
		openPortal(true);

		signInAsRoot();

		goToPageManagement();

		waitForAndGetElement(ELEMENT_PAGE_MANAGEMENT_BODY);

		System.out.println("--Create new page--");

        goToAddNewPage();
        
        fillPageEditor("test_page_27", "test_page_name_27", null, null, false, null);

		System.out.println("--Go to View Page properties--");

		click(ELEMENT_VIEW_PAGE_PROPERTIES);

		waitForTextPresent("Show Max Window");
		
		System.out.println("--Choose Permission Setting--");

		click(ELEMENT_PERMISSION_SETTING_TAB);

		System.out.println("--Choose Access Permission Setting--");

		click(ELEMENT_LINK_ACCESS_PERMISSION);

		System.out.println("--Choose Edit Permission Setting--");

		click(ELEMENT_LINK_EDIT_PERMISSION);
		
		System.out.println("--Do not change anything in Page properties");

		cancel();

		System.out.println("--Click Save to complete adding new page by wizard with no content (no portlet)");

        finishPageEdit();

		System.out.println("--Go to Edit page--");

		goToEditPage();

		System.out.println("--Show form to edit page by wizard");

		click(ELEMENT_VIEW_PAGE_PROPERTIES);

		waitForTextPresent("Show Max Window");
		
		System.out.println("--Choose Permission Setting--");

		click(ELEMENT_PERMISSION_SETTING_TAB);

		System.out.println("--Choose Access Permission Setting--");

		click(ELEMENT_LINK_ACCESS_PERMISSION);

		setViewPermissions("Platform/Administrators", "manager");

		save();

		System.out.println("--Click Finish after change something of page--");

        finishPageEdit();

		System.out.println("--Edit layout when click Save button--");

		goToEditLayout();

		click(ELEMENT_SITE_CONFIG_LINK);
                
		type(ELEMENT_INPUT_DESCRIPTION, "SNF_PRL_27 test description", true);
                
		save();
		
		click(ELEMENT_EDIT_LAYOUT_FINISH_BUTTON);

		System.out.println("--Change layout when click Cancel button--");

		goToEditLayout();
		
		click(ELEMENT_SITE_CONFIG_LINK);

        Assert.assertEquals(getValue(ELEMENT_INPUT_DESCRIPTION), "SNF_PRL_27 test description");

		cancel();
		
		click(ELEMENT_EDIT_LAYOUT_ABORT_BUTTON);
		
        if (!gateinFlag) {
            waitForPopupConfirmationAndConfirm("Modifications have been made. Are you sure you want to close without saving ?");
        }
		
		System.out.println("--Delete page");

		goToGroup();

		deleteNodeFromNavigation("Administrators", "test_page_name_27", "Page Management", true);
		
		goToPageManagement();
		
		searchAndDeletePage(PageType.GROUP, "page", "test_page_27", true, "test_page_27");
		
		signOut();
	}

}
