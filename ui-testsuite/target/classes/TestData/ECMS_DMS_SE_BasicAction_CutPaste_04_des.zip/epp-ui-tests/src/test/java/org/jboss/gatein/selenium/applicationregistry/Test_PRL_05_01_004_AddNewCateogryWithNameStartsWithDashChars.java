package org.jboss.gatein.selenium.applicationregistry;

import java.util.HashMap;
import java.util.Map;

import org.jboss.gatein.selenium.AbstractTestCase;
import org.testng.annotations.Test;

import static org.jboss.gatein.selenium.common.CommonHelper.*;
import static org.jboss.gatein.selenium.applicationregistry.ApplicationRegistryHelper.*;

public class Test_PRL_05_01_004_AddNewCateogryWithNameStartsWithDashChars extends AbstractTestCase {
	
	@Test(groups={"applicationregistry"})
	public void testPRL_05_01_004_AddNewCateogryWithNameStartsWithDashChars() throws Exception {
		System.out.println("-- Add new category with name starts with  dash  characters--");

		openPortal(true);
		
		signInAsRoot();
		
		goToApplicationRegistry();
		
		Map<String, String> permissions = new HashMap<String, String>();
		permissions.put("Customers", "*");
		addNewCategory("------", "Test_PRL_05_01_004", "Test_PRL_05_01_004", false, permissions, false);
		
		waitForMessage("The \"Category name\" field must start with a letter and must not contain special characters.");
		closeMessageDialog();
		
		cancel();

		signOut();
	}
}
