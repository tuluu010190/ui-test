package org.jboss.gatein.selenium.permission;

import org.jboss.gatein.selenium.AbstractTestCase;
import org.testng.annotations.Test;


import static org.jboss.gatein.selenium.common.CommonHelper.*;
import static org.jboss.gatein.selenium.page.PageHelper.*;
import static org.jboss.gatein.selenium.permission.PermissionHelper.*;

public class Test_VerifyViewRightsPortlet extends AbstractTestCase {

	@Test(groups={"epp5.0", "permission"})
	public void testVerifyViewRightsPortlet() throws Exception {
		
        String gadgetsCategory = ELEMENT_EDIT_PAGE_CATEGORY_MENU.replace("${categoryLabel}", "Gadgets");
		String calculatorPortlet = "//div[@id='Gadgets/Calculator']";
        String siteMapPortlet = "//div[@id='UISiteMap']";
        String dragAndDropVerification = ELEMENT_EDIT_PAGE_COMPONENT_FIRST + PORTLET_LABEL.replace("${portletName}", "Calculator");
                
		System.out.println("--Verify portlet view permissions--");
		
		openPortal(true);

		signInAsRoot();

		System.out.println("--Add Calculator portlet on Site map page");

		goToSiteMap();
		
		waitForTextPresent("Collapse All");

		goToEditPage();

		System.out.println("--DnD Calculator portlet on page--");

		click(gadgetsCategory);

		dragAndDropToObject(calculatorPortlet, ELEMENT_EDIT_PAGE_PAGE, dragAndDropVerification);
        
		System.out.println("--Edit view permissions--");

		editSpecifiedPortletOrContainer("1", false, ELEMENT_INPUT_TITLE);

		waitForTextPresent("Display Name:");

		click(ELEMENT_ACCESS_PERMISSION_TAB);

		check(ELEMENT_CHECKBOX_PUBLIC_MODE);

		uncheck(ELEMENT_CHECKBOX_PUBLIC_MODE);

		setViewPermissions("Platform/Administrators", "*");
		
		click(ELEMENT_SAVE_AND_CLOSE_BUTTON);

        finishPageEdit();

		System.out.println("--Verify portlet added on page--");

		waitForTextPresent("Calculator");
		
		signOut();

		System.out.println("--Verify portlet no visible in public mode--");

		click("//a[text()='SiteMap']");
		
		waitForTextPresent("Collapse All");
		
        waitForAndGetElement(siteMapPortlet);
		waitForTextNotPresent("Calculator");

		System.out.println("--Verify portlet not visible for mary--");

		signInAsMary();

		goToSiteMap();
		
		waitForTextPresent("Collapse All");
		
		waitForAndGetElement(siteMapPortlet);
		waitForTextNotPresent("Calculator");

		signOut();

		System.out.println("--Verify portlet visible for root--");

		signInAsRoot();

		goToSiteMap();
		
		waitForTextPresent("Collapse All");
		
		waitForTextPresent("Calculator");

		System.out.println("--Delete portlet from page--");

		goToEditPage();

		deleteSpecifiedPortletOrContainer(ContainerType.PORTLET, "1", false);

        finishPageEdit();

        waitForTextPresent("Collapse All");
        
		waitForAndGetElement(siteMapPortlet);
		waitForTextNotPresent("Calculator");

		signOut();
	}

}
