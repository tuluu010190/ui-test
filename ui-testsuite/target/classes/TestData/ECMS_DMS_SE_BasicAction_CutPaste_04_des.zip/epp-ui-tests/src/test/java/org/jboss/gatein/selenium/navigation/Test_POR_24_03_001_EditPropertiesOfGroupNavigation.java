package org.jboss.gatein.selenium.navigation;

import org.testng.Assert;
import org.jboss.gatein.selenium.AbstractTestCase;
import org.testng.annotations.Test;

import static org.jboss.gatein.selenium.common.CommonHelper.*;
import static org.jboss.gatein.selenium.navigation.NavigationHelper.*;

public class Test_POR_24_03_001_EditPropertiesOfGroupNavigation extends AbstractTestCase {
	
	@Test(groups={"navigation"})
	public void testPOR_24_03_001_EditPropertiesOfGroupNavigation()	throws Exception {
        
		String admins = "/platform/administrators";
		String exBoard = "/organization/management/executive-board";
        String firstPositionInMenu = ELEMENT_LINK_GROUP + "/..//ul//li[contains(@class, 'TitleBar')][1]";
        String secondPositionInMenu = ELEMENT_LINK_GROUP + "/..//ul//li[contains(@class, 'TitleBar')][2]";
        
		String firstPositionInGroup = "//div[@id='UIGroupNavigationGrid']//table[1]//div[@class='Label']";
		String secondPositionInGroup = "//div[@id='UIGroupNavigationGrid']//table[2]//div[@class='Label']";
        
		String exBoardEditProperties = ELEMENT_GROUP_EDIT_PROPERTIES.replace("${navigation}", "Executive Board");
		
		openPortal(true);
		
		signInAsRoot();
		
		System.out.println("--Edit priority--");

		goToGroup();
		
        Assert.assertTrue(getTitleOfElement(firstPositionInGroup).equals(admins));
        Assert.assertTrue(getTitleOfElement(secondPositionInGroup).equals(exBoard));

        mouseOver(ELEMENT_LINK_GROUP, true);
        Assert.assertTrue(getTitleOfElement(firstPositionInMenu).equals(admins));
        
        if (ieFlag) {
            mouseOver(ELEMENT_LINK_GROUP, true);
        }
        Assert.assertTrue(getTitleOfElement(secondPositionInMenu).equals(exBoard));
        
		click(exBoardEditProperties);
		
		waitForTextPresent("Page Navigation Form");
		
		select(ELEMENT_INPUT_PRIORITY, "1");

		save();

		System.out.println("-- Check after edit--");

        pause(500);
		goToGroup();
		
		Assert.assertTrue(getTitleOfElement(firstPositionInGroup).equals(exBoard));
        Assert.assertTrue(getTitleOfElement(secondPositionInGroup).equals(admins));

		mouseOver(ELEMENT_LINK_GROUP, true);
		Assert.assertTrue(getTitleOfElement(firstPositionInMenu).equals(exBoard));
        
        if (ieFlag) {
            mouseOver(ELEMENT_LINK_GROUP, true);
        }
        Assert.assertTrue(getTitleOfElement(secondPositionInMenu).equals(admins));
        
		System.out.println("-- Return to old priority--");
		
		System.out.println("--Edit priority--");

		goToGroup();
		
		click(exBoardEditProperties);
		
		waitForTextPresent("Page Navigation Form");
		
		select(ELEMENT_INPUT_PRIORITY, "5");

		save();
		
		System.out.println("--Check after change to old priority--");
		
        pause(500);
		goToGroup();
		
        Assert.assertTrue(getTitleOfElement(firstPositionInGroup).equals(admins));
        Assert.assertTrue(getTitleOfElement(secondPositionInGroup).equals(exBoard));

        mouseOver(ELEMENT_LINK_GROUP, true);
        Assert.assertTrue(getTitleOfElement(firstPositionInMenu).equals(admins));
        
        if (ieFlag) {
            mouseOver(ELEMENT_LINK_GROUP, true);
        }
        Assert.assertTrue(getTitleOfElement(secondPositionInMenu).equals(exBoard));

		signOut();
	}

}
