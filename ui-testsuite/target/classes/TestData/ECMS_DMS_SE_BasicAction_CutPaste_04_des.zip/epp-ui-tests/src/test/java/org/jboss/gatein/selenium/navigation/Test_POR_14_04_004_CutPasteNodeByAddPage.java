package org.jboss.gatein.selenium.navigation;

import org.jboss.gatein.selenium.AbstractTestCase;
import org.testng.annotations.Test;

import static org.jboss.gatein.selenium.common.CommonHelper.*;
import static org.jboss.gatein.selenium.navigation.NavigationHelper.*;
import static org.jboss.gatein.selenium.page.PageHelper.*;

public class Test_POR_14_04_004_CutPasteNodeByAddPage extends AbstractTestCase {

	@Test(groups={"navigation"})
	public void testPOR_14_04_004_CutPasteNodeByAddPage() throws Exception {
		System.out.println("--CutPasteNodeByAddPageWizard--");

		openPortal(true);

		signInAsRoot();
		
		addNewPageWithEditor("Home", "Test_POR_14_04_004", "Test_POR_14_04_004", null, null, false, null);

		goToSite();

		editFirstNavigation();

		copyNode(CopyType.CUT, null, "Test_POR_14_04_004", ELEMENT_NAVIGATION_HOME_NODE, null);

		save();

		waitForTextNotPresent("Navigation Management");

		deleteNodeFromFirstNavigation("Test_POR_14_04_004", null, true);

		goToPageManagement();

		searchAndDeletePage(PageType.PORTAL, "page", "Test_POR_14_04_004", true, "Test_POR_14_04_004");

		signOut();
	}

}
