package org.jboss.gatein.selenium.usersmanagement;

import org.jboss.gatein.selenium.AbstractTestCase;
import org.testng.Assert;
import org.testng.annotations.Test;

import static org.jboss.gatein.selenium.common.CommonHelper.*;
import static org.jboss.gatein.selenium.usersmanagement.UsersManagementHelper.*;

public class Test_PRL_04_04_003_DeleteMembershipWhileItIsBeingUsedByHimself extends AbstractTestCase {
	
	@Test(groups={"usersmanagement","two"})
	public void testPRL_04_04_003_DeleteMembershipWhileItIsBeingUsedByHimself()	throws Exception {
        
		String membershipEditIcon = ELEMENT_MEMBERSHIP_EDIT_ICON.replace("${membership}", "Test_PLT_04_04_003");
		
		System.out.println("-- Delete Membership while  it is being used by himself--");
		
		openPortal(true);
		
		signInAsRoot();
		
		goToUsersAndGroupsManagement();
		
		chooseMembershipTab();

		addNewMembership("Test_PLT_04_04_003", "Test_PLT_04_04_003", true);
		
		click(membershipEditIcon);
		
		pause(500);
		
		Assert.assertEquals("Test_PLT_04_04_003", getValue(ELEMENT_INPUT_NAME));

		System.out.println("-- Click delete membership--");
		
		deleteMembership("Test_PLT_04_04_003", false);
		
		waitForMessage("You can not delete this membership because it is in use");
		closeMessageDialog();

		click(ELEMENT_RESET_BUTTON);
		
		pause(500);
		
		Assert.assertEquals("", getValue(ELEMENT_INPUT_NAME));
		
		deleteMembership("Test_PLT_04_04_003", true);
		
		signOut();
	}

}
