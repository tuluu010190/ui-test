package org.jboss.gatein.selenium.usersmanagement;

import org.jboss.gatein.selenium.AbstractTestCase;
import org.testng.annotations.Test;

import static org.jboss.gatein.selenium.common.CommonHelper.*;
import static org.jboss.gatein.selenium.usersmanagement.UsersManagementHelper.*;

public class Test_PRL_01_022_CreateNewAccountWithFirstAndLastNameContaintsSpace extends AbstractTestCase {
	
	@Test(groups={"usersmanagement","one"})
	public void testPRL_01_022_CreateNewAccountWithFirstAndLastNameContaintsSpace()	throws Exception {
        
		System.out.println("-- Create new account with First/Last Name field contains space  --");
		
		openPortal(true);
		
		signInAsRoot();
		
		goToNewStaff();
		
		addNewAccountAtNewStaff("test_prl_01_022", "Test_PRL_01_022", "Test_PRL_01_022", "Test PRL 01 022", "Test PRL 01 022", "Test_PRL_01_022@localhost.com", "", "Dutch", true);
		
		signOut();
		
		signIn("test_prl_01_022", "Test_PRL_01_022");
        
		signOut();
		
		signInAsRoot();
		
		goToUsersAndGroupsManagement();
		
		deleteUser("test_prl_01_022");
		
		signOut();
	}

}
