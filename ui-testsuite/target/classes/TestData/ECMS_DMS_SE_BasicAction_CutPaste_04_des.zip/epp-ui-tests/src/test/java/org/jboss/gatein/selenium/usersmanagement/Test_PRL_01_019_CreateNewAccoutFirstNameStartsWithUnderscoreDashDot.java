package org.jboss.gatein.selenium.usersmanagement;

import org.jboss.gatein.selenium.AbstractTestCase;
import org.testng.annotations.Test;

import static org.jboss.gatein.selenium.common.CommonHelper.*;
import static org.jboss.gatein.selenium.usersmanagement.UsersManagementHelper.*;

public class Test_PRL_01_019_CreateNewAccoutFirstNameStartsWithUnderscoreDashDot extends AbstractTestCase {
	
	@Test(groups={"usersmanagement","one"})
	public void testPRL_01_019_CreateNewAccoutFirstNameStartsWithUnderscoreDashDot() throws Exception {
        
		System.out.println("-- Create new account when First Name starts with underscore, dash and dot--");
		
		openPortal(true);
		
		signInAsRoot();
		
		goToNewStaff();
		
		addNewAccountAtNewStaff("test_prl_01_019", "Test_PRL_01_019", "Test_PRL_01_019", "--Test_PRL_01_019", "Test_PRL_01_019", "Test_PRL_01_019@localhost.com", "", "English", true);
		
		signOut();
		
		signIn("test_prl_01_019", "Test_PRL_01_019");
		
		signOut();
		
		signInAsRoot();
		
		goToUsersAndGroupsManagement();
		
		deleteUser("test_prl_01_019");
		
		goToNewStaff();
		
		addNewAccountAtNewStaff("test_prl_01_019", "Test_PRL_01_019", "Test_PRL_01_019", "__Test_PRL_01_019", "Test_PRL_01_019", "Test_PRL_01_019@localhost.com", "", "English", true);
		
		signOut();
		
		signIn("test_prl_01_019", "Test_PRL_01_019");
		
		signOut();
		
		signInAsRoot();
		
		goToUsersAndGroupsManagement();
		
		deleteUser("test_prl_01_019");
		
		goToNewStaff();
		
		addNewAccountAtNewStaff("test_prl_01_019", "Test_PRL_01_019", "Test_PRL_01_019", "..Test_PRL_01_019", "Test_PRL_01_019", "Test_PRL_01_019@localhost.com", "", "English", true);
		
		signOut();
		
		signIn("test_prl_01_019", "Test_PRL_01_019");
		
		signOut();
		
		signInAsRoot();
		
		goToUsersAndGroupsManagement();
		
		deleteUser("test_prl_01_019");
		
		signOut();
	}

}
