package org.jboss.gatein.selenium.usersmanagement;

import org.jboss.gatein.selenium.AbstractTestCase;
import org.testng.Assert;
import org.testng.annotations.Test;

import static org.jboss.gatein.selenium.common.CommonHelper.*;
import static org.jboss.gatein.selenium.usersmanagement.UsersManagementHelper.*;

public class Test_PRL_03_06_004_EditMemberShipWhichWasRemoved extends AbstractTestCase {
	
	@Test(groups={"usersmanagement","two"})
	public void testPRL_03_06_004_EditMemberShipWhichWasRemoved() throws Exception {
        
		System.out.println("-- Edit membership which was removed--");
		
		openPortal(true);
		
		signInAsRoot();
		
		goToUsersAndGroupsManagement();
		
		chooseMembershipTab();
		
		addNewMembership("Test_PRL_03_06_004", "Test_PRL_03_06_004", true);
		
		chooseGroupTab();
		
		selectGroup("Customers");
		
		addUsersAtGroup("root", "Test_PRL_03_06_004", true, true);
		
		System.out.println("-- Choose Membership Management to delete new membership--");
		
		chooseMembershipTab();
		
		deleteMembership("Test_PRL_03_06_004", true);
		
		chooseGroupTab();
		
		selectGroup("Customers");
		
		Assert.assertEquals(getText(ELEMENT_SELECTED_GROUP_INFO), "Customers");
		
		waitForTextNotPresent("Test_PRL_03_06_004");
		
		signOut();
	}

}
