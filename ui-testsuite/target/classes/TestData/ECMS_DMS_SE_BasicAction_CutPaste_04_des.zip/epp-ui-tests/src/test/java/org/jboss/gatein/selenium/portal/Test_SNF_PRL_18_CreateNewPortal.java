package org.jboss.gatein.selenium.portal;

import static org.jboss.gatein.selenium.common.CommonHelper.*;
import static org.jboss.gatein.selenium.portal.PortalHelper.*;

import org.jboss.gatein.selenium.AbstractTestCase;
import org.testng.annotations.Test;

public class Test_SNF_PRL_18_CreateNewPortal extends AbstractTestCase {

	@Test(groups={"sniff", "epp5.0", "portal"})
	public void testSNF_PRL_18_CreateNewPortal() throws Exception {
		System.out.println("-CreateNewPortal-");

		openPortal(true);

		signInAsRoot();

		goToSite();

		createNewPortal("test_portal_18", "English", "Default", "On Demand", true, null, "Platform/Administrators", "manager");

		verifyPortalExists("test_portal_18");

		deletePortal("test_portal_18");

		signOut();
	}
}
