package org.jboss.gatein.selenium.common;

import static org.jboss.gatein.selenium.common.CommonHelper.*;

import org.jboss.gatein.selenium.AbstractTestCase;
import org.testng.annotations.Test;

public class Test_POR_01_003_SignInByNormalAccount extends AbstractTestCase {

	@Test(groups={"epp5.0", "common"})
	public void testPOR_01_003_SignInByNormalAccount() throws Exception {
		System.out.println("--Login by Demo account--");
		
		openPortal(true);

		signInAsDemo();

		waitForAndGetElement(ELEMENT_LINK_DASHBOARD);

		signOut();
		
		waitForElementNotPresent(ELEMENT_LINK_DASHBOARD);

		System.out.println("--Login by Mary account--");

		signInAsMary();

		waitForAndGetElement(ELEMENT_LINK_DASHBOARD);

		signOut();

	}

}
