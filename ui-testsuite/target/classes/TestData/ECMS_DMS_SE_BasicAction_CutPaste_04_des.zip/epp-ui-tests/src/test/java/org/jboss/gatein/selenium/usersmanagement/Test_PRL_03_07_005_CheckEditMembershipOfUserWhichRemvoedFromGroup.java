package org.jboss.gatein.selenium.usersmanagement;

import org.jboss.gatein.selenium.AbstractTestCase;
import org.testng.annotations.Test;

import static org.jboss.gatein.selenium.common.CommonHelper.*;
import static org.jboss.gatein.selenium.usersmanagement.UsersManagementHelper.*;

public class Test_PRL_03_07_005_CheckEditMembershipOfUserWhichRemvoedFromGroup extends AbstractTestCase {
	
	private final String DIALOG_MESSAGE = getMessage("usersmanagemt.message.cantSaveMembershipRemoved");
	
	@Test(groups={"usersmanagement","two"})
	public void testPRL_03_07_005_CheckEditMembershipOfUserWhichRemvoedFromGroup() throws Exception {
        
		String userEditIcon = ELEMENT_GROUP_USER_IN_TABLE_EDIT_ICON.replace("${membership}", "manager").replace("${username}", "root");
		
		System.out.println("-- Check edit membership of user which removed from group--");

		openPortal(true);
		
		signInAsRoot();
		
		goToUsersAndGroupsManagement();
		
		chooseGroupTab();
		
		selectGroup("Customers");
		
		addUsersAtGroup("root", "manager", true, true);
		
		click(userEditIcon);
		
		deleteUserFromGroup("root", "manager", "customers", true);
		
		save();

		waitForMessage(DIALOG_MESSAGE);
		closeMessageDialog();
		
		signOut();
	}

}
