package org.jboss.gatein.selenium.usersmanagement;

import org.jboss.gatein.selenium.AbstractTestCase;
import org.testng.annotations.Test;

import static org.jboss.gatein.selenium.common.CommonHelper.*;
import static org.jboss.gatein.selenium.usersmanagement.UsersManagementHelper.*;

public class Test_PRL_02_03_002_EditFirstNameOfUserInCommunityManagement extends AbstractTestCase {
	
	@Test(groups={"usersmanagement","one"})
	public void testPRL_02_03_002_EditFirstNameOfUserInCommunityManagement() throws Exception {
        
		System.out.println("-- Edit First Name of user in Community Management--");

		openPortal(true);
		
		signInAsRoot();
		
		goToNewStaff();
		
		addNewAccountAtNewStaff("test_prl_02_03_002", "Test_PRL_02_03_002", "Test_PRL_02_03_002", "Test_PRL_02_03_002", "Test_PRL_02_03_002", "Test_PRL_02_03_002@localhost.com", "", "English", true);
		
		goToUsersAndGroupsManagement();
		
		searchUserByUserName("test_prl_02_03_002");
		
		System.out.println("-- Edit with blank First Name--");
		
		editFirstNameAndCheckMessage("", "The field \"First Name\" is required.", true);

		System.out.println("-- Edit with First Name contains special characters --");
		
		editFirstNameAndCheckMessage("#$#%#^#@", "The user profile has been updated.", false);

		System.out.println("-- Change current value of First Name with dash --");
		
		editFirstNameAndCheckMessage("----Test_PRL_02_03_002", "The user profile has been updated.", true);

		System.out.println("-- Change current value of First Name with underscore--");
		
		editFirstNameAndCheckMessage("____Test_PRL_02_03_002", "The user profile has been updated.", true);

		System.out.println("--  Edit with First Name start with number--");
		
		editFirstNameAndCheckMessage("02_03_002", "The user profile has been updated.", true);

		System.out.println("-- Edit with First Name contains space--");

		editFirstNameAndCheckMessage("Test_PRL_02_03_002 Test_PRL_02_03_002", "The user profile has been updated.", true);
		
		System.out.println("-- Edit with valid value for First Name--");
		
		editFirstNameAndCheckMessage("Test_PRL_02_03_002_edit", "The user profile has been updated.", true);

		deleteUser("test_prl_02_03_002");
		
        waitForMessage("No result found.");
        closeMessageDialog();
        
		signOut();
	}
	
	private static void editFirstNameAndCheckMessage(String newFirstName, String message, boolean editOnStart) throws Exception {
		if (editOnStart) {
            editUser("test_prl_02_03_002");
        }
		type(ELEMENT_INPUT_FIRSTNAME, newFirstName, true);
		save();
		waitForMessage(message);
		closeMessageDialog();
	}

}
