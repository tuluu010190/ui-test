package org.jboss.gatein.selenium.applicationregistry;

import org.jboss.gatein.selenium.AbstractTestCase;
import org.testng.annotations.Test;

import static org.jboss.gatein.selenium.common.CommonHelper.*;
import static org.jboss.gatein.selenium.applicationregistry.ApplicationRegistryHelper.*;

public class Test_PRL_07_02_005_AddRemoteGadgetWithURLExisting extends AbstractTestCase {
	
	@Test(groups={"applicationregistry"})
	public void testPRL_07_02_005_AddRemoteGadgetWithURLExisting()
			throws Exception {
		System.out.println("-- Add a remote gadget with URL existing --");
		
		openPortal(true);

		signInAsRoot();
		
        goToApplicationRegistry();
        
		click(ELEMENT_GADGETS_TAB_LINK);

		addRemoteGadget("http://www.labpixies.com/campaigns/babylon/babylon.xml", true);
		
		addNewGadgetToCategory("Babylon Translation Box");
		
		System.out.println("-- Add URL is the same existing --");
		
		addRemoteGadget("http://www.labpixies.com/campaigns/babylon/babylon.xml", false);

		waitForMessage("This url is existing, please select another one!");
		closeMessageDialog();
		
		System.out.println("-- Delete this gadget--");

		deleteGadget("Babylon Translation Box");
		
		signOut();
	}

}
