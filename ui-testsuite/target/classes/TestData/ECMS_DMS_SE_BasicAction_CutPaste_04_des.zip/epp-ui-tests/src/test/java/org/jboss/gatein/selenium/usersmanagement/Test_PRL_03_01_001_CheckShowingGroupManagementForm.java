package org.jboss.gatein.selenium.usersmanagement;

import org.jboss.gatein.selenium.AbstractTestCase;
import org.testng.Assert;
import org.testng.annotations.Test;

import static org.jboss.gatein.selenium.common.CommonHelper.*;
import static org.jboss.gatein.selenium.usersmanagement.UsersManagementHelper.*;

public class Test_PRL_03_01_001_CheckShowingGroupManagementForm extends AbstractTestCase {
	
	@Test(groups={"usersmanagement","two"})
	public void testPRL_03_01_001_CheckShowingGroupManagementForm()	throws Exception {
        
		String organizationGroup = ELEMENT_GROUP_TO_SELECT_LINK.replace("${group}", "Organization");
		String communicationGroup = ELEMENT_GROUP_TO_SELECT_LINK.replace("${group}", "Communication") + "/../..";
		String managementGroup = ELEMENT_GROUP_TO_SELECT_LINK.replace("${group}", "Management") + "/../..";
		String customersGroup = ELEMENT_GROUP_TO_SELECT_LINK.replace("${group}", "Customers");
        
        String secondInForm = "//div[@class='HomeNode']/../div[2]";
        String thirdInForm = "//div[@class='HomeNode']/../div[3]";
		
		System.out.println("-- Check showing Group Management form--");
		
		openPortal(true);
		
		signInAsRoot();
		
		goToUsersAndGroupsManagement();
		
		chooseGroupTab();
		
		System.out.println("-- Select a group from left pane by clicking on group name--");
		
		selectGroup("Customers");
		
		Assert.assertTrue(isTextAtElementEqual(ELEMENT_SELECTED_GROUP_INFO, "Customers"));
		
		System.out.println("-- Select a group from left pane by clicking cross icon (+) --");

		click(organizationGroup);
		
		pause(500);
		
		Assert.assertTrue(isTextAtElementEqual(ELEMENT_SELECTED_GROUP_INFO, "Organization"));
		
		System.out.println("-- Check showing path to selected group--");
		
		selectGroup("Communication");
		
        Assert.assertEquals(waitForAndGetElement(secondInForm), waitForAndGetElement(communicationGroup));
        Assert.assertEquals(waitForAndGetElement(thirdInForm), waitForAndGetElement(managementGroup));

		System.out.println("-- Check Up level function while showing sub group--");

		click(ELEMENT_GROUP_LEVEL_UP_ICON);

		waitForAndGetElement(customersGroup);

		System.out.println("-- Check Up level while showing last parent group--");

		click(ELEMENT_GROUP_LEVEL_UP_ICON);

		waitForElementNotPresent(ELEMENT_SELECTED_GROUP_INFO);
		
		signOut();
	}

}
