package org.jboss.gatein.selenium.usersmanagement;

import org.jboss.gatein.selenium.AbstractTestCase;
import org.testng.annotations.Test;

import static org.jboss.gatein.selenium.common.CommonHelper.*;
import static org.jboss.gatein.selenium.usersmanagement.UsersManagementHelper.*;

public class Test_PRL_03_02_006_AddNewGroupWIthNameContainsSpace extends AbstractTestCase {
	
	@Test(groups={"usersmanagement","two"})
	public void testPRL_03_02_006_AddNewGroupWIthNameContainsSpace() throws Exception {
        
		System.out.println("-- Add new group with Name contains space--");
		
		openPortal(true);
		
		signInAsRoot();

		goToUsersAndGroupsManagement();
		
		chooseGroupTab();
		
		System.out.println("-- Add new group with Name containing spaces--");
		
		addNewGroup("Test PRL 02 03 006", "Test_PRL_02_03_006", "Test_PRL_02_03_006", false);
		
		waitForMessage("Only alpha, digit, dash and underscore characters allowed for the field \"Group Name\".");
		closeMessageDialog();
		
		cancel();

		signOut();
	}

}
