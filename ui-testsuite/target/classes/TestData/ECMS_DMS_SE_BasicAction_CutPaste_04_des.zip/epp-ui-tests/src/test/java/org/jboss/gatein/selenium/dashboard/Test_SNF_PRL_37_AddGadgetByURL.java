package org.jboss.gatein.selenium.dashboard;

import org.jboss.gatein.selenium.AbstractTestCase;
import org.testng.annotations.Test;

import static org.jboss.gatein.selenium.common.CommonHelper.*;
import static org.jboss.gatein.selenium.dashboard.DashboardHelper.*;
import static org.jboss.gatein.selenium.applicationregistry.ApplicationRegistryHelper.*;

public class Test_SNF_PRL_37_AddGadgetByURL extends AbstractTestCase {
    
    @Test(groups={"sniff", "dashboard"})
	public void testSNF_PRL_37_AddGadgetByURL() throws Exception {
        
        String gadget1Title = ELEMENT_GADGET_TITLE.replace("${title}", "Date & Time");
		String gadget1Delete = ELEMENT_GADGET_DELETE_ICON.replace("${title}", "Date & Time");
        		
		openPortal(true);

		signInAsRoot();

		goToDashboard();
        
        System.out.println("--Add gadgets into dashboard page by url");
        
        click(ELEMENT_ADD_GADGETS_LINK);
		
		type(ELEMENT_INPUT_URL, URL_GADGET_DATETIME, true);

		click(ELEMENT_ADD_GADGET_ADD_ICON);

		click(ELEMENT_ADD_GADGETS_CLOSE_BUTTON);
        
		waitForAndGetElement(gadget1Title);

		click(gadget1Delete);

		waitForConfirmation("Are you sure to delete this gadget?");
        
        waitForTextPresent("Drag your gadgets here.");
		
		signOut();
    }
}
