package org.jboss.gatein.selenium.navigation;

import org.jboss.gatein.selenium.AbstractTestCase;
import org.testng.annotations.Test;

import static org.jboss.gatein.selenium.common.CommonHelper.*;
import static org.jboss.gatein.selenium.navigation.NavigationHelper.*;

public class Test_POR_25_05_001_CutPasteNodeToSamePlace extends AbstractTestCase {
	
	@Test(groups={"epp5.0", "navigation"})
	public void testPOR_25_05_001_CutPasteNodeToSamePlace() throws Exception {
        
		String organizationNode = ELEMENT_NODE_LINK.replace("${nodeLabel}", "Organization");
		
		System.out.println("--CutPasteNodeToSamePlace--");

		openPortal(true);
		
		signInAsRoot();
		
		goToGroup();
		
		editNavigation("Executive Board");
		
		copyNode(CopyType.CUT, null, "New Staff", organizationNode, null);

		waitForMessage("This node name already exists.");
		
		closeMessageDialog();
		
		save();
		
		waitForTextNotPresent("Navigation Management");
		
		signOut();
	}

}
