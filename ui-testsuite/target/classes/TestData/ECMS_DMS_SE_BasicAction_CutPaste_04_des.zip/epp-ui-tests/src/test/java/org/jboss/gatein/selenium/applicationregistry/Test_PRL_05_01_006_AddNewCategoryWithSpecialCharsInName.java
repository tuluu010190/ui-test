package org.jboss.gatein.selenium.applicationregistry;

import java.util.HashMap;
import java.util.Map;

import org.jboss.gatein.selenium.AbstractTestCase;
import org.testng.annotations.Test;

import static org.jboss.gatein.selenium.common.CommonHelper.*;
import static org.jboss.gatein.selenium.applicationregistry.ApplicationRegistryHelper.*;

public class Test_PRL_05_01_006_AddNewCategoryWithSpecialCharsInName extends AbstractTestCase {
	
	@Test(groups={"applicationregistry"})
	public void testPRL_05_01_006_AddNewCategoryWithSpecialCharsInName()
			throws Exception {
		System.out.println("-- Add new category with special characters in name--");

		openPortal(true);
		
		signInAsRoot();
		
		goToApplicationRegistry();
		
		Map<String, String> permissions = new HashMap<String, String>();
		permissions.put("Customers", "*");
		addNewCategory("@$@%@^", "Test_PRL_05_01_006", "Test_PRL_05_01_006", false, permissions, false);
		
		waitForMessage("Only alpha, digit, dash and underscore characters allowed for the field \"Category name\".");
		closeMessageDialog();
		
		cancel();

		signOut();
	}

}
