package org.jboss.gatein.selenium.portal;

import org.jboss.gatein.selenium.AbstractTestCase;
import org.testng.annotations.Test;

import static org.jboss.gatein.selenium.common.CommonHelper.*;
import static org.jboss.gatein.selenium.page.PageHelper.*;
import static org.jboss.gatein.selenium.permission.PermissionHelper.*;

public class Test_POR_12_02_007_EditCurrentPortalWithNoOneForEditRight extends AbstractTestCase {
	
	@Test(groups={"epp5.0", "portal"})
	public void testPOR_12_02_007_EditCurrentPortalWithNoOneForEditRight() throws Exception {
        
		System.out.println("-- Edit Current Portal With No one For Edit Right");
		
		openPortal(true);

		signInAsRoot();

		goToEditLayout();

		System.out.println("- Change Portal Properties -");

		click(ELEMENT_SITE_CONFIG_LINK);

		click(ELEMENT_PERMISSION_SETTING_TAB);

		click(ELEMENT_LINK_EDIT_PERMISSION);

		System.out.println("- Delete all edit permissions -");

		click(ELELENT_LINK_DELETE_PERMISSION);

		save();

        waitForMessage("The \"Edit Permission Setting\" list can not be empty.");
        
        if (ieFlag) {
            click("//a[text()='OK']");
        } else {
            closeMessageDialog();
        }
        
		cancel();

		click(ELEMENT_EDIT_LAYOUT_ABORT_BUTTON);
		
		waitForPopupConfirmationAndConfirm("Modifications have been made. Are you sure you want to close without saving ?");
		
		signOut();
	}

}
