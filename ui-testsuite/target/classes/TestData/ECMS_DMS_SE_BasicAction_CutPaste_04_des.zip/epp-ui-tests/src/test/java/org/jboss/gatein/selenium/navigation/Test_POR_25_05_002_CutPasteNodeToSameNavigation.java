package org.jboss.gatein.selenium.navigation;

import org.jboss.gatein.selenium.AbstractTestCase;
import org.testng.annotations.Test;

import static org.jboss.gatein.selenium.common.CommonHelper.*;
import static org.jboss.gatein.selenium.navigation.NavigationHelper.*;

public class Test_POR_25_05_002_CutPasteNodeToSameNavigation extends AbstractTestCase {
	
	@Test(groups={"epp5.0", "navigation"})
	public void testPOR_25_05_002_CutPasteNodeToSameNavigation() throws Exception {
        
		String organizationNode = ELEMENT_NODE_LINK.replace("${nodeLabel}", "Organization");
		
		System.out.println("--CutPasteNodeToSameNavigation--");
		
		openPortal(true);
		
		signInAsRoot();
		
		goToGroup();
		
		editNavigation("Executive Board");
		
		copyNode(CopyType.CUT, null, "Users and groups management", ELEMENT_NAVIGATION_HOME_NODE, null);

		save();
		
		waitForTextNotPresent("Navigation Management");

		System.out.println("--Move node back to original place--");
		
		editNavigation("Executive Board");
		
		copyNode(CopyType.CUT, null, "Users and groups management", organizationNode, null);
		
		save();
		
		waitForTextNotPresent("Navigation Management");
		
        goToUsersAndGroupsManagement();
		
		signOut();
	}

}
