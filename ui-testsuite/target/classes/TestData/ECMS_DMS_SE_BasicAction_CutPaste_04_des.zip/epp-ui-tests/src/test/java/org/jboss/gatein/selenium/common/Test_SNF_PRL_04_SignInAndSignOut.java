package org.jboss.gatein.selenium.common;

import static org.jboss.gatein.selenium.common.CommonHelper.*;

import org.jboss.gatein.selenium.AbstractTestCase;
import org.testng.annotations.Test;

public class Test_SNF_PRL_04_SignInAndSignOut extends AbstractTestCase {
	
	@Test(groups={"sniff", "epp5.0", "common"})
	public void testSNF_PRL_04_SignInAndSignOut() throws Exception {
		System.out.println("-SignInOut-");
		
		openPortal(true);

		signInAsRoot();

		signOut();
	}
}
