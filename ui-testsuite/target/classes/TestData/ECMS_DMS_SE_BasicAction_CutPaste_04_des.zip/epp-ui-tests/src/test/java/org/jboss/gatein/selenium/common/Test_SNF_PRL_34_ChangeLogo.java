package org.jboss.gatein.selenium.common;

import org.jboss.gatein.selenium.AbstractTestCase;
import org.testng.Assert;
import org.testng.annotations.Test;

import static org.jboss.gatein.selenium.common.CommonHelper.*;
import static org.jboss.gatein.selenium.page.PageHelper.*;

public class Test_SNF_PRL_34_ChangeLogo extends AbstractTestCase {
	
	@Test(groups={"sniff", "epp5.0", "common"})
	public void testSNF_PRL_34_ChangeLogo() throws Exception {
		
		String editedLogo = "//div[@id='UILogoPortlet']/a/img[@src='http://www.jboss.com/images/common/redhat_logo-lg.png']";
		
		System.out.println("-LogoPortletAccSetting-");
		
		openPortal(true);

		signInAsRoot();

		goToDashboard();

		System.out.println("--Edit Logo Picture");
		
		goToEditLayout();
		
		editSpecifiedPortletOrContainer("1", false, ELEMENT_INPUT_LOGO_URL);
		
		type(ELEMENT_INPUT_LOGO_URL, "http://www.jboss.com/images/common/redhat_logo-lg.png", true);

		save();
		
		close();
		
		click(ELEMENT_EDIT_LAYOUT_FINISH_BUTTON);

        waitForAndGetElement(editedLogo);
		
		signOut();
	}

}
