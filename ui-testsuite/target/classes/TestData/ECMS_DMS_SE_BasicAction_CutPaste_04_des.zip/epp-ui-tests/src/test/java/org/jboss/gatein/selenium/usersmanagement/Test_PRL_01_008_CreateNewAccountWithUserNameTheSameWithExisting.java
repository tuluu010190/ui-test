package org.jboss.gatein.selenium.usersmanagement;

import org.jboss.gatein.selenium.AbstractTestCase;
import org.testng.annotations.Test;

import static org.jboss.gatein.selenium.common.CommonHelper.*;
import static org.jboss.gatein.selenium.language.LanguageHelper.*;
import static org.jboss.gatein.selenium.usersmanagement.UsersManagementHelper.*;

public class Test_PRL_01_008_CreateNewAccountWithUserNameTheSameWithExisting extends AbstractTestCase {
	
	@Test(groups={"usersmanagement","one"})
	public void testPRL_01_008_CreateNewAccountWithUserNameTheSameWithExisting() throws Exception {
        
		System.out.println("-- Add new user--");

		openPortal(true);
		
		signInAsRoot();
		
		goToNewStaff();

		addNewAccountAtNewStaff("test_prl_01_008", "Test_PRL_01_008", "Test_PRL_01_008", "Test_PRL_01_008", "Test_PRL_01_008", "Test_PRL_01_008@localhost.com", "", "Russian", true);
		
		addNewAccountAtNewStaff("test_prl_01_008", "Test_PRL_01_008", "Test_PRL_01_008", "Test_PRL_01_008", "Test_PRL_01_008", "Test_PRL_01_008@localhost.com", "", "English", false);
		
		waitForMessage("This user name already exists, please enter a different name.");
		closeMessageDialog();
		
		signOut();
		
		signIn("test_prl_01_008", "Test_PRL_01_008");
		
		waitForTextPresent(HOME_LABEL_RUSSIAN);
		
		signOut();
		
		signInAsRoot();
		
		goToUsersAndGroupsManagement();
		
		deleteUser("test_prl_01_008");
		
		signOut();
	}

}
