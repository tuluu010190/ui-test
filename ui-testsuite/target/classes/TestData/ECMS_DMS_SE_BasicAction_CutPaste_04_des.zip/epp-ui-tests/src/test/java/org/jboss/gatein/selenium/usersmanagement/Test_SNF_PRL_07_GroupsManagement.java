package org.jboss.gatein.selenium.usersmanagement;

import static org.jboss.gatein.selenium.common.CommonHelper.*;
import static org.jboss.gatein.selenium.usersmanagement.UsersManagementHelper.*;

import org.jboss.gatein.selenium.AbstractTestCase;
import org.testng.annotations.Test;

public class Test_SNF_PRL_07_GroupsManagement extends AbstractTestCase {
	
	@Test(groups={"sniff", "epp5.0", "usersmanagement","one"})
	public void testSNF_PRL_07_GroupsManagement() throws Exception {
        
		System.out.println("-GroupManagement-");
		
		openPortal(true);

		signInAsRoot();
		
		goToUsersAndGroupsManagement();

		chooseGroupTab();
		
		waitForTextPresent("Group Info");
		
		selectGroup("Organization/Management");

		addNewGroup("test_group_name_07", "test_group_label_07", "test_group_description_07", true);

		selectGroup("test_group_label_07");
		
		addUsersAtGroup("john,mary,root", "member", true, true);

		deleteGroup("test_group_label_07", true);

		signOut();
	}

}
