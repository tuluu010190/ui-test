package org.jboss.gatein.selenium.common;

import static org.jboss.gatein.selenium.common.CommonHelper.*;

import org.jboss.gatein.selenium.AbstractTestCase;
import org.testng.annotations.Test;

public class Test_SNF_PRL_17_SiteMap extends AbstractTestCase {
	
	@Test(groups={"sniff", "epp5.0", "common"})
	public void testSNF_PRL_17_SiteMap() throws Exception {
		String expandAdministrationLink = ELEMENT_SITEMAP_EXPAND_LINK.replace("${page}", "Administration");
		String expandOrganizationLink = ELEMENT_SITEMAP_EXPAND_LINK.replace("${page}", "Organization");
		String expandMyLink = ELEMENT_SITEMAP_EXPAND_LINK.replace("${page}", "My Link");
		
		String collapseAdministrationLink = ELEMENT_SITEMAP_COLLAPSE_LINK.replace("${page}", "Administration");
		
		System.out.println("-CollapseAll-");
		
		openPortal(true);

		signInAsRoot();

		goToSiteMap();
		
		System.out.println("--Expand SiteMap Tree");

		click(expandAdministrationLink);
		
		click(expandOrganizationLink);
		
		click(expandMyLink);
		
		System.out.println("--Collapse SiteMap Tree");
		
		click(collapseAdministrationLink);
                
		click(ELEMENT_LINK_COLLAPSE_ALL);//natrvalo

        waitForElementNotPresent(ELEMENT_SITEMAP_LINK.replace("${page}", "New Staff"));

        waitForElementNotPresent(ELEMENT_SITEMAP_LINK.replace("${page}", "Blog"));

		signOut();
	}

}
