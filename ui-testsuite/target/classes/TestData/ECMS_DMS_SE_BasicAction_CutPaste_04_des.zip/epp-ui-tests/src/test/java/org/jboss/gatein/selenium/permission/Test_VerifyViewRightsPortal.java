package org.jboss.gatein.selenium.permission;

import java.util.HashMap;
import java.util.Map;

import org.jboss.gatein.selenium.AbstractTestCase;
import org.testng.Assert;
import org.testng.annotations.Test;
import com.thoughtworks.selenium.SeleniumException;

import static org.jboss.gatein.selenium.common.CommonHelper.*;
import static org.jboss.gatein.selenium.portal.PortalHelper.*;

public class Test_VerifyViewRightsPortal extends AbstractTestCase {
	
	@Test(groups={"epp5.0", "permission"})
	public void testVerifyViewRightsPortal() throws Exception {
		String portalLink = "//a[text()='portalWithLimitedViewRights']";
		String loginForm = "//div[@class='UILogin']";
        
		System.out.println("--Verify portal view permissions--");
		
		openPortal(true);

		signInAsRoot();
		
		goToSite();

		Map<String, String> viewPermissions = new HashMap<String, String>();
		viewPermissions.put("Platform/Administrators", "*");
		
		createNewPortal("portalWithLimitedViewRights", "English", "Default", "On Demand", false, viewPermissions, "Platform/Administrators", "*");
		
		verifyPortalExists("portalWithLimitedViewRights");

		goToPage(ELEMENT_TEST_USER_ADMIN, ELEMENT_LINK_SITE, "portalWithLimitedViewRights");
        
        goToSite();
        
        goToPage(ELEMENT_TEST_USER_ADMIN, ELEMENT_LINK_SITE, "portalWithLimitedViewRights", ELEMENT_LINK_HOME);

		System.out.println("--Sign out from created portal--");

		goToPage(loginForm, ELEMENT_LINK_PORTAL_TOP_CONTAINER, ELEMENT_SIGN_OUT_LINK);

		System.out.println("--Verify portal with mary account--");

		openPortal(true);

		signInAsMary();

        mouseOver(ELEMENT_LINK_SITE, true);
        waitForAndGetElement(ELEMENT_LINK_CLASSIC_PORTAL);
		Assert.assertFalse(isElementPresent(portalLink));

		try {
            open(getPortalUrl().concat("/portalWithLimitedViewRights"));
        } catch (SeleniumException ex) {}

		waitForTextPresent("403");
		
		openPortal(false);

		signOut();

		System.out.println("--Sign in as root and verify portal--");

		signInAsRoot();

		System.out.println("--Delete portal--");

		deletePortal("portalWithLimitedViewRights");
		
		signOut();
	}

}
