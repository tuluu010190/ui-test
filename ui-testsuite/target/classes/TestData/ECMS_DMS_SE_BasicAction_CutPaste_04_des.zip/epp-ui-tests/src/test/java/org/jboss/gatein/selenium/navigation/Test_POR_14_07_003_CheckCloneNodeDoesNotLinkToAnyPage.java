package org.jboss.gatein.selenium.navigation;

import org.jboss.gatein.selenium.AbstractTestCase;
import org.testng.annotations.Test;

import static org.jboss.gatein.selenium.common.CommonHelper.*;
import static org.jboss.gatein.selenium.navigation.NavigationHelper.*;
import static org.jboss.gatein.selenium.page.PageHelper.*;


public class Test_POR_14_07_003_CheckCloneNodeDoesNotLinkToAnyPage extends AbstractTestCase {
	
	@Test(groups={"navigation"})
	public void testPOR_14_07_003_CheckCloneNodeDoesNotLinkToAnyPage() throws Exception {
        
		String homeNode = ELEMENT_NODE_LINK.replace("${nodeLabel}", "Home");
		
		System.out.println("--CheckCloneNodeDoesNotLinkToAnyPage--");
		
		openPortal(true);
		
		signInAsRoot();
		
		goToSite();
		
		addNewNode("POR_14_07_003", "POR_14_07_003", false, ELEMENT_NAVIGATION_HOME_NODE, null, null, false, true, false, null);

		editFirstNavigation();
		
		copyNode(CopyType.CLONE, null, "POR_14_07_003", homeNode, null);

		save();
		
		waitForTextNotPresent("Navigation Management");

		System.out.println("--Check page list in Manage Page--");

		goToPageManagement();

		searchPageByTitle(PageType.PORTAL, "POR_14_07_003", null);
		
		waitForMessage("No result found.");
		closeMessageDialog();
		
		goToSite();
		
		deleteNodeFromFirstNavigation("POR_14_07_003", null, false);
		
		deleteNodeFromFirstNavigation("POR_14_07_003", null, true);
		
		signOut();
	}

}
