package org.jboss.gatein.selenium.common;

import junit.framework.Assert;
import static org.jboss.gatein.selenium.common.CommonHelper.*;

import org.jboss.gatein.selenium.AbstractTestCase;
import org.testng.annotations.Test;

public class Test_SNF_PRL_05_RememberMyLogin extends AbstractTestCase {

	@Test(groups={"sniff", "epp5.0", "common"})
	public void testSNF_PRL_05_RememberMyLogin() throws Exception {
		String signedUserLink = ELEMENT_SIGNED_USER_LINK.replace("${name}", "Root").replace("${surname}", "Root");
		
        openPortal(true);
        
        signInAsRoot();
        
        System.out.println("--Errase JSESSIONID (JSESSIONIDSSO) Cookie to simulate leaving the browser");
        
        deleteCookieNamed("JSESSIONID");
        deleteCookieNamed("JSESSIONIDSSO");//this cookie is only in gatein on jbossas5 and jbossas6
        
        Assert.assertNull(getCookieNamed("JSESSIONID"));
        Assert.assertNull(getCookieNamed("JSESSIONIDSSO"));
        
        System.out.println("--Verify if simulation of leaving browser works--");
        
        openPortal(true);
        
        waitForAndGetElement(ELEMENT_SIGN_IN_LINK);
        
		System.out.println("-RememberMyLogin-");
		
		signInWithRememberChecked("root", "gtn");

		System.out.println("--Errase JSESSIONID (JSESSIONIDSSO) Cookie to simulate leaving the browser");
        
        deleteCookieNamed("JSESSIONID");
        deleteCookieNamed("JSESSIONIDSSO");//this cookie is only in gatein on jbossas5 and jbossas6

        Assert.assertNull(getCookieNamed("JSESSIONID"));
        Assert.assertNull(getCookieNamed("JSESSIONIDSSO"));
        
		System.out.println("--Verify Rememberme functionality works");

		openPortal(true);

		waitForAndGetElement(signedUserLink);

		signOut();
	}
}
