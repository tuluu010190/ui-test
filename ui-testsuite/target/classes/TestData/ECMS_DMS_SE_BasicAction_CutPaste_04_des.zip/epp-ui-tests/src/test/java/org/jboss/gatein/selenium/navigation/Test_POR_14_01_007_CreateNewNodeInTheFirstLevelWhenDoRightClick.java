package org.jboss.gatein.selenium.navigation;

import org.jboss.gatein.selenium.AbstractTestCase;
import org.testng.annotations.Test;

import static org.jboss.gatein.selenium.common.CommonHelper.*;
import static org.jboss.gatein.selenium.navigation.NavigationHelper.*;

public class Test_POR_14_01_007_CreateNewNodeInTheFirstLevelWhenDoRightClick extends AbstractTestCase {

	@Test(groups={"navigation"})
	public void testPOR_14_01_007_CreateNewNodeInTheFirstLevelWhenDoRightClick() throws Exception {
        
        String verification = BREADCRUMB_PORTLET_SELECTED_NODE.replace("${node_label}", "Test_POR_14_01_007");
        
		System.out.println("--CreateNewNodeInTheFirstLevelWhenDoRightClick--");

		openPortal(true);
		
		signInAsRoot();

		goToSite();

		System.out.println("--Create new node in the first level when do right click--");
		
		addNewNode("Test_POR_14_01_007", "Test_POR_14_01_007", false, ELEMENT_NAVIGATION_HOME_NODE, null, null, false, true, false, null);
		
		System.out.println("--View page (node)--");

		goToPage(verification, ELEMENT_LINK_SITE, ELEMENT_LINK_CLASSIC_PORTAL, "Test_POR_14_01_007");

        goToSite();

		deleteNodeFromFirstNavigation("Test_POR_14_01_007", null, true);
		
		signOut();
	}

}
