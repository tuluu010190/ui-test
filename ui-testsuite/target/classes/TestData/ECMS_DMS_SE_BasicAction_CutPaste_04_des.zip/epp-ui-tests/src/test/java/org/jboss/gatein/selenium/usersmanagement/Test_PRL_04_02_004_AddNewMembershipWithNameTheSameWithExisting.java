package org.jboss.gatein.selenium.usersmanagement;

import org.jboss.gatein.selenium.AbstractTestCase;
import org.testng.annotations.Test;

import static org.jboss.gatein.selenium.common.CommonHelper.*;
import static org.jboss.gatein.selenium.usersmanagement.UsersManagementHelper.*;

public class Test_PRL_04_02_004_AddNewMembershipWithNameTheSameWithExisting extends AbstractTestCase {
	
	@Test(groups={"usersmanagement","two"})
	public void testPRL_04_02_004_AddNewMembershipWithNameTheSameWithExisting() throws Exception {
        
		System.out.println("-- Add new membership with name the same with existing--");
		
		openPortal(true);
		
		signInAsRoot();
		
		goToUsersAndGroupsManagement();
		
		chooseMembershipTab();

		addNewMembership("Test_PLT_04_02_004", "Test_PLT_04_02_004", true);
		
		addNewMembership("Test_PLT_04_02_004", "Test_PLT_04_02_004", false);
		
		waitForMessage("This membership already exists, please enter another one");
		closeMessageDialog();
		
		deleteMembership("Test_PLT_04_02_004", false);

		signOut();
	}

}
