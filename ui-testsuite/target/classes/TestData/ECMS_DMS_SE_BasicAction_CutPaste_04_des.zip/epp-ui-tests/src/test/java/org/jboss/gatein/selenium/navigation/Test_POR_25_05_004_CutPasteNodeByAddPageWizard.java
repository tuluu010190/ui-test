package org.jboss.gatein.selenium.navigation;

import org.jboss.gatein.selenium.AbstractTestCase;
import org.testng.annotations.Test;

import static org.jboss.gatein.selenium.common.CommonHelper.*;
import static org.jboss.gatein.selenium.navigation.NavigationHelper.*;
import static org.jboss.gatein.selenium.page.PageHelper.*;

public class Test_POR_25_05_004_CutPasteNodeByAddPageWizard extends AbstractTestCase {
	
	@Test(groups={"epp5.0", "navigation"})
	public void testPOR_25_05_004_CutPasteNodeByAddPageWizard()
			throws Exception {
		System.out.println("--CutPasteNodeByAddPageWizard--");

		openPortal(true);
		
		signInAsRoot();
		
		goToNewStaff();

		addNewPageWithEditor(null, "Test_POR_25_05_004", "Test_POR_25_05_004", null, null, false, null);

		goToGroup();

		editNavigation("Executive Board");
		
		copyNode(CopyType.CUT, "New Staff", "Test_POR_25_05_004", ELEMENT_NAVIGATION_HOME_NODE, null);

		save();
		
		waitForTextNotPresent("Navigation Management");

		deleteNodeFromNavigation("Executive Board", "Test_POR_25_05_004", null, true);
		
		goToPageManagement();
		
		searchAndDeletePage(PageType.GROUP, "page", "Test_POR_25_05_004", true, "Test_POR_25_05_004");
		
		signOut();
	}

}
