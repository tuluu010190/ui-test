package org.jboss.gatein.selenium.usersmanagement;

import org.jboss.gatein.selenium.AbstractTestCase;
import org.testng.annotations.Test;

import static org.jboss.gatein.selenium.common.CommonHelper.*;
import static org.jboss.gatein.selenium.usersmanagement.UsersManagementHelper.*;

public class Test_PRL_03_02_012_AddNewGroupSameNameWithExisting extends AbstractTestCase {
	
	@Test(groups={"usersmanagement","two"})
	public void testPRL_03_02_012_AddNewGroupSameNameWithExisting() throws Exception {
        
		System.out.println("-- Add new group same name with existing--");
		
		openPortal(true);
		
		signInAsRoot();
		
		goToUsersAndGroupsManagement();
		
		chooseGroupTab();
		
		click(ELEMENT_GROUP_LEVEL_UP_ICON);
		
		System.out.println("-- Create the first group--");
		
		addNewGroup("Test_PRL_03_02_012", "Test_PRL_03_02_012", "Test_PRL_03_02_012", true);
		
		System.out.println("-- Click up level--");
		
		click(ELEMENT_GROUP_LEVEL_UP_ICON);
		
		System.out.println("-- Create same name group in the same path--");
		
		addNewGroup("Test_PRL_03_02_012", "Test_PRL_03_02_012", "Test_PRL_03_02_012", false);
		
		waitForMessage("This group name already exists, please enter another one");
		closeMessageDialog();
		
		cancel();
		
		System.out.println("-- Create same name group in different paths--");
		
		selectGroup("Customers");
		
		addNewGroup("Test_PRL_03_02_012", "Test_PRL_03_02_012", "Test_PRL_03_02_012", true);
		
		System.out.println("-- Delete first group--");
		
        pause(500);
        
		click(ELEMENT_GROUP_LEVEL_UP_ICON);
		
		selectGroup("Test_PRL_03_02_012");
		
		deleteGroup("Test_PRL_03_02_012", false);
		
		System.out.println("-- Delete group in different paths--");
		
        pause(500);
        
		selectGroup("Customers/Test_PRL_03_02_012");
		
		deleteGroup("Test_PRL_03_02_012", true);

		signOut();
	}

}
