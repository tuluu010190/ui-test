package org.jboss.gatein.selenium.usersmanagement;

import org.jboss.gatein.selenium.AbstractTestCase;
import org.testng.annotations.Test;

import static org.jboss.gatein.selenium.common.CommonHelper.*;
import static org.jboss.gatein.selenium.usersmanagement.UsersManagementHelper.*;

public class Test_PRL_01_024_CreateNewAccoutWithInvalidEmail extends AbstractTestCase {
	
	@Test(groups={"usersmanagement","one"})
	public void testPRL_01_024_CreateNewAccoutWithInvalidEmail() throws Exception {
        
		System.out.println("--Add new user with invalid email--");
		
		openPortal(true);
		
		signInAsRoot();
		
		goToNewStaff();

		addNewAccountAtNewStaff("test_prl_01_024", "Test_PRL_01_024", "Test_PRL_01_024", "Test_PRL_01_024", "Test_PRL_01_024", "Test_PRL_01_024", "", "Ukrainian", false);
		
		waitForMessage("Your email address is invalid. Please enter a different address.");
		closeMessageDialog();

        addNewAccountAtNewStaff("test_prl_01_024", "Test_PRL_01_024", "Test_PRL_01_024", "Test_PRL_01_024", "Test_PRL_01_024", "@", "", "Ukrainian", false);
		
		waitForMessage("Your email address is invalid. Please enter a different address.");
		closeMessageDialog();

		addNewAccountAtNewStaff("test_prl_01_024", "Test_PRL_01_024", "Test_PRL_01_024", "Test_PRL_01_024", "Test_PRL_01_024", "@localhost.com", "", "Ukrainian", false);
		
		waitForMessage("Your email address is invalid. Please enter a different address.");
		closeMessageDialog();

		addNewAccountAtNewStaff("test_prl_01_024", "Test_PRL_01_024", "Test_PRL_01_024", "Test_PRL_01_024", "Test_PRL_01_024", "@localhost.com@", "", "Ukrainian", false);
		
		waitForMessage("Your email address is invalid. Please enter a different address.");
		closeMessageDialog();

		signOut();
	}

}
