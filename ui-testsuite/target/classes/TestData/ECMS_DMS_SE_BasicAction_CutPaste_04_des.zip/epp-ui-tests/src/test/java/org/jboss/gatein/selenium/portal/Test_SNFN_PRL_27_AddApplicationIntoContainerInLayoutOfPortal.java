package org.jboss.gatein.selenium.portal;

import org.testng.Assert;
import java.util.HashMap;
import java.util.Map;

import org.jboss.gatein.selenium.AbstractTestCase;
import org.testng.annotations.Test;

import static org.jboss.gatein.selenium.common.CommonHelper.*;
import static org.jboss.gatein.selenium.page.PageHelper.*;
import static org.jboss.gatein.selenium.portal.PortalHelper.*;

public class Test_SNFN_PRL_27_AddApplicationIntoContainerInLayoutOfPortal extends AbstractTestCase {
	
	@Test(groups={"sniff", "portal"})
	public void testSNFN_PRL_27_AddApplicationIntoContainerInLayoutOfPortal() throws Exception {
        
		String editLayoutIcon = ELEMENT_EDIT_LAYOUT_FROM_TABLE.replace("${portalName}", "Test_SNF_PRL_27");
		String gadgetsCategory = ELEMENT_EDIT_PAGE_CATEGORY_MENU.replace("${categoryLabel}", "Gadgets");
		String calculator = "//div[@id='Gadgets/Calculator']";
        String emptyContainerPosition1 = EMPTY_CONTAINER.replace("${portletNumber}", "1");
        String calculatorPosition1 = ELEMENT_EDIT_PAGE_COMPONENT_FIRST + PORTLET_LABEL.replace("${portletName}", "Calculator");
		
		System.out.println("-- Add application into container in layout of portal--");
		
		openPortal(true);
		
		signInAsRoot();
		
		goToSite();
		
		Map<String, String> permissions = new HashMap<String, String>();
		permissions.put("Platform/Administrators", "*");
		createNewPortal("Test_SNF_PRL_27", "English", "Default", "On Demand", false, permissions, "Platform/Administrators", "manager");
		
		verifyPortalExists("Test_SNF_PRL_27");
		
		System.out.println("-- Choose new portal and click edit layout--");
		
		click(editLayoutIcon);
		
		click(ELEMENT_SWITCH_VIEW_MODE_PORTAL);
		
        if (ieFlag) {
            pause(500);
        }
        
		click(ELEMENT_SWITCH_VIEW_MODE_PORTAL);
		
		click(ELEMENT_CONTAINERS_TAB);
		
		System.out.println("-- Add container by drag & drop--");

		dragAndDropToObject(ELEMENT_ONE_ROW_CONTAINER, ELEMENT_EDIT_PAGE_COMPONENT_FIRST, emptyContainerPosition1);
		
		click(ELEMENT_SWITCH_VIEW_MODE_PORTAL);
        
        if (ieFlag) {
            pause(500);
        }
		
		click(ELEMENT_SWITCH_VIEW_MODE_PORTAL);

		System.out.println("-- Choose Application tab--");

		click(ELEMENT_APPLICATIONS_TAB);

		System.out.println("-- Drag & drop application into the container added above--");

		click(gadgetsCategory);
		
		dragAndDropToObject(calculator, emptyContainerPosition1, calculatorPosition1);
		
		click(ELEMENT_SWITCH_VIEW_MODE_PORTAL);
		
        pause(500);
        
        Assert.assertTrue(getText(ELEMENT_EDIT_PAGE_COMPONENT_FIRST).contains("Calculator"));
		
		click(ELEMENT_SWITCH_VIEW_MODE_PORTAL);

		System.out.println("-- Delete application --");

		deleteSpecifiedPortletOrContainer(ContainerType.PORTLET, "1", true);

		System.out.println("-- Choose Container tab to delete container --");

		click(ELEMENT_CONTAINERS_TAB);

		deleteSpecifiedPortletOrContainer(ContainerType.CONTAINER, "1", false);

		System.out.println("-- Click to Finish --");

		click(ELEMENT_EDIT_LAYOUT_FINISH_BUTTON);
		
		deletePortal("Test_SNF_PRL_27");

		signOut();
	}

}
