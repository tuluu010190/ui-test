package org.jboss.gatein.selenium.page;

import java.util.Map;
import static org.jboss.gatein.selenium.common.CommonHelper.*;
import static org.jboss.gatein.selenium.permission.PermissionHelper.*;

import org.jboss.gatein.selenium.AbstractContextual;
import org.openqa.selenium.StaleElementReferenceException;
import org.testng.Assert;

public class PageHelper extends AbstractContextual {

    public static final String ELEMENT_EDITOR_LINK = "//a[@class='EditorIcon TBIcon']";
    public static final String ELEMENT_EDIT_PAGE_LINK = "//a[text()='Edit Page']";
    public static final String ELEMENT_VIEW_PAGE_PROPERTIES = "//a[@class='PageProfileIcon']";
    public static final String ELEMENT_EDIT_PAGE_CATEGORY_MENU = "//a[@class='TabLabel' and @title='${categoryLabel}']";
    public static final String ELEMENT_LINK_ADD_NEW_PAGE = "//a[text()='Add New Page']";
    public static final String ELEMENT_PAGE_LEVEL_UP_ICON = "//a[@class='LevelUpArrowIcon' and @title='Up Level']";
    public static final String ELEMENT_PAGE_EDITOR_NEXT_STEP = "//div[@class='ActionBar']//a[text()='Next']";
    public static final String ELEMENT_PAGE_FINISH_BUTTON = "//div[@id='UIPageEditor']//a[@title='Finish']";
    public static final String ELEMENT_PAGE_ABORT_BUTTON = "//div[@id='UIPageEditor']//a[@class='CloseButton']";
    public static final String ELEMENT_PAGE_CONFIGS_MENU = "//div[@id='UIDropDownPageTemp']/div[1]/div/div/div/div/div/div";
    public static final String ELEMENT_PAGE_CONFIGS_ROW = "//a[text()='Row Page Configs']";
    public static final String ELEMENT_RESIZE_BUTTON = "//span[@class='ResizeButton']";
    public static final String ELEMENT_INPUT_PAGE_NAME = "//input[@id='pageName']";
    public static final String ELEMENT_CHECKBOX_EXTENDED_LABEL_MODE = "//input[@name='switchmode']";
    public static final String ELEMENT_INPUT_PAGE_DISPLAY_NAME = "//input[@id='pageDisplayName']";
    public static final String ELEMENT_INPUT_PAGE_TITLE = "//input[@id='pageTitle']";
    public static final String ELEMENT_EDIT_LAYOUT_LINK = "//a[text()='Edit Layout']";
    public static final String ELEMENT_EDIT_LAYOUT_FINISH_BUTTON = "//div[@id='UIPortalComposer']//a[contains(@class, 'SaveButton')]";
    public static final String ELEMENT_EDIT_LAYOUT_ABORT_BUTTON = "//div[@id='UIPortalComposer']//a[@class='CloseButton']";
    public static final String ELEMENT_SITE_CONFIG_LINK = "//a[@class='PageProfileIcon']";
    public static final String ELEMENT_EDIT_PAGE_PORTLET = "//div[@id='UIPage']/div/div[${portletNumber}]/div/div/div/div";
    public static final String ELEMENT_EDIT_PAGE_PORTLET_TEMP = "//div[@id='UIPage']/div/div[${portletNumber}]/div";
    public static final String ELEMENT_EDIT_LAYOUT_PORTLET = "//div[@id='UIPortal']/div/div[${portletNumber}]/div/div/div/div";
    public static final String ELEMENT_EDIT_LAYOUT_PORTLET_TEMP = "//div[@id='UIPortal']/div/div[${portletNumber}]/div";
    public static final String ELEMENT_EDIT_PAGE_EDIT_ICON = "//div[@class='UIRowContainer']/div[${portletNumber}]//a[1]";
    public static final String ELEMENT_EDIT_PAGE_DELETE_ICON = "//div[@class='UIRowContainer']/div[${portletNumber}]//a[2]";
    public static final String ELEMENT_EDIT_PAGE_COMPONENT_DRAG_ICON = "//div[@class='UIRowContainer']/div[${number}]//div[@class='DragControlArea']";
    public static final String ELEMENT_EDIT_PAGE_COMPONENT = "//div[@class='UIRowContainer']/div[${portletNumber}]/div";
    public static final String ELEMENT_EDIT_PAGE_COMPONENT_FIRST = ELEMENT_EDIT_PAGE_COMPONENT.replace("${portletNumber}", "1");
    public static final String EMPTY_CONTAINER = ELEMENT_EDIT_PAGE_COMPONENT + "//div[@class='UIRowContainer EmptyContainer']";
    public static final String PORTLET_LABEL = "//div[@class='CPortletLayoutDecorator' and contains(text(), '${portletName}')]";
    public static final String ELEMENT_ONE_ROW_CONTAINER = "//div[@id='oneRow']/div";
    public static final String ELEMENT_PORLET_SETTING_TAB = "//div[text()='Portlet Setting' and @class='MiddleTab']";
    public static final String ELEMENT_SELECT_ICON_TAB = "//div[text()='Select Icon' and @class='MiddleTab']";
    public static final String ELEMENT_DECORATION_THEMES_TAB = "//div[text()='Decoration Themes' and @class='MiddleTab']";
    public static final String ELEMENT_SELECT_ICON_FIRST = "//div[@class='IconSelector CategoryContainer']/div/a";
    public static final String ELEMENT_DECORATION_THEME_FIRST = "//div[@id='UIItemThemeSelector']/div[2]/div[1]/div/div[2]/div/div/div";
    public static final String ELEMENT_PAGE_MANAGEMENT_BODY = "//div[@id='UIPageBrowser']";
    public static final String ELEMENT_PAGE_MANAGEMENT_SEARCH_BUTTON = "//form[@id='UIPageSearchForm']/div[2]/a[@class='SearchIcon']";
    public static final String ELEMENT_PAGE_MANAGEMENT_ADD_NEW_PAGE_BUTTON = "//div[@id='UIPageBrowser']//a[text()='Add New Page']";
    public static final String ELEMENT_PAGE_DELETE_ICON = "//div[@id='UIVirtualList']//table//tr/td/div[contains(@title, '${page}')]/../../td[5]//img[@class='DeleteIcon']";
    public static final String ELEMENT_PAGE_EDIT_ICON = "//div[@id='UIVirtualList']//table//tr/td/div[contains(@title, '${page}')]/../../td[5]//img[@class='EditInfoIcon']";
    public static final String ELEMENT_SWITCH_VIEW_MODE_PAGE = "//a[text()='Switch View mode']";
    public static final String ELEMENT_EDIT_PAGE_BODY = "//div[@id='UIPagePreview']";
    public static final String ELEMENT_EDIT_PAGE_PAGE = "//div[@id='UIPage']";
    public static final String ELEMENT_EDIT_PAGE_PAGE_BODY_COMPONENT = "//div[@id='UIPageBody']";
    public static final String ELEMENT_CONTAINERS_TAB = "//div[contains(text(),'Containers') and @class='MiddleTab']";
    public static final String ELEMENT_APPLICATIONS_TAB = "//div[contains(text(),'Applications') and @class='MiddleTab']";
    public static final String ELEMENT_EDIT_PAGE_OR_LAYOUT = "//span[@class='PopupTitle']";
    public static final String ELEMENT_INPUT_SEARCH_TITLE = "//input[@id='pageTitle']";
    private static int second = 0;

    public static enum PageType {

        PORTAL, GROUP;
    }

    public static enum ContainerType {

        PORTLET, CONTAINER;
    }

    public static void goToAddNewPage() {
        goToPage(ELEMENT_INPUT_PAGE_NAME, ELEMENT_EDITOR_LINK, ELEMENT_LINK_ADD_NEW_PAGE);
    }

    public static void goToEditPage() {
        goToPage(ELEMENT_EDIT_PAGE_OR_LAYOUT, ELEMENT_EDITOR_LINK, ELEMENT_EDIT_PAGE_LINK);
    }

    public static void goToEditLayout() {
        goToPage(ELEMENT_EDIT_PAGE_OR_LAYOUT, ELEMENT_EDITOR_LINK, ELEMENT_EDIT_LAYOUT_LINK);
    }

    public static void finishPageEdit() {
        pause(500);
        click(ELEMENT_PAGE_FINISH_BUTTON);
        waitForTextNotPresent("Page Editor");
    }

    public static void addNewPageWithEditorAtFirstLevel(String pageName, String displayName, String categoryTitle,
            Map<String, String> portletIdsAndVerification, boolean extendedLabelMode, Map<String, String> labels) {

        System.out.println("-- Add new page with editor at first level--");
        goToAddNewPage();
        click(ELEMENT_PAGE_LEVEL_UP_ICON);
        fillPageEditor(pageName, displayName, categoryTitle, portletIdsAndVerification, extendedLabelMode, labels);
        finishPageEdit();
    }

    public static void addNewPageWithEditor(String navigation, String pageName, String displayName, String categoryTitle,
            Map<String, String> portletIdsAndVerifications, boolean extendedLabelMode, Map<String, String> labels) {

        System.out.println("-- Add new page with editor--");
        goToAddNewPage();
        if (navigation != null) {
            String[] navig = navigation.split("/");
            for (String nav : navig) {
                click("//a[@title='" + nav + "']");
            }
        }
        fillPageEditor(pageName, displayName, categoryTitle, portletIdsAndVerifications, extendedLabelMode, labels);
        finishPageEdit();
    }

    public static void fillPageEditor(String pageName, String displayName, String categoryTitle, Map<String, String> portletIdsAndVerifications,
            boolean extendedLabelMode, Map<String, String> labels) {

        type(ELEMENT_INPUT_PAGE_NAME, pageName, true);

        if (extendedLabelMode) {
            Assert.assertTrue(isSelected(ELEMENT_CHECKBOX_EXTENDED_LABEL_MODE));

            for (String language : labels.keySet()) {
                select(ELEMENT_SELECT_LANGUAGE, language);
                type(ELEMENT_INPUT_LOCALIZED_LABEL, labels.get(language), true);
            }
        } else {
            uncheck(ELEMENT_CHECKBOX_EXTENDED_LABEL_MODE);
            type(ELEMENT_INPUT_PAGE_DISPLAY_NAME, displayName, true);
        }
        click(ELEMENT_PAGE_EDITOR_NEXT_STEP);
        waitForTextPresent("Empty Layout");
        click(ELEMENT_PAGE_EDITOR_NEXT_STEP);
        if (categoryTitle != null && portletIdsAndVerifications != null) {
            if (ieFlag) {
                resize(ELEMENT_RESIZE_BUTTON, 0, 100);
            }
            String category = ELEMENT_EDIT_PAGE_CATEGORY_MENU.replace("${categoryLabel}", categoryTitle);
            click(category);
            for (String portletId : portletIdsAndVerifications.keySet()) {
                String elementEditPagePage = ELEMENT_EDIT_PAGE_PAGE;
                if (ieFlag) {
                    elementEditPagePage = ELEMENT_EDIT_PAGE_PAGE + "/..";
                }
                String verification = PORTLET_LABEL.replace("${portletName}", portletIdsAndVerifications.get(portletId));
                dragAndDropToObject("//div[@id='" + portletId + "']//img", elementEditPagePage, verification);
            }
        }
    }

    public static void addNewPageAtPageManagement(String name, String title, PageType type, String groupId, String verifyText) {
        System.out.println("-- Add new " + type.name() + " page at page management--");
        click(ELEMENT_PAGE_MANAGEMENT_ADD_NEW_PAGE_BUTTON);
        type(ELEMENT_INPUT_NAME, name, true);
        type(ELEMENT_INPUT_TITLE, title, true);

        switch (type) {
            case PORTAL:
                select(ELEMENT_SELECT_OWNER_TYPE, "portal");
                break;
            case GROUP:
                select(ELEMENT_SELECT_OWNER_TYPE, "group");
                if (groupId != null) {
                    select(ELEMENT_INPUT_OWNER_ID, groupId);
                }
                break;
            default:
                break;
        }
        pause(500);
        click(ELEMENT_PERMISSION_SETTING_TAB);
        click(ELEMENT_LINK_ACCESS_PERMISSION);
        click(ELEMENT_LINK_EDIT_PERMISSION);
        save();
        if (verifyText != null) {
            waitForTextNotPresent("Page Setting");
            searchPageByTitle(type, title, verifyText);
            waitForTextPresent(verifyText);
        }
    }

    public static void searchAndDeletePage(PageType pageType, String name, String title, boolean closeDialog, String verifyText) {
        searchPageByTitle(pageType, title, verifyText);
        deletePage(pageType, name, title, closeDialog, verifyText);
    }

    public static void searchPageByTitle(PageType pageType, String title, String verifyText) {
        System.out.println("--Searching page: " + title + "--");

        type(ELEMENT_INPUT_SEARCH_TITLE, title, true);
        switch (pageType) {
            case PORTAL:
                select(ELEMENT_SELECT_SEARCH_OPTION, "portal");
                break;
            case GROUP:
                select(ELEMENT_SELECT_SEARCH_OPTION, "group");
                break;
            default:
                break;
        }
        click(ELEMENT_PAGE_MANAGEMENT_SEARCH_BUTTON);
        pause(500);
        if (verifyText != null) {
            waitForTextPresent(verifyText);
        }
    }

    public static void deletePage(PageType pageType, String name, String title, boolean closeDialog, String verifyText) {
        String pageDeleteIcon = ELEMENT_PAGE_DELETE_ICON.replace("${page}", name);

        System.out.println("--Delete page: " + title + "--");
        pause(500);
        click(pageDeleteIcon);
        waitForConfirmation("Do you want to delete this page?");
        if (closeDialog) {
            closeMessageDialog();
        }
        if (verifyText != null) {
            waitForTextNotPresent(verifyText);
        }
    }

    public static void editSpecifiedPortletOrContainer(String portletNumber, boolean portletInContainer, String verification) {
        String editPortlet = ELEMENT_EDIT_PAGE_EDIT_ICON.replace("${portletNumber}", portletNumber);
        String portlet = ELEMENT_EDIT_PAGE_COMPONENT.replace("${portletNumber}", portletNumber);

        waitForAndGetElement(ELEMENT_EDIT_PAGE_OR_LAYOUT);

        if (portletInContainer) {
            portlet = portlet.concat("/div/div/div/div");
        }
        pause(500);
        try {
            if (ieFlag) {
                actions.moveToElement(getElement(portlet));
            } else {
                mouseOver(portlet, false);
            }
            mouseOverAndClick(editPortlet);
        } catch (StaleElementReferenceException e) {
            checkCycling(e, 5);
            editSpecifiedPortletOrContainer(portletNumber, portletInContainer, verification);
        } finally {
            loopCount = 0;
        }
        if (verification != null) {
            pause(500);
            verifyEdit(portlet, editPortlet, verification);
        }
    }

    private static void verifyEdit(String portlet, String editPortlet, String xpath) {

        for (; ieFlag && isElementNotPresent(xpath); second++) {
            System.out.println("second: " + second);
            if (second >= timeoutSecInt) {
                Assert.fail("Timeout at editSpecifiedPortletOrContainer");
            }
            try {
                if (ieFlag) {
                    actions.moveToElement(getElement(portlet));
                } else {
                    mouseOver(portlet, false);
                }
                mouseOverAndClick(editPortlet);
            } catch (StaleElementReferenceException e) {
                checkCycling(e, 5);
                verifyEdit(portlet, editPortlet, xpath);
                break;
            } finally {
                loopCount = 0;
            }
        }
        second = 0;
        if (!ieFlag) {
            waitForAndGetElement(xpath);
        }
    }

    public static void deleteSpecifiedPortletOrContainer(ContainerType containerType, String portletNumber, boolean portletInContainer) {
        String deletePortlet = ELEMENT_EDIT_PAGE_DELETE_ICON.replace("${portletNumber}", portletNumber);
        String portlet = ELEMENT_EDIT_PAGE_COMPONENT.replace("${portletNumber}", portletNumber);

        if (portletInContainer) {
            portlet = portlet.concat("/div/div/div/div");
        }

        waitForAndGetElement(ELEMENT_EDIT_PAGE_OR_LAYOUT);

        try {
            if (ieFlag) {
                actions.moveToElement(getElement(portlet));
            } else {
                mouseOver(portlet, false);
            }
            mouseOverAndClick(deletePortlet);
        } catch (StaleElementReferenceException e) {
            checkCycling(e, 5);
            deleteSpecifiedPortletOrContainer(containerType, portletNumber, portletInContainer);
        } finally {
            loopCount = 0;
        }
        pause(500);
        verifyDelete(containerType, portletNumber, portletInContainer);
    }

    private static void verifyDelete(ContainerType containerType, String portletNumber, boolean portletInContainer) {
        String text = null;
        boolean needToBeVerified = true;
        switch (containerType) {
            case PORTLET:
                text = "Are you sure you want to delete this portlet?";
                break;
            case CONTAINER:
                text = "Are you sure you want to delete this Container?";
                break;
            default:
                break;
        }
        while (ieFlag && !getTextFromAlert().equals(text)) {
            if (second >= timeoutSecInt) {
                Assert.fail("Timeout at deleteSpecifiedPortletOrContainer");
            }
            second++;
            pause(500);
            verifyDelete(containerType, portletNumber, portletInContainer);
            needToBeVerified = false;
            break;
        }
        if (needToBeVerified) {
            waitForConfirmation(text);
            second = 0;
        }
    }
}
