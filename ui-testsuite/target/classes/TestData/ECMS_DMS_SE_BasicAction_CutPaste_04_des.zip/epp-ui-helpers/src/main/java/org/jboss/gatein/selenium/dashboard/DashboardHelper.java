package org.jboss.gatein.selenium.dashboard;

import java.util.Map;
import static org.jboss.gatein.selenium.common.CommonHelper.*;
import static org.jboss.gatein.selenium.page.PageHelper.*;

import org.jboss.gatein.selenium.AbstractContextual;
import org.testng.Assert;

public class DashboardHelper extends AbstractContextual {
	
	public static final String ELEMENT_DASHBOARD_UNSELECTED_PAGE_WITH_SPECIFIED_NAME = "//div[@id='UITabPaneDashboard']//a[text()='${dashboardName}']";
	public static final String ELEMENT_DASHBOARD_SELECTED_PAGE_WITH_SPECIFIED_NAME = "//div[@id='UITabPaneDashboard']//span[text()='${dashboardName}']";
	public static final String ELEMENT_DASHBOARD_SELECTED_DELETE = "//div[contains(@class, 'SelectedTab')]//a[@class='CloseIcon']";
	public static final String ELEMENT_DASHBOARD_SELECTED = "//div[contains(@class, 'SelectedTab')]//span";
	public static final String ELEMENT_DASHBOARD_NEW_ICON = "//div[@id='UITabPaneDashboard']/a[@class='AddDashboard']";
	public static final String ELEMENT_DASHBOARD_NEW_INPUT = "//div[@id='UITabPaneDashboard']//div[contains(@class, 'UITab SelectedTab')]/input";
	
	public static final String ELEMENT_ADD_GADGETS_LINK = "//div[@class='AddIcon']//a[text()='Add Gadgets']";
	public static final String ELEMENT_ADD_GADGET_ADD_ICON = "//img[@class='AddNewNodeIcon']";
	public static final String ELEMENT_ADD_GADGETS_CLOSE_BUTTON = "//div[contains(@id, 'UIAddGadgetPopup')]/div//a";
	public static final String ELEMENT_ADD_GADGETS_GADGET = "//div[@class='GadgetControl']/div[@title='${title}']/..";
	
	public static final String ELEMENT_GADGET_TITLE = "//span[text()='${title}']";
	public static final String ELEMENT_GADGET_DELETE_ICON = ELEMENT_GADGET_TITLE + "/..//span[@title='Delete Gadget']";

	public static void addNewPageOnDashboardWithEditor(String name, String displayName, boolean extendedLabelMode, Map<String, String> labels) {
        
		String dashboard = ELEMENT_DASHBOARD_SELECTED_PAGE_WITH_SPECIFIED_NAME.replace("${dashboardName}", displayName);
		
		System.out.println("--Add new page on dashboard with editor--");
		goToAddNewPage();
        
        type(ELEMENT_INPUT_PAGE_NAME, name, true);
        
		if (extendedLabelMode) {
            Assert.assertTrue(isSelected(ELEMENT_CHECKBOX_EXTENDED_LABEL_MODE));
            
            for (String language : labels.keySet()) {
                select(ELEMENT_SELECT_LANGUAGE, language);
                type(ELEMENT_INPUT_LOCALIZED_LABEL, labels.get(language), true);
            }
        } else {
            uncheck(ELEMENT_CHECKBOX_EXTENDED_LABEL_MODE);
            type(ELEMENT_INPUT_PAGE_DISPLAY_NAME, displayName, true);
        }
		System.out.println("--Click Next to move to step 2");
		click(ELEMENT_PAGE_EDITOR_NEXT_STEP);
		System.out.println("--Click Next to move to step 3, keep Empty layout");
		waitForTextPresent("Select a Page Layout Template");
		click(ELEMENT_PAGE_EDITOR_NEXT_STEP);
		System.out.println("--Click Save to complete adding page");
		finishPageEdit();
		waitForAndGetElement(dashboard);
	}
	
	public static void deleteSelectedPage(String displayName) {
		String dashboard = ELEMENT_DASHBOARD_SELECTED_PAGE_WITH_SPECIFIED_NAME.replace("${dashboardName}", displayName);
		
		System.out.println("--Delete selected page on dashboard--");
		click(ELEMENT_DASHBOARD_SELECTED_DELETE);
		waitForConfirmation("Really want to remove this dashboard?");
		waitForElementNotPresent(dashboard);
	}
	
	public static void addNewPageOnDashboard(String displayName, boolean verify) {
		System.out.println("--Add new page on dashboard--");
		click(ELEMENT_DASHBOARD_NEW_ICON);
        typeAndConfirm(ELEMENT_DASHBOARD_NEW_INPUT, displayName);
		if (verify) {
			waitForAndGetElement("//span[text()='" + displayName + "']");
		}
	}
	
	public static void editPageNameOnDashboard(String displayName, String newName) {
		String dashboard = ELEMENT_DASHBOARD_SELECTED_PAGE_WITH_SPECIFIED_NAME.replace("${dashboardName}", displayName);
		
		System.out.println("--Edit name of page on dashboard--");
		click(dashboard);
		doubleClickOnElement(ELEMENT_DASHBOARD_SELECTED);
        typeAndConfirm(ELEMENT_DASHBOARD_NEW_INPUT, newName);
		waitForAndGetElement("//span[text()='" + newName + "']");
		waitForElementNotPresent("//span[text()='" + displayName + "']");
	}

}
