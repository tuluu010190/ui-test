package org.jboss.gatein.selenium.portal;

import static org.jboss.gatein.selenium.common.CommonHelper.*;
import static org.jboss.gatein.selenium.permission.PermissionHelper.*;
import static org.jboss.gatein.selenium.page.PageHelper.*;

import java.util.Map;

import org.jboss.gatein.selenium.AbstractContextual;
import org.openqa.selenium.WebElement;

public class PortalHelper extends AbstractContextual {
	
	public static final String ELEMENT_ADD_NEW_PORTAL_LINK = "//a[text()='Add New Portal']";
	
	public static final String ELEMENT_SELECT_SESSION_ALIVE = "//select[@name='sessionAlive']";
	
	public static final String ELEMENT_CHECKBOX_SHOW_INFO_BAR_BY_DEFAULT = "//input[@name='showInfobar']";
	
	public static final String ELEMENT_PORTAL_IN_LIST = "//td[@class='Content']/div[@class='Label' and text()='${portalName}']";
	public static final String ELEMENT_PORTAL_DELETE_ICON = "//td[@class='Content']/div[@class='Label' and text()='${portalName}']/../../td[3]/a[@class='DeleteIcon']";
	public static final String ELEMENT_PORTAL_EDIT_ICON = "//td[@class='Content']/div[@class='Label' and text()='${portalName}']/../../td[3]/a[@class='EditNavIcon'][2]";
	
	public static final String ELEMENT_EDIT_FIRST_PORTAL_CONFIG = "//div[@id='UISiteManagement']//a[@class='EditNavIcon'][2]";
	
	public static final String ELEMENT_SWITCH_VIEW_MODE_PORTAL = "//a[text()='Switch View Mode']";
	
	public static void createNewPortal(String portalName, String portalLocale, String portalSkin, String portalSession, 
            boolean publicMode, Map<String, String> permissions, String editGroupId, String editMembership) {
        
		System.out.println("--Creating new portal--");

        pause(500);
        if (isTextPresent("Application Registry")) {
            goToEditLayout();
            deleteSpecifiedPortletOrContainer(ContainerType.PORTLET, "2", false);
            finishPageEdit();
        }
        
		click(ELEMENT_ADD_NEW_PORTAL_LINK);
		waitForTextPresent("Portal Setting");
		type(ELEMENT_INPUT_NAME, portalName, true);
		select(ELEMENT_SELECT_LOCALE, portalLocale);
		select(ELEMENT_SELECT_SKIN, portalSkin);
		click(ELEMENT_PROPERTIES_TAB);
		select(ELEMENT_SELECT_SESSION_ALIVE, portalSession);
		click(ELEMENT_PERMISSION_SETTING_TAB);
		if (publicMode) {
            waitForAndGetElement("//a[text()='Add Permission']");
			check(ELEMENT_CHECKBOX_PUBLIC_MODE);
			waitForElementNotPresent("//a[text()='Add Permission']");
		} else {
			for (String key : permissions.keySet()) {
				setViewPermissions(key, permissions.get(key));
			}
		}
		click(ELEMENT_LINK_EDIT_PERMISSION);
		setEditPermissions(editGroupId, editMembership);
		save();
	}
	
	public static void verifyPortalExists(String portalName) {
		String portal = ELEMENT_PORTAL_IN_LIST.replace("${portalName}", portalName);
		
		System.out.println("--Verify portal (" + portalName + ") exist--");
		waitForAndGetElement(portal);
        goToGroup();
		goToSite();
		waitForAndGetElement(portal);
	}
	
	public static void deletePortal(String portalName) {
		String portal = ELEMENT_PORTAL_IN_LIST.replace("${portalName}", portalName);
		String portalDelete = ELEMENT_PORTAL_DELETE_ICON.replace("${portalName}", portalName);
		
		System.out.println("--Delete portal (" + portalName + ")--");
		goToSite();
		waitForAndGetElement(portal);
		click(portalDelete);
		waitForConfirmation("Are you sure you want to delete this portal?");
		System.out.println("--Verify portal deleted--");
		waitForElementNotPresent(portal);
		waitForTextNotPresent(portalName);
	}
	
	public static void setShowInfoBarByDefault(String portalName, boolean showInfoBar) {
		String portalEdit = ELEMENT_PORTAL_EDIT_ICON.replace("${portalName}", portalName);
		
		goToSite();
		waitForAndGetElement(portalEdit);
		click(portalEdit);
		waitForTextPresent("Portal Setting");
		click(ELEMENT_PROPERTIES_TAB);
		WebElement checkbox = waitForAndGetElement(ELEMENT_CHECKBOX_SHOW_INFO_BAR_BY_DEFAULT);
		if (showInfoBar) {
			if (!checkbox.isSelected()) {
				check(ELEMENT_CHECKBOX_SHOW_INFO_BAR_BY_DEFAULT);
			}
		} else {
			if (checkbox.isSelected()) {
				uncheck(ELEMENT_CHECKBOX_SHOW_INFO_BAR_BY_DEFAULT);
			}
		}
		save();
	}
}
