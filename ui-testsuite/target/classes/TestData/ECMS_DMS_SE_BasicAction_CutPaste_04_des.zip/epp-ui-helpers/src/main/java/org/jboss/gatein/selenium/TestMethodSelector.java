package org.jboss.gatein.selenium;

import java.lang.reflect.Constructor;
import java.lang.reflect.Method;

import org.apache.commons.lang.StringUtils;
import org.testng.IAnnotationTransformer;
import org.testng.annotations.ITestAnnotation;

public class TestMethodSelector implements IAnnotationTransformer {

    /**
     * Disables the test methods which doesn't match the given method name.
     */
    @SuppressWarnings("unchecked")
    public void transform(ITestAnnotation annotation, Class testClass, Constructor testConstructor, Method testMethod) {
        String[] selectedMethods = System.getProperty("method", "*").split(",");
        String[] excludedMethods = System.getProperty("exclude", "-").split(",");

        String methodName = testMethod.getDeclaringClass().getCanonicalName()+ "." + testMethod.getName();
        boolean match = false;

        for (String selectedMethod : selectedMethods) {

            selectedMethod = StringUtils.replace(selectedMethod, "*", ".*");

            if (methodName.matches(selectedMethod)) {
                match = true;
                break;
            }
        }
        
        for (String excludedMethod : excludedMethods) {

            excludedMethod = StringUtils.replace(excludedMethod, "*", ".*");

            if (methodName.matches(excludedMethod)) {
                match = false;
                break;
            }
        }

        annotation.setEnabled(match);

    }
}
