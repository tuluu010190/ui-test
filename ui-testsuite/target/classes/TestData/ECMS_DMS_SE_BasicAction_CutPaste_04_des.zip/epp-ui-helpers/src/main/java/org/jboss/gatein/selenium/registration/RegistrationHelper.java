package org.jboss.gatein.selenium.registration;

import static org.jboss.gatein.selenium.common.CommonHelper.*;
import static org.jboss.gatein.selenium.page.PageHelper.*;

import org.jboss.gatein.selenium.AbstractContextual;

public class RegistrationHelper extends AbstractContextual {
	
	public static final String ELEMENT_CHECKBOX_USE_CAPTCHA = "//input[@name='useCaptcha']";
	public static final String ELEMENT_INPUT_CAPTCHA = "//div[@id='captcha']";
	
	public static void setCaptchaInEditPage(boolean useCaptcha) {
		
		System.out.println("--Setting using captcha to " + useCaptcha + "--");
        
		goToEditPage();
		editSpecifiedPortletOrContainer("1", false, ELEMENT_CHECKBOX_USE_CAPTCHA);
		if (useCaptcha) {
			if (!isSelected(ELEMENT_CHECKBOX_USE_CAPTCHA)) {
				check(ELEMENT_CHECKBOX_USE_CAPTCHA);
			}
		} else {
			if (isSelected(ELEMENT_CHECKBOX_USE_CAPTCHA)) {
				uncheck(ELEMENT_CHECKBOX_USE_CAPTCHA);
			}
		}
		save();
		close();
		finishPageEdit();
		click("//a[text()='Register']");
	}
}
