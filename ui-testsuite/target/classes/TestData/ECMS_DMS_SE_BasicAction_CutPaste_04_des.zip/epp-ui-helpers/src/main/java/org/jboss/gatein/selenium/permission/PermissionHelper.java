package org.jboss.gatein.selenium.permission;

import static org.jboss.gatein.selenium.common.CommonHelper.*;

import org.jboss.gatein.selenium.AbstractContextual;

public class PermissionHelper extends AbstractContextual {
	
	public static final String ELEMENT_PERMISSION_SETTING_TAB = "//div[text()='Permission Setting' and @class='MiddleTab']";
	public static final String ELEMENT_ACCESS_PERMISSION_TAB = "//div[text()='Access Permission' and @class='MiddleTab']";
	public static final String ELEMENT_ADD_PERMISSION_BUTTON = "//a[text()='Add Permission']";
	public static final String ELEMENT_SELECT_PERMISSION_BUTTON = "//a[text()='Select Permission']";
	public static final String ELEMENT_CHECKBOX_PUBLIC_MODE = "//input[@name='publicMode']";
	public static final String ELEMENT_LINK_ACCESS_PERMISSION = "//a[text()='Access Permission Setting']";
	public static final String ELEMENT_LINK_EDIT_PERMISSION = "//a[text()='Edit Permission Setting']";
	public static final String ELELENT_LINK_DELETE_PERMISSION = "//a[text()='Delete Permission']";
	
	public static final String ELEMENT_SELECT_ACCESS_GROUP_ITEM = "//a[@title='${group}']";
	public static final String ELEMENT_SELECT_ACCESS_MEMBERSHIP_ITEM = "//a[text()='${membership}']";
	
	public static final String ELEMENT_SELECT_EDIT_GROUP_ITEM = "//div[@id='UIPermissionSelector']//a[text()='${group}']";
	public static final String ELEMENT_SELECT_EDIT_MEMBERSHIP_ITEM = "//div[@id='UIPermissionSelector']//a[text()='${membership}']";
	
	public static final String ELEMENT_SELECTED_ACCESS_PERM_GROUP = "//div[@id='PermissionGrid']/table/tbody//div[text()='/${groupId}']";
	public static final String ELEMENT_SELECTED_ACCESS_PERM_MEMBERSHIP = "//div[@id='PermissionGrid']/table/tbody//div[text()='${membership}']";
	
	public static final String ELEMENT_SELECTED_EDIT_PERM_GROUP = "//div[@class='SelectedPermissionInfo']/div[2]/div[.='/${groupId}']";
	public static final String ELEMENT_SELECTED_EDIT_PERM_MEMBERSHIP = "//div[@class='SelectedPermissionInfo']/div[3]/div[.='${membership}']";
	
	public static void setViewPermissions(String groupId, String membership) {
		String membershipToSelect = ELEMENT_SELECT_ACCESS_MEMBERSHIP_ITEM.replace("${membership}", membership);
		String selectedGroup = ELEMENT_SELECTED_ACCESS_PERM_GROUP.replace("${groupId}", groupId.replace(" ", "-").toLowerCase());
		String selectedMembership = ELEMENT_SELECTED_ACCESS_PERM_MEMBERSHIP.replace("${membership}", membership);
		
		System.out.println("--Setting view permission to " + groupId + ", " + membership + "--");
		String[] groups = groupId.split("/");
        pause(500);
		click(ELEMENT_ADD_PERMISSION_BUTTON);
		waitForTextPresent("Browse and select a group");
		for (String group : groups) {
			String groupToSelect = ELEMENT_SELECT_ACCESS_GROUP_ITEM.replace("${group}", group);
			click(groupToSelect);
		}
        pause(500);
		click(membershipToSelect);
        pause(500);
		waitForTextNotPresent("Permission Selector");
		waitForAndGetElement(selectedGroup);
		waitForAndGetElement(selectedMembership);
	}
	
	public static void setEditPermissions(String groupId, String membership) {
		String membershipToSelect = ELEMENT_SELECT_EDIT_MEMBERSHIP_ITEM.replace("${membership}", membership);
		String selectedGroup = ELEMENT_SELECTED_EDIT_PERM_GROUP.replace("${groupId}", groupId.replace(" ", "-").toLowerCase());
		String selectedMembership = ELEMENT_SELECTED_EDIT_PERM_MEMBERSHIP.replace("${membership}", membership);
		
		System.out.println("--Setting edit permission to " + groupId + ", " + membership + "--");
		String[] groups = groupId.split("/");
		click(ELEMENT_SELECT_PERMISSION_BUTTON);
        pause(500);
		waitForTextPresent("Permission Selector");
		for (String group : groups) {
			String groupToSelect = ELEMENT_SELECT_EDIT_GROUP_ITEM.replace("${group}", group);
			click(groupToSelect);
		}
		click(membershipToSelect);
		waitForTextNotPresent("Permission Selector");
		waitForAndGetElement(selectedGroup);
		waitForAndGetElement(selectedMembership);
	}
}
