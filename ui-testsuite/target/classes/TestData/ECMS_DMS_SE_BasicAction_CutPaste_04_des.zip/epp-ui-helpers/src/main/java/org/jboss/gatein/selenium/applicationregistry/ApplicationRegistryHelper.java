package org.jboss.gatein.selenium.applicationregistry;

import static org.jboss.gatein.selenium.common.CommonHelper.*;
import static org.jboss.gatein.selenium.permission.PermissionHelper.*;

import java.util.Map;

import org.jboss.gatein.selenium.AbstractContextual;

public class ApplicationRegistryHelper extends AbstractContextual {
	public static final String ELEMENT_IMPORT_ICON = "//div[@class='IconControl ImportIcon']";
	public static final String ELEMENT_CHECKBOX_SHOW_IMPORT_EDIT_MODE = "//input[@name='showImport']";
	
	public static final String ELEMENT_CATEGORY_ADD_ICON = "//div[@class='IconControl AddCategoryIcon']";
	public static final String ELEMENT_CATEGORY_MENU = "//div[@id='UIApplicationOrganizer']//a[@title='${categoryTitle}']";
    public static final String ELEMENT_CATEGORY_DELETE_ICON = ELEMENT_CATEGORY_MENU + "/../a[@class='ControlIcon DeleteIcon']";
    public static final String ELEMENT_CATEGORY_EDIT_ICON = ELEMENT_CATEGORY_MENU + "/../a[@class='ControlIcon EditIcon']";
	public static final String ELEMENT_CATEGORY_ADD_APPLICATION_ICON = "//a[@class='ControlIcon CreateNewIcon' and @title='Add application to category']";
	public static final String ELEMENT_CATEGORY_ADD_APPLICATION_APP_IN_TABLE = "//table[@class='UIGrid']//tr/td[2]/span[text()='${appName}']";
	public static final String ELEMENT_CATEGORY_ADD_APPLICATION_APP_IN_TABLE_CHECKBOX = ELEMENT_CATEGORY_ADD_APPLICATION_APP_IN_TABLE + "/../../td[1]/input";
	public static final String ELEMENT_CATEGORY = "//a[@title='${categoryName}']";

    public static final String ELEMENT_APPLICATION_IN_CATEGORY = "//a[@title='${applicationName}']";
	public static final String ELEMENT_APPLICATION_DELETE_SELECTED_ICON = "//div[contains (@class, 'ItemContent SelectedItem')]//a[@title='Delete application']";
	public static final String ELEMENT_APPLICATION_ADD_IN_CATEGORY_LINK = "//a[contains(text(), 'Click here to add into categories')]";
	
	public static final String ELEMENT_GADGET_IN_CATEGORY = "//a[contains(@class, 'TabLabel') and @title='${gadgetName}']";
	public static final String ELEMENT_REMOVE_GADGET_LINK = "//div[@id='UIGadgetManagement']/div[2]//a[text()='${gadgetName}']/../a[2]";
	public static final String ELEMENT_GADGET_ADD_ICON = "//div[@class='IconControl AddNewIcon' and text()='Add a remote gadget']";
	public static final String ELEMENT_GADGET_CREATE_ICON = "//div[@class='IconControl CreateNewIcon' and text()='Create a new gadget']";
	public static final String ELEMENT_GADGETS_CATEGORY = "//input[@name='category_Gadgets']";
	
	public static final String ELEMENT_GADGETS_TAB_LINK = "//a[contains(@class, 'GadgetIcon')]";
	public static final String ELEMENT_PORTLETS_TAB_LINK = "//a[@class='ItemButton ItemButton PorletIcon']";
	public static final String ELEMENT_CATEGORIES_TAB_LINK = "//a[@class='ItemButton ItemButton OrganizeIcon']";
	
	public static final String ELEMENT_REMOTE_PORTLET_TAB = "//div[@class='TitleCategory' and contains(text(), 'REMOTE')]";
	
	public static final String URL_GADGET_DATETIME = "http://www.gstatic.com/ig/modules/datetime_v3/datetime_v3.xml";
	
	public static enum PortletType {
		PORTLET, GADGET, WSRP;
	}
	
	public static void addNewCategory(String categoryName, String categoryLabel, String categoryDesc, boolean publicMode, 
            Map<String, String> permissions, boolean verify) {
		System.out.println("--Adding new category");
		click(ELEMENT_CATEGORY_ADD_ICON);
		type(ELEMENT_INPUT_NAME, categoryName, true);
		type(ELEMENT_INPUT_DISPLAY_NAME, categoryLabel, true);
		type(ELEMENT_TEXTAREA_DESCRIPTION, categoryDesc, true);
        click(ELEMENT_PERMISSION_SETTING_TAB);
		if (publicMode) {
            pause(500);
			check(ELEMENT_CHECKBOX_PUBLIC_MODE);
			waitForElementNotPresent(ELEMENT_ADD_PERMISSION_BUTTON);
		} else {
			for (String key : permissions.keySet()) {
                pause(500);
				setViewPermissions(key, permissions.get(key));
			}
		}
		save();
		if (verify) {
            waitForAndGetElement("//a[@title='" + categoryLabel + "']");
			waitForTextPresent("This category does not have any application, click (+) button to add application.");
		}
	}
	
	public static void editCategory(String categoryTitle, String newLabel, String newDesc) {
		String editCategoryLink = ELEMENT_CATEGORY_EDIT_ICON.replace("${categoryTitle}", categoryTitle);
		
		System.out.println("--Editting category--");
		click(editCategoryLink);
		type(ELEMENT_INPUT_DISPLAY_NAME, newLabel, true);
		type(ELEMENT_TEXTAREA_DESCRIPTION, newDesc, true);
		save();
		waitForAndGetElement("//a[@title='" + newLabel + "']");
	}
	
	public static void deleteCategory(String categoryTitle) {
		String categoryTabMenu = ELEMENT_CATEGORY_MENU.replace("${categoryTitle}", categoryTitle);
		String categoryDeleteIcon = ELEMENT_CATEGORY_DELETE_ICON.replace("${categoryTitle}", categoryTitle);
		
		System.out.println("--Deleting Category--");
        pause(300);
		click(categoryTabMenu);
		click(categoryDeleteIcon);
		waitForConfirmation("Are you sure to delete this category and all applications on it?");
		waitForElementNotPresent(categoryTabMenu);
	}
	
	public static void addApplicationToCategory(String categoryName, PortletType portletType, String applicationName, String displayName) {
		String applicationInTable = ELEMENT_CATEGORY_ADD_APPLICATION_APP_IN_TABLE.replace("${appName}", applicationName);
		String applicationInTableCheckbox = ELEMENT_CATEGORY_ADD_APPLICATION_APP_IN_TABLE_CHECKBOX.replace("${appName}", applicationName);
		
		System.out.println("--Add application to category " + categoryName);
		click(ELEMENT_CATEGORY_ADD_APPLICATION_ICON);
		if (portletType != null) {
			switch (portletType) {
			case GADGET:
				select(ELEMENT_SELECT_TYPE, "Gadget");
				break;
			case WSRP:
				select(ELEMENT_SELECT_TYPE, "wsrp");
				break;
			case PORTLET:
				select(ELEMENT_SELECT_TYPE, "Portlet");
                break;
			default:
				break;
			}
		}
        pause(500);
		type(ELEMENT_INPUT_DISPLAY_NAME, displayName, true);
		System.out.println("--Select application in list--");
        if (isTextPresent("Total pages")) {
            usePaginator(applicationInTable, "Portlet not found in list");
        }
		click(applicationInTableCheckbox);
		click(ELEMENT_ADD_BUTTON);
		waitForElementNotPresent(ELEMENT_ADD_BUTTON);
	}
	
	public static void deleteApplicationFromCategory(String category, String applicationName) {
		String applicationLink = ELEMENT_APPLICATION_IN_CATEGORY.replace("${applicationName}", applicationName);
		
		System.out.println("--Delete application from category--");
		selectApplicationInCategory(category, applicationName);

        pause(500);
		click(ELEMENT_APPLICATION_DELETE_SELECTED_ICON);
		waitForConfirmation("Are you sure to delete this application?");
		waitForElementNotPresent(applicationLink);
	}
	
	public static void autoImportApplications() {
		System.out.println("--Click Import Application--");

        click(ELEMENT_IMPORT_ICON);
		waitForConfirmation("This action will automatically create categories and import all the gadgets and portlets on it.");
		waitForTextPresent("System");
	}
	
	public static void selectApplicationInCategory(String categoryTitle, String applicationName) {
		String categoryTabMenu = ELEMENT_CATEGORY_MENU.replace("${categoryTitle}", categoryTitle);
		String applicationLink = ELEMENT_APPLICATION_IN_CATEGORY.replace("${applicationName}", applicationName);

		click(categoryTabMenu);
        pause(500);
		click(applicationLink);
	}
	
	public static void deleteGadget(String gadgetTitle) {
		String removeGadgetLink = ELEMENT_REMOVE_GADGET_LINK.replace("${gadgetName}", gadgetTitle);
		
		System.out.println("--Deleting gadget--");
        
        pause(500);
		click(removeGadgetLink);
		waitForConfirmation("Are you sure to delete this gadget?");
		waitForElementNotPresent(removeGadgetLink);
	}
	
	public static void addRemoteGadget(String gadgetUrl, boolean verify) {
		System.out.println("--Adding a remote gadget--");
		click(ELEMENT_GADGET_ADD_ICON);
		type(ELEMENT_INPUT_URL, gadgetUrl, true);
		click(ELEMENT_ADD_BUTTON);
		if (verify) {
            waitForTextPresent("Gadget Details");
        }
	}
	
	public static void addNewGadgetToCategory(String gadgetTitle) {
		String gadgetLink = ELEMENT_GADGET_IN_CATEGORY.replace("${gadgetName}", gadgetTitle);
		
		System.out.println("--Adding a new gadget to category--");
		click(gadgetLink);
		pause(500);
        click(ELEMENT_APPLICATION_ADD_IN_CATEGORY_LINK);
		check(ELEMENT_GADGETS_CATEGORY);
		save();
	}
	
	public static void addNewGadget(String gadgetName, String code, boolean verify) {
		System.out.println("--Add a new gadget in App. registry--");
		click(ELEMENT_GADGET_CREATE_ICON);
		type(ELEMENT_INPUT_NAME, gadgetName, true);
		if (code != null) {
			type(ELEMENT_INPUT_SOURCE, code, true);
		}
		save();
		if (verify) {
            waitForTextPresent("Gadget Details");
        }
	}
}
