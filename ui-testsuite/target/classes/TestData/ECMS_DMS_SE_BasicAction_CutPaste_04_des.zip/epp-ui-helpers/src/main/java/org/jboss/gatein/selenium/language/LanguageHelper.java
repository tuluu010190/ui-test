package org.jboss.gatein.selenium.language;

import static org.jboss.gatein.selenium.common.CommonHelper.*;
import static org.jboss.gatein.selenium.AbstractTestCase.*;

import org.jboss.gatein.selenium.AbstractContextual;

public class LanguageHelper extends AbstractContextual {
	
	public static final String HOME_LABEL_FRENCH = getMessage("language.home.label.french");
	public static final String HOME_LABEL_ENGLISH = getMessage("language.home.label.english");
	public static final String HOME_LABEL_VIETNAMESE = getMessage("language.home.label.vietnamese");
	public static final String HOME_LABEL_GERMAN = getMessage("language.home.label.german");
	public static final String HOME_LABEL_RUSSIAN = getMessage("language.home.label.russian");
	public static final String HOME_LABEL_SPANISH = getMessage("language.home.label.spanish");
    
    public static final String LANGUAGE_ARABIC = getMessage("language.arabic");
    public static final String LANGUAGE_CZECH = getMessage("language.czech");
    public static final String LANGUAGE_DUTCH = getMessage("language.dutch");
    public static final String LANGUAGE_ENGLISH = getMessage("language.english");
    public static final String LANGUAGE_FRENCH = getMessage("language.french");
    public static final String LANGUAGE_GERMAN = getMessage("language.german");
    public static final String LANGUAGE_ITALIAN = getMessage("language.italian");
    public static final String LANGUAGE_JAPANESE = getMessage("language.japanese");
    public static final String LANGUAGE_KOREAN = getMessage("language.korean");
    public static final String LANGUAGE_NEPALI = getMessage("language.nepali");
    public static final String LANGUAGE_PORTUGUESE_BRAZIL = getMessage("language.portuguese-brazil");
    public static final String LANGUAGE_RUSSIAN = getMessage("language.russian");
    public static final String LANGUAGE_SIMPLIFIED_CHINESE = getMessage("language.simplified-chinese");
    public static final String LANGUAGE_SPANISH = getMessage("language.spanish");
    public static final String LANGUAGE_TRADITIONAL_CHINESE = getMessage("language.traditional-chinese");
    public static final String LANGUAGE_UKRANIAN = getMessage("language.ukrainian");
    public static final String LANGUAGE_VIETNAMESE = getMessage("language.vietnamese");
    
    public static final String CHANGE_LANGUAGE_ARABIC = getMessage("language.changelanguage.arabic");
    public static final String CHANGE_LANGUAGE_CZECH = getMessage("language.changelanguage.czech");
    public static final String CHANGE_LANGUAGE_DUTCH = getMessage("language.changelanguage.dutch");
    public static final String CHANGE_LANGUAGE_ENGLISH = getMessage("language.changelanguage.english");
    public static final String CHANGE_LANGUAGE_FRENCH = getMessage("language.changelanguage.french");
    public static final String CHANGE_LANGUAGE_GERMAN = getMessage("language.changelanguage.german");
    public static final String CHANGE_LANGUAGE_ITALIAN = getMessage("language.changelanguage.italian");
    public static final String CHANGE_LANGUAGE_JAPANESE = getMessage("language.changelanguage.japanese");
    public static final String CHANGE_LANGUAGE_KOREAN = getMessage("language.changelanguage.korean");
    public static final String CHANGE_LANGUAGE_NEPALI = getMessage("language.changelanguage.nepali");
    public static final String CHANGE_LANGUAGE_PORTUGUESE_BRAZIL = getMessage("language.changelanguage.portuguese-brazil");
    public static final String CHANGE_LANGUAGE_RUSSIAN = getMessage("language.changelanguage.russian");
    public static final String CHANGE_LANGUAGE_SIMPLIFIED_CHINESE = getMessage("language.changelanguage.simplified-chinese");
    public static final String CHANGE_LANGUAGE_SPANISH = getMessage("language.changelanguage.spanish");
    public static final String CHANGE_LANGUAGE_TRADITIONAL_CHINESE = getMessage("language.changelanguage.traditional-chinese");
    public static final String CHANGE_LANGUAGE_UKRANIAN = getMessage("language.changelanguage.ukrainian");
    public static final String CHANGE_LANGUAGE_VIETNAMESE = getMessage("language.changelanguage.vietnamese");
    
    public static final String LANGUAGE = "//div[text()='${language}']";
    
    public static final String APPLY_BUTTON = "//div[@id='UITabContent']/../../div[2]/a";
    
    public static enum LanguageAbbreviation {
        ar, cs, nl, en, fr, de, it, ja, ko, ne, pt_BR, ru, zh_CN, es, zh_TW, uk, vi
    }
    
	public static void changeLanguage(String newLanguage) { 
        String newLanguageLink = LANGUAGE.replace("${language}", newLanguage);
		
		System.out.println("--Change language to " + newLanguage + "--");
        
        pause(1000);
        //if user is NOT signed in
        if (isElementPresent(ELEMENT_LINK_CHANGE_LANGUAGE)) {
            pause(500);
            click(ELEMENT_LINK_CHANGE_LANGUAGE);
        } else {
            pause(500);
            goToPage(APPLY_BUTTON, ELEMENT_LINK_PORTAL_TOP_CONTAINER, ELEMENT_LINK_CHANGE_LANGUAGE_SIGNED_IN);
        }
        click(newLanguageLink);
        pause(500);
        click(APPLY_BUTTON);
        waitForElementNotPresent(APPLY_BUTTON);
	}
    
    public static void openPortalInLanguage(LanguageAbbreviation abb) {
        String location;
        if (abb.toString().contains("_")) {
            location = getPortalUrl().concat("/").concat(abb.toString().replace("_", "-")).concat("/classic");
        } else {
            location = getPortalUrl().concat("/").concat(abb.toString()).concat("/classic");
        }
		open(location);
    }
}
