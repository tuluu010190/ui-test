package org.jboss.gatein.selenium;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

import org.testng.ITestResult;
import org.testng.TestListenerAdapter;

import java.io.File;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;

/**
 * The listener interface for receiving AbstractTestCase events.
 * The class that is interested in processing a AbstractTestCase
 * event implements this interface, and the object created
 * with that class is registered with a component using the
 * component's <code>addTestCaseFailListener<code> method. When
 * the AbstractTestCase event occurs, that object's appropriate
 * method is invoked. <br/>
 * TestCaseFailListener is responsible for decoding most of the parameters which are passed to selenium tests.
 * <table>
 * <thead>
 * <tr>
 * <th>parameter name</th>
 * <th>valid values</th>
 * <th>default value</th>
 * <th>description</th>
 * </tr> 
 * </thead>
 * <tr>
 * <td>screenshot</td>
 * <td>true/false</td>
 * <td>false</td>
 * <td>If true, screenshots are taken after the test failure. They are saved into directory specified by the "output-dir" parameter.</td>
 * </tr><tr>
 * <td>html-src</td><td>true/false</td><td>false</td><td>If true, html sources are taken after the test failure. They are saved into directory specified by the "output" parameter.</td>
 * </tr><tr>
 * <td>output-dir</td><td>&#60;path-to-dir&#62;</td><td>""</td><td>Path to the directory where html sources and screenshots are saved.</td>
 * </tr>
 * </table> 
 * 
 */
public class TestCaseFailListener extends TestListenerAdapter {

	public static WebDriver webDriver;
	public static String browser;
	protected static int count;
	protected static boolean screenshot = false;
	protected static boolean htmlSource = false;
	protected static String outputDir = "";

	static {
		String ss = System.getProperty("screenshot");
		if ("true".equals(ss)) {
			screenshot = true;
		}

		String sh = System.getProperty("html-src");
		if ("true".equals(sh)) {
			htmlSource = true;
		}
		
		String so = System.getProperty("output-dir");
		if (so != null) {
			outputDir = so;
		}
	}
    
	/* (non-Javadoc)
	 * @see org.testng.TestListenerAdapter#onTestFailure(org.testng.ITestResult)
	 */
	@Override
	public void onTestFailure(ITestResult tr) {

		String name = outputDir +"/"+ "F_" + tr.getName() + "-" + count;

		if (screenshot && !browser.contains("chrome")) {
			try {
				waitFor(1000);
                File temp = ((TakesScreenshot) webDriver).getScreenshotAs(OutputType.FILE);
                FileUtils.copyFile(temp, new File(name + ".png"));
			} catch (WebDriverException e2) {
				e2.printStackTrace();
			} catch (IOException e3) {
                e3.printStackTrace();
            } catch (ClassCastException e4) {
                e4.printStackTrace();
            }
		}
		
		if (htmlSource) {
			try {
				PrintWriter out = new PrintWriter(new BufferedWriter(new FileWriter(name + ".html")));
				out.println(webDriver.getPageSource());
				out.close();
			} catch (IOException e1) {
				e1.printStackTrace();
			}
		}
		count++;
	}
	
	/**
	 * Waits for specified time in ms. Used mostly in AJAX based tests.
	 * 
	 * @param time
	 *            the time (in ms) to be waited for.
	 */
	public void waitFor(long time) {
		try {
			Thread.sleep(time);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
	
	public static void captureScreenshot(String testName) {
		String name = outputDir +"/"+ "F_" + testName;
		if (screenshot) {
			try {
				File temp = ((TakesScreenshot) webDriver).getScreenshotAs(OutputType.FILE);
                FileUtils.copyFile(temp, new File(name + ".png"));
			} catch (WebDriverException e2) {
				e2.printStackTrace();
			} catch (IOException e3) {
                e3.printStackTrace();
            }
		}
	}

}
