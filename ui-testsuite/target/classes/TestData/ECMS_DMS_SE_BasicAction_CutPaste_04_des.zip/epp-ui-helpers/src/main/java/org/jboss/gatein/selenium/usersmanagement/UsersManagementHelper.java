package org.jboss.gatein.selenium.usersmanagement;

import static org.jboss.gatein.selenium.common.CommonHelper.*;

import org.jboss.gatein.selenium.AbstractContextual;
import org.testng.Assert;

public class UsersManagementHelper extends AbstractContextual {
	
	public static final String ELEMENT_USER_EDIT_ICON = "//div[@id='UIListUsersGird']/table//tr/td/div[text()='${username}']/../../td[5]//img[@class='ViewUserInfoIcon']";
	public static final String ELEMENT_USER_DELETE_ICON = "//div[@id='UIListUsersGird']//div[text()='${username}']/../..//img[@class='DeleteUserIcon']";
	public static final String ELEMENT_USER_IN_LIST = "//div[@class='UIUserInGroup']//div[@title='${username}']";
	public static final String ELEMENT_SEARCH_ICON_USERS_MANAGEMENT = "//form[@id='UISearchForm']/div[2]/a";
	public static final String ELEMENT_USER_EDIT_DELETE_MEMBERSHIP_ICON = "//img[@class='DeleteMembershipIcon' and contains(@onclick, 'objectId=${membershipId}')]";
	
	public static final String ELEMENT_USER_PROFILE_TAB = "//div[text()='User Profile' and @class='MiddleTab']";
	public static final String ELEMENT_ACCOUNT_INFO_TAB = "//div[text()='Account Info' and @class='MiddleTab']";
	public static final String ELEMENT_ACCOUNT_SETTING_TAB = "//div[text()='Account Setting' and @class='MiddleTab']";
	public static final String ELEMENT_USER_MEMBERSHIP_TAB = "//div[text()='User Membership' and @class='MiddleTab']";
	
	public static final String ELEMENT_SELECT_USER_LANGUAGE = "//select[@name='user.language']";
	public static final String ELEMENT_SEARCH_ICON_REGISTER = "//img[@class='SearchIcon']";
	public static final String ELEMENT_INPUT_USER_NAME_GIVEN = "//input[@id='user.name.given']";
	public static final String ELEMENT_INPUT_USER_NAME_FAMILY = "//input[@id='user.name.family']";
	public static final String ELEMENT_INPUT_USER_NAME_NICK = "//input[@id='user.name.nickName']";
	
	public static final String ELEMENT_SELECTED_GROUP_INFO = "//a[@class='Selected']";
	public static final String ELEMENT_GROUP_TO_SELECT_LINK = "//a[contains(@class, 'NodeIcon') and @title='${group}']";
	public static final String ELEMENT_GROUP_SELECTED = "//a[@class='NodeIcon PortalIcon NodeSelected' and @title='${group}']";
	public static final String ELEMENT_GROUP_LEVEL_UP_ICON = "//a[@class='LevelUpArrowIcon']";
	public static final String ELEMENT_GROUP_EDIT_SELECTED = "//a[@title='Edit Selected Group']";
	public static final String ELEMENT_GROUP_DELETE_SELECTED = "//a[@title='Delete Selected Group']";
	
	public static final String ELEMENT_CHECKBOX_CHANGE_PASSWORD = "//input[@name='changePassword']";
	public static final String ELEMENT_INPUT_GROUP_NAME = "//input[@name='groupName']";
	public static final String ELEMENT_SELECT_MEMBERSHIP = "//select[@name='membership']";
	
	public static final String ELEMENT_GROUP_ADD_NEW_ICON = "//div[@id='UIOrganizationPortlet']//div[@class='TitleBar']/a[@class='TreeActionIcon AddGroupIcon']";
	public static final String ELEMENT_GROUP_REMOVE_ICON = "//div[@id='UIOrganizationPortlet']//div[@class='TitleBar']/a[@class='TreeActionIcon RemoveGroupIcon']";
	public static final String ELEMENT_GROUP_SEARCH_USER_ICON = "//form[@id='UIGroupMembershipForm']/div[2]/div/table/tbody/tr[1]/td[2]/a";
	public static final String ELEMENT_GROUP_SEARCH_POPUP_INPUT = "//input[@name='Quick Search']";
	public static final String ELEMENT_GROUP_SEARCH_CHECKBOX_ALL_USERS = "//table[@id='UIListUsers']/thead/tr/th/input[@type='checkbox']";
	public static final String ELEMENT_GROUP_SEARCH_POPUP_SEARCH_ICON = "//form[@id='UIUserSelector']/div[2]/div[1]/div/div[1]/div/div/div/div/div/div/a";
	public static final String ELEMENT_GROUP_SEARCH_POPUP_ADD_ICON = "//form[@id='UIUserSelector']//div[@class='UIAction']//a[@class='ActionButton LightBlueStyle']";
	public static final String ELEMENT_GROUP_SEARCH_POPUP_CLOSE_ICON = "//div[@id='SearchUser']//a[@class='CloseButton']";
	public static final String ELEMENT_GROUP_SEARCH_MEMBERSHIP_REFRESH_ICON = "//form[@id='UIGroupMembershipForm']/div[2]/div/table/tbody/tr[2]/td[2]/a";
	public static final String ELEMENT_GROUP_USER_IN_TABLE_EDIT_ICON = "//div[@id='UIGridUser']/table//tr/td/div[text()='${username}']/../../td[4]/div[text()='${membership}']/../../td[6]//img[@class='EditIcon']";
	public static final String ELEMENT_GROUP_USER_IN_TABLE_DELETE_ICON = "//div[@id='UIGridUser']/table//tr/td/div[text()='${username}']/../../td[4]/div[text()='${membership}']/../../td[6]//img[@class='DeleteUserIcon']";
	public static final String ELEMENT_GROUP_USER_IN_TABLE_FIRST = "//div[@id='UIGridUser']/table/tbody/tr[1]/td[1]/div";
	public static final String ELEMENT_GROUP_USER_IN_TABLE = "//div[@class='UIUserInGroup']//div[@title='${username}']";
	
	public static final String ELEMENT_MEMBERSHIP_EDIT_ICON = "//div[@class='UIListMembershipType']//table//tr/td/div[text()='${membership}']/../../td[5]//img[@class='EditMembershipIcon']";
	public static final String ELEMENT_MEMBERSHIP_DELETE_ICON = "//div[@class='UIListMembershipType']//table//tr/td/div[text()='${membership}']/../../td[5]//img[@class='DeleteMembershipIcon']";
	
	public static final String ELEMENT_USER_CHANGE_PASSWORD_LINK = "//a[text()='Change Password']";
	public static final String ELEMENT_INPUT_USER_PROFILE_CURRENT_PASSWORD = "//input[@name='currentpass']";
	public static final String ELEMENT_INPUT_USER_PROFILE_NEW_PASSWORD = "//input[@name='newpass']";
	public static final String ELEMENT_INPUT_USER_PROFILE_CONFIRM_NEW_PASSWORD = "//input[@name='confirmnewpass']";
	public static final String ELEMENT_USER_PROFILE_CHANGE_PASSWORD_SAVE_BUTTON = "//form[@id='UIAccountChangePass']//a[text()='Save']";
	
	public static final String ELEMENT_TAB_GROUP_MANAGEMENT = "//div[@class='GroupManagementIcon']/..";
	public static final String ELEMENT_TAB_USER_MANAGEMENT = "//div[@class='UserManagementIcon']/..";
	public static final String ELEMENT_TAB_MEMBERSHIP_MANAGEMENT = "//div[@class='MembershipManagementIcon']/..";
	
	public static void addNewMembership(String membershipName, String membershipDesc, boolean verify) {
		System.out.println("--Creating new membership--");
		type(ELEMENT_INPUT_NAME, membershipName, true);
		type(ELEMENT_TEXTAREA_DESCRIPTION, membershipDesc, true);
		save();
		if (verify) {
            waitForTextPresent(membershipName);
        }
	}

    public static void editMembership(String membership, String newDesc) {
		String editIcon = ELEMENT_MEMBERSHIP_EDIT_ICON.replace("${membership}", membership);
		String membershipInput = "//input[@value='" + membership + "']";
		
		System.out.println("--Editting membership");
		click(editIcon);
		waitForAndGetElement(membershipInput);
		type(ELEMENT_TEXTAREA_DESCRIPTION, newDesc, true);
		save();
		waitForTextPresent(newDesc);
	}

	public static void deleteMembership(String membership, boolean verify) {
		String editIcon = ELEMENT_MEMBERSHIP_DELETE_ICON.replace("${membership}", membership);
		
		System.out.println("--Deleting membership--");
		click(editIcon);
		waitForConfirmation("Are you sure you want to delete this membership?");
		if (verify) {
            waitForTextNotPresent(membership);
        }
	}

	public static void selectGroup(String groupId) {
		System.out.println("--Select category (" + groupId + ")--");
		String[] groups = groupId.split("/");
		waitForTextPresent("Groups");
		for (String group : groups) {
			String groupToSelect = ELEMENT_GROUP_TO_SELECT_LINK.replace("${group}", group);
			String selectedGroup = ELEMENT_GROUP_SELECTED.replace("${group}", group);
			click(groupToSelect);
			waitForAndGetElement(selectedGroup);
            pause(500);
		}
	}

	public static void addNewGroup(String groupName, String groupLabel, String groupDesc, boolean verify) {
		System.out.println("--Adding new group--");
        pause(500);
		click(ELEMENT_GROUP_ADD_NEW_ICON);
		type(ELEMENT_INPUT_GROUP_NAME, groupName, true);
		type(ELEMENT_INPUT_LABEL, groupLabel, true);
		type(ELEMENT_TEXTAREA_DESCRIPTION, groupDesc, true);
		save();
		if (verify) {
            waitForAndGetElement("//a[@title='" + (groupLabel.length() > 0 ? groupLabel : groupName) + "']");
        }
	}

	public static void addUsersAtGroup(String userNames, String memberShip, boolean select, boolean verify) {

		System.out.println("--Adding users to group--");
		String[] users = userNames.split(",");
		if (select) {
			click(ELEMENT_GROUP_SEARCH_USER_ICON);
			waitForTextPresent("Select User");
			for (String user : users) {
				check("//input[@name='" + user + "']");
			}
			click(ELEMENT_GROUP_SEARCH_POPUP_ADD_ICON);
            pause(500);
            Assert.assertEquals(getValue(ELEMENT_INPUT_USERNAME), userNames);
		} else {
			type(ELEMENT_INPUT_USERNAME, userNames, true);
		}
		select(ELEMENT_SELECT_MEMBERSHIP, memberShip);
		save();
		if (verify) {
			for (String user : users) {
				String addedUser = ELEMENT_GROUP_USER_IN_TABLE.replace("${username}", user);
				if (isTextPresent("Total pages")) {
                    usePaginator(addedUser, "User " + user + "not found in group");
				} else {
					waitForAndGetElement(addedUser);
				}
			}
		}
	}

	public static void deleteUserFromGroup(String userName, String membership, String groupId, boolean verify) {
		String userDeleteIcon = ELEMENT_GROUP_USER_IN_TABLE_DELETE_ICON.replace("${username}", userName).replace("${membership}", membership);
		
		System.out.println("-- Delete user from group: " + userName + "--");
		if (isTextPresent("Total pages")) {
            usePaginator(userDeleteIcon, "User " + userName + "not found in group");
		} 
		click(userDeleteIcon);
		waitForConfirmation("Are you sure you want to delete user " + userName + " from group " + groupId + "?");
		if (verify) {
            waitForElementNotPresent(userDeleteIcon);
        }
	}

	public static void deleteGroup(String groupName, boolean verify) {
		System.out.println("-- Delete group: " + groupName + "--");
		click(ELEMENT_GROUP_REMOVE_ICON);
		waitForConfirmation("Are you sure you want to delete this group?");
		if (verify) {
            waitForElementNotPresent(groupName);
        }
	}
	
	public static void addNewAccountAtNewStaff(String username, String password, String confirmPassword, String firstName, 
            String lastName, String email, String userNameGiven, String language, boolean verify) {
        
		System.out.println("--Create new user using \"New Staff\" portlet--");
		type(ELEMENT_INPUT_USERNAME, username, true);
		type(ELEMENT_INPUT_PASSWORD, password, true);
		type(ELEMENT_INPUT_CONFIRM_PASSWORD, confirmPassword, true);
		type(ELEMENT_INPUT_FIRSTNAME, firstName, true);
		type(ELEMENT_INPUT_LASTNAME, lastName, true);
		type(ELEMENT_INPUT_EMAIL, email, true);
		click(ELEMENT_USER_PROFILE_TAB);
		waitForTextPresent("Given Name:");
		type(ELEMENT_INPUT_USER_NAME_GIVEN, userNameGiven, true);
		select(ELEMENT_SELECT_USER_LANGUAGE, language);
		click(ELEMENT_ACCOUNT_SETTING_TAB);
		save();
		if (verify) {
			waitForMessage("You have registered a new account.");
			closeMessageDialog();
		}
	}

    public static void deleteUser(String username) {
		String userDeleteIcon = ELEMENT_USER_DELETE_ICON.replace("${username}", username);
		
		System.out.println("--Deleting user " + username + "--");
		if (isTextPresent("Total pages")) {
            usePaginator(userDeleteIcon, "User " + username + "not found in group");
		}
        pause(500);
		click(userDeleteIcon);
		waitForConfirmation("Are you sure you want to delete " + username + " user?");
		waitForTextNotPresent(username);
        click(ELEMENT_SEARCH_ICON_USERS_MANAGEMENT);
	}

	public static void verifyUserInGroup(String username) {
		String userInList = ELEMENT_USER_IN_LIST.replace("${username}", username);
		
		System.out.println("--Verify user " + username + " at group--");
		if (isTextPresent("Total pages")) {
            usePaginator(userInList, "User " + username + "not found in group");
		} else {
			waitForAndGetElement(userInList);
		}
	}

	public static void searchUserByUserName(String userName) {
		searchUser(userName, "User Name");
	}

	public static void searchUser(String userAttribute, String searchOption) {
		System.out.println("-- Search user: " + userAttribute + " --");
		type(ELEMENT_INPUT_SEARCH_TERM, userAttribute, true);
		select(ELEMENT_SELECT_SEARCH_OPTION, searchOption);
		click(ELEMENT_SEARCH_ICON_USERS_MANAGEMENT);
	}

    public static void editUser(String username) {
		String userEditIcon = ELEMENT_USER_EDIT_ICON.replace("${username}", username);
		
		System.out.println("--Editing user " + username + "--");
        pause(300);
		click(userEditIcon);
	}

    public static void chooseMembershipTab() {
		System.out.println("-- Choose Membership Management tab--");
        pause(500);
		click(ELEMENT_TAB_MEMBERSHIP_MANAGEMENT);
		waitForTextPresent("Add/Edit Membership");
	}

    public static void chooseGroupTab() {
		System.out.println("-- Choose Group Management tab--");
        pause(500);
		click(ELEMENT_TAB_GROUP_MANAGEMENT);
		waitForTextPresent("Group Info");
	}

	public static void chooseUserTab() {
		System.out.println("-- Choose User Management tab--");
        pause(500);
		click(ELEMENT_TAB_USER_MANAGEMENT);
		waitForTextPresent("Search:");
	}
}
