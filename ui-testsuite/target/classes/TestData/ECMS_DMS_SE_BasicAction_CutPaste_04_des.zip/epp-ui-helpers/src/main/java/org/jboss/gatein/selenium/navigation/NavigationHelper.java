package org.jboss.gatein.selenium.navigation;

import java.util.Map;
import static org.jboss.gatein.selenium.common.CommonHelper.*;
import static org.jboss.gatein.selenium.page.PageHelper.*;

import org.jboss.gatein.selenium.AbstractContextual;

public class NavigationHelper extends AbstractContextual {
	public static final String ELEMENT_CHECKBOX_VISIBLE = "//input[@name='visible']";
	public static final String ELEMENT_CHECKBOX_PUBLICATION_DATE_TIME = "//input[@name='showPublicationDate']";
    
    public static final String ELEMENT_INPUT_START_PUBLICATION_DATE = "//input[@name='startPublicationDate']";
    public static final String ELEMENT_INPUT_END_PUBLICATION_DATE = "//input[@name='endPublicationDate']";
    
	public static final String ELEMENT_EDIT_FIRST_NAVIGATION = "//a[text()='Edit Navigation']";
	public static final String ELEMENT_EDIT_NAVIGATION = "//div[@class='Label' and text()='${navigation}']/../../td[3]//a[@class='EditNavIcon']";
	
	public static final String ELEMENT_PAGE_SELECTOR_TAB = "//div[text()='Page Selector' and @class='MiddleTab']";
	public static final String ELEMENT_PAGE_NODE_SETTING_TAB = "//div[text()='Page Node Setting' and @class='MiddleTab']";
	public static final String ELEMENT_CREATE_PAGE_LINK = "//a[text()='Create Page']";
	public static final String ELEMENT_SEARCH_SELECT_PAGE_LINK = "//a[text()='Search and Select Page']";
	public static final String ELEMENT_SELECT_PAGE_FIRST = "//div[@id='UIRepeater']//table//tbody/tr/td[5]/div[@class='ActionContainer']/img";
	
	public static final String ELEMENT_ADD_NODE_LINK = "//a[text()='Add Node']";
	public static final String ELEMENT_NODE_ADD_NEW_TOP_NODE = "//div[@id='UINavigationNodeSelectorPopupMenu']/div[@class='UIContextMenuContainer']//a[@class='ItemIcon AddNode16x16Icon']";
	public static final String ELEMENT_NODE_ADD_NEW = "//div[@id='NavigationNodePopupMenu']/div[@class='UIContextMenuContainer']//a[@class='ItemIcon AddNode16x16Icon']";
	public static final String ELEMENT_NODE_DELETE = "//div[@id='NavigationNodePopupMenu']/div[@class='UIContextMenuContainer']//a[@class='ItemIcon DeleteNode16x16Icon']";
	public static final String ELEMENT_NODE_COPY = "//div[@id='NavigationNodePopupMenu']/div[@class='UIContextMenuContainer']//a[@class='ItemIcon CopyNode16x16Icon']";
	public static final String ELEMENT_NODE_CUT = "//div[@id='NavigationNodePopupMenu']/div[@class='UIContextMenuContainer']//a[@class='ItemIcon CutNode16x16Icon']";
	public static final String ELEMENT_NODE_CLONE = "//div[@id='NavigationNodePopupMenu']/div[@class='UIContextMenuContainer']//a[@class='ItemIcon CloneNode16x16Icon']";
	public static final String ELEMENT_NODE_PASTE = "//div[@id='NavigationNodePopupMenu']/div[@class='UIContextMenuContainer']//a[@class='ItemIcon PasteNode16x16Icon']";
	public static final String ELEMENT_NODE_MOVE_UP = "//div[@id='NavigationNodePopupMenu']/div[@class='UIContextMenuContainer']//a[@class='ItemIcon MoveUp16x16Icon']";
	public static final String ELEMENT_NODE_MOVE_DOWN = "//div[@id='NavigationNodePopupMenu']/div[@class='UIContextMenuContainer']//a[@class='ItemIcon MoveDown16x16Icon']";
	public static final String ELEMENT_NODE_EDIT_NODE = "//div[@id='NavigationNodePopupMenu']/div[@class='UIContextMenuContainer']//a[@class='ItemIcon EditSelectedNode16x16Icon']";
	public static final String ELEMENT_NODE_EDIT_NODE_PAGE = "//div[@id='NavigationNodePopupMenu']/div[@class='UIContextMenuContainer']//a[@class='ItemIcon EditPageNode16x16Icon']";
	public static final String ELEMENT_NODE_PASTE_HOME = "//div[@id='UINavigationNodeSelectorPopupMenu']/div[@class='UIContextMenuContainer']//a[@class='ItemIcon PasteNode16x16Icon']";
	public static final String ELEMENT_NODE_LINK = "//div[@id='UINavigationNodeSelector']//a[@title='${nodeLabel}']";
	
	public static final String ELEMENT_NAVIGATION_HOME_NODE = "//div[@class='HomeNode']";
	public static final String ELEMENT_NODE_ITEM = "//div[@class='TreeContainer JSContainer']/div/div";
	
	public static final String ELEMENT_NAVIGATION_PORTLET_PAGE_LINK = "//div[@id='UINavigationPortlet']//li[contains(@class, 'NavigationTab')][${number}]//a";
	
	public static final String ELEMENT_GROUP_EDIT_PROPERTIES_FIRST = "//a[text()='Edit Properties']";
	public static final String ELEMENT_GROUP_EDIT_PROPERTIES = "//div[@class='Label' and text()='${navigation}']/../../td[3]//a[@class='EditProIcon']";
	public static final String ELEMENT_INPUT_PRIORITY = "//select[@name='priority']";
	
	public static final String ELEMENT_ADD_NAVIGATION_LINK = "//a[text()='Add Navigation']";
	
	public static enum CopyType {
		COPY, CUT, CLONE;
	}

	public static void addNewNode(String nodeName, String nodeLabel, boolean useLink, String elementToAddWithRightClick, 
            String pageName, String pageTitle, boolean verifyPage, boolean verifyNode, boolean extendedLabelMode, 
            Map<String, String> labels) {
        
		String node = ELEMENT_NODE_LINK.replace("${nodeLabel}", nodeLabel);
		
		System.out.println("--Adding new node at navigation--");
		editFirstNavigation();
		if (useLink) {
			click(ELEMENT_ADD_NODE_LINK);
		} else {
			click(elementToAddWithRightClick);
            pause(500);
			contextMenuOnElement(elementToAddWithRightClick);
			if (elementToAddWithRightClick.equals(ELEMENT_NAVIGATION_HOME_NODE)) {
				click(ELEMENT_NODE_ADD_NEW_TOP_NODE);
			} else {
				click(ELEMENT_NODE_ADD_NEW);
			}
		}
        pause(500);
		waitForTextPresent("Page Node Setting");
		type(ELEMENT_INPUT_NAME, nodeName, true);
        
        if (extendedLabelMode) {
            for (String language : labels.keySet()) {
                select(ELEMENT_SELECT_LANGUAGE, language);
                pause(500);
                type(ELEMENT_INPUT_LOCALIZED_LABEL, labels.get(language), true);
            }
        } else {
            uncheck(ELEMENT_CHECKBOX_EXTENDED_LABEL_MODE);
            type(ELEMENT_INPUT_LABEL, nodeLabel, true);
        }
        
		click(ELEMENT_PAGE_SELECTOR_TAB);
		pause(500);
		if (pageName != null & pageTitle != null) {
			System.out.println("--Create new page");
			type(ELEMENT_INPUT_PAGE_NAME, pageName, true);
			type(ELEMENT_INPUT_PAGE_TITLE, pageTitle, true);
			click(ELEMENT_CREATE_PAGE_LINK);
			if (verifyPage) {
				waitForElementNotPresent(ELEMENT_CREATE_PAGE_LINK);
			} else {
				return;
			}
		} else {
			System.out.println("--Select Page");
            pause(500);
			click(ELEMENT_SEARCH_SELECT_PAGE_LINK);
			click(ELEMENT_SELECT_PAGE_FIRST);
		}
		System.out.println("--Save--");
		pause(1000);
		save();
		if (verifyNode) {
			waitForTextNotPresent("Page Node Setting");
			waitForAndGetElement(node);
			save();
			waitForTextNotPresent("Navigation Management");
		}
	}
	
	public static void deleteNodeFromFirstNavigation(String nodeLabel, String navigation, boolean verify) {
		System.out.println("--Deleting node from navigation--");
		editFirstNavigation();
		if (navigation != null) {
			goToNavigation(navigation);
		}
		deleteNode(nodeLabel, verify);
	}
	
	// deletes node from specific navigation (first param is used to open navigation)
	public static void deleteNodeFromNavigation(String navigationType, String nodeLabel, String navigation, boolean verify) {
		System.out.println("--Deleting node from navigation--");
		editNavigation(navigationType);
		if (navigation != null) {
			goToNavigation(navigation);
		}
		deleteNode(nodeLabel, verify);
	}
	
	public static void deleteNode(String nodeLabel, boolean verify) {
		String node = ELEMENT_NODE_LINK.replace("${nodeLabel}", nodeLabel);
        System.out.println("--Deleting node from navigation--");

		contextMenuOnElement(node);
        click(ELEMENT_NODE_DELETE);
		waitForConfirmation("Are you sure you want to delete this node?");
		if (verify) {
            waitForElementNotPresent(node);
        }
		save();
		waitForTextNotPresent("Navigation Management");
		if (verify) {
            waitForTextNotPresent(nodeLabel);
        }
	}

	public static void editFirstNavigation() {
		click(ELEMENT_EDIT_FIRST_NAVIGATION);
		waitForTextPresent("Navigation Management");
	}

	public static void editNavigation(String navigation) {
		String navig = ELEMENT_EDIT_NAVIGATION.replace("${navigation}", navigation);
		click(navig);
		waitForTextPresent("Navigation Management");
	}

	public static void copyNode(CopyType type, String navigation, String nodeLabel, String pasteToElement, String verifyElement) {
		System.out.println("--" + type.name() + " a node--");
		if (navigation != null) {
			goToNavigation(navigation);
		}
		String node = ELEMENT_NODE_LINK.replace("${nodeLabel}", nodeLabel);
		contextMenuOnElement(node);
		switch (type) {
			case COPY:
				click(ELEMENT_NODE_COPY);
				break;
			case CUT:
				click(ELEMENT_NODE_CUT);
				break;
			case CLONE:
				click(ELEMENT_NODE_CLONE);
				break;
			default:
				break;
		}
        pause(700);
		System.out.println("--Paste a node--");
		contextMenuOnElement(pasteToElement);
		pause(500);
		if (pasteToElement.equals(ELEMENT_NAVIGATION_HOME_NODE)) {
			click(ELEMENT_NODE_PASTE_HOME);
		} else {
			click(ELEMENT_NODE_PASTE);
		}
        pause(500);
		if (verifyElement != null) {
			waitForAndGetElement(verifyElement);
		}
	}
    
    public static String getTitleOfElement(String xpath) {
        return waitForAndGetElement(xpath).getAttribute("title");
    }
    
    private static void goToNavigation(String navigation) {
        String[] nav = navigation.split("/");
        for (String navig : nav) {
            String node = ELEMENT_NODE_LINK.replace("${nodeLabel}", navig);
            click(node);
        }
    }
}
