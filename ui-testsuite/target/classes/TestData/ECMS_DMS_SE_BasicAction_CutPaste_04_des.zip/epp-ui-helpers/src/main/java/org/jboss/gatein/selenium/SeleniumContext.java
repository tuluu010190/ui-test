package org.jboss.gatein.selenium;

import org.openqa.selenium.WebDriver;

public class SeleniumContext {

    private String timeout;
    private int timeoutSecInt;
    private String portalPath;
    private String host;
    private String hostPort;
    private String browser;
    private WebDriver webDriver;
    private boolean httpsFlag;

    public SeleniumContext(WebDriver webDriver, String timeout, String portalPath, String host, String hostPort,
            String browser, boolean httpsFlag) {

        this.webDriver = webDriver;
        this.timeout = timeout;
        this.timeoutSecInt = Integer.parseInt(timeout) / 1000;
        this.host = host;
        this.hostPort = hostPort;
        this.portalPath = portalPath;
        this.browser = browser;
        this.httpsFlag = httpsFlag;
    }

    public WebDriver getWebDriver() {
        return webDriver;
    }

    public String getTimeout() {
        return timeout;
    }

    public int getTimeoutSecInt() {
        return timeoutSecInt;
    }

    public String getHost() {
        return host;
    }

    public String getHostPort() {
        return hostPort;
    }

    public String getPortalPath() {
        return portalPath;
    }

    public String getBrowser() {
        return browser;
    }

    public boolean isHttpsFlag() {
        return httpsFlag;
    }
}
