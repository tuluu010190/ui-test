package org.jboss.gatein.selenium.common;

import java.util.ArrayList;
import java.util.List;
import org.jboss.gatein.selenium.AbstractContextual;
import org.jboss.gatein.selenium.applicationregistry.ApplicationRegistryHelper;
import org.jboss.gatein.selenium.dashboard.DashboardHelper;
import org.jboss.gatein.selenium.navigation.NavigationHelper;
import org.jboss.gatein.selenium.page.PageHelper;
import org.jboss.gatein.selenium.usersmanagement.UsersManagementHelper;
import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

public class CommonHelper extends AbstractContextual {

    private static String portalUrl;
    
    public static final String ELEMENT_SAVE_BUTTON = "//a[text()='Save']";
    public static final String ELEMENT_ADD_BUTTON = "//div[@class='UIAction']/a[text()='Add']";
    public static final String ELEMENT_CANCEL_BUTTON = "//a[text()='Cancel']";
    public static final String ELEMENT_CLOSE_BUTTON = "//a[text()='Close']";
    public static final String ELEMENT_X_BUTTON = "//a[@class='CloseButton']";
    public static final String ELEMENT_SAVE_AND_CLOSE_BUTTON = "//a[@id='Save']";
    public static final String ELEMENT_APPLY_BUTTON = "//a[text()='Apply']";
    public static final String ELEMENT_BACK_BUTTON = "//a[text()='Back']";
    public static final String ELEMENT_OK_BUTTON = "//a[text()='OK']";
    public static final String ELEMENT_RESET_BUTTON = "//a[text()='Reset']";
	
    public static final String ELEMENT_INPUT_NAME = "//input[@id='name']";
    public static final String ELEMENT_INPUT_DISPLAY_NAME = "//input[@id='displayName']";
    public static final String ELEMENT_INPUT_DESCRIPTION = "//input[@id='description']";
    public static final String ELEMENT_INPUT_URL = "//input[@id='url']";
    public static final String ELEMENT_INPUT_SOURCE = "//textarea[@id='source']";
    public static final String ELEMENT_INPUT_USERNAME = "//input[@name='username']";
    public static final String ELEMENT_INPUT_PASSWORD = "//input[@name='password']";
    public static final String ELEMENT_INPUT_CONFIRM_PASSWORD = "//input[@id='Confirmpassword']";
    public static final String ELEMENT_INPUT_NEW_PASSWORD = "//input[@id='newPassword']";
    public static final String ELEMENT_INPUT_NEW_CONFIRM_PASSWORD = "//input[@id='confirmPassword']";
    public static final String ELEMENT_INPUT_TITLE = "//input[@id='title']";
    public static final String ELEMENT_INPUT_TEMPLATE_URL = "//input[@id='template']";
    public static final String ELEMENT_INPUT_LABEL = "//input[@id='label']";
    public static final String ELEMENT_INPUT_LOCALIZED_LABEL = "//input[@id='i18nizedLabel']";
    public static final String ELEMENT_INPUT_WIDTH = "//input[@id='width']";
    public static final String ELEMENT_INPUT_HEIGHT = "//input[@id='height']";
    public static final String ELEMENT_INPUT_FIRSTNAME = "//input[@id='firstName']";
    public static final String ELEMENT_INPUT_LASTNAME = "//input[@id='lastName']";
    public static final String ELEMENT_INPUT_DISPLAYNAME = "//input[@id='displayName']";
    public static final String ELEMENT_INPUT_EMAIL = "//input[@id='email']";
    public static final String ELEMENT_INPUT_OWNER_ID = "//select[@name='ownerId']";
    public static final String ELEMENT_INPUT_SEARCH_TERM = "//input[@id='searchTerm']";
    public static final String ELEMENT_INPUT_LOGO_URL = "//input[@id='logoUrl']";
    
    public static final String ELEMENT_TEXTAREA_DESCRIPTION = "//textarea[@id='description']";
	
    public static final String ELEMENT_SELECT_TYPE = "//select[@name='type']";
    public static final String ELEMENT_SELECT_LOCALE = "//select[@name='locale']";
    public static final String ELEMENT_SELECT_SKIN = "//select[@name='skin']";
    public static final String ELEMENT_SELECT_OWNER_TYPE = "//select[@name='ownerType']";
    public static final String ELEMENT_SELECT_OWNER_ID = "//select[@name='ownerId']";
    public static final String ELEMENT_SELECT_SEARCH_OPTION = "//select[@name='searchOption']";
    public static final String ELEMENT_SELECT_LANGUAGE = "//select[@name='languages']";
	
    public static final String ELEMENT_PAGINATOR_TOTAL_NUMBER = "//a[@class='PagesTotalNumber']";
    public static final String ELEMENT_PAGINATOR_NEXT_ICON = "//a[@class='Icon NextPageIcon']";
    public static final String ELEMENT_PAGINATOR_SELECTED_PAGE = "//a[@class='Number PageSelected' and text()='${number}']";
    public static final String ELEMENT_PAGINATOR_PAGE_LINK = "//a[contains(@class, 'Number') and text()='${number}']";
	
    public static final String ELEMENT_SIGN_IN_LINK = "//a[contains(@class, 'Login')]";
    public static final String ELEMENT_SIGN_IN_BUTTON = "//a[text()='Sign in']";
    public static final String ELEMENT_SIGN_OUT_LINK = "//a[@class='SignOutIcon']";
    public static final String ELEMENT_SIGN_IN_CONFIRM_BUTTON = "//form[@id='UIPortalComponentLogin']//div[@class='UIAction']/*";
    public static final String ELEMENT_SIGN_IN_REMEMBERME_CHECKBOX = "//input[@name='rememberme']";
    public static final String ELEMENT_SIGNED_USER_LINK = "//a[text()='${name} ${surname}']";
    public static final String ELEMENT_TEST_USER_ADMIN = "//div[@class='AccountBlock AdministratorUser']";
    public static final String ELEMENT_TEST_USER_MANAGER = "//div[@class='AccountBlock ManagerUser']";
    public static final String ELEMENT_TEST_USER_USER = "//div[@class='AccountBlock NormalUser']";
    public static final String ELEMENT_TEST_USER_DEMO = "//div[@class='AccountBlock DemoUser']";
	
    public static final String ELEMENT_LINK_PORTAL_TOP_CONTAINER = "//ul[contains (@id, 'PortalNavigationContainer')]/..";
    public static final String ELEMENT_LINK_CHANGE_LANGUAGE_SIGNED_IN = "//a[@class='ChangeLanguageIcon']";
    public static final String ELEMENT_LINK_CHANGE_LANGUAGE = "//a[@class='Language']";
    public static final String ELEMENT_LINK_APP_REGISTRY = "//a[text()='Application Registry']";
    public static final String ELEMENT_LINK_ADMINISTRATION = "//a[text()='Administration']";
    public static final String ELEMENT_LINK_NEW_STAFF = "//a[text()='New Staff']";
    public static final String ELEMENT_LINK_USERS_MANAGEMENT = "//a[text()='Users and groups management']";
    public static final String ELEMENT_LINK_PAGE_MANAGEMENT = "//a[text()='Page Management']";
    public static final String ELEMENT_LINK_SITE = "//a[@class='SitesIcon TBIcon']";
    public static final String ELEMENT_LINK_GROUP = "//a[@class='GroupIcon TBIcon']";
    public static final String ELEMENT_LINK_GROUP_EDITOR = "//a[@class='EditorIcon TBIcon']";
    public static final String ELEMENT_LINK_ORGANIZATION = "//a[text()='Organization']";
    public static final String ELEMENT_LINK_DASHBOARD = "//a[@class='DashboardIcon TBIcon']";
    public static final String ELEMENT_LINK_CLASSIC_PORTAL = "//a[contains(@href, '/classic/') and contains(text(), 'lassic')]"; // Classic in GateIn, classic in EPP
    public static final String ELEMENT_LINK_HOME = "//a[text()='Home']";
    public static final String ELEMENT_LINK_SITE_MAP = "//a[text()='SiteMap']";
    public static final String ELEMENT_LINK_COLLAPSE_ALL = "//div[@id='UISiteMap']/div/div";
	
    public static final String ELEMENT_MESSAGE_TEXT = "//li[@class='MessageContainer']/span[contains(@class, 'PopupIcon')]";
    public static final String ELEMENT_MESSAGE_DIALOG_CLOSE_ICON = "//div[contains(@class, 'UIPopupWindow') and contains(@style, 'visibility: visible')]//span[text()='Messages']/..//a[@class='CloseButton']";
    public static final String ELEMENT_MESSAGE_DIALOG_CLOSE_ICON_IE = ELEMENT_MESSAGE_TEXT + "/../../../../../..//a";
    public static final String ELEMENT_CONFIRMATION = "//div[@id='UIConfirmation']";
    public static final String ELEMENT_CONFIRMATION_YES_OPTION = "//div[@id='UIConfirmation']//div[contains(@class, 'UIAction')]//a[contains(text(), 'Yes')]";
	
    public static final String ELEMENT_BREADCRUMB_SELECTED_TEXT = "//div[@class='BreadcumbsInfoBar']//a[@class='Selected']";
	
    public static final String ELEMENT_SITEMAP_EXPAND_LINK = "//div[@class='ExpandIcon ClearFix']/a[text()='${page}']";
    public static final String ELEMENT_SITEMAP_COLLAPSE_LINK = "//div[@class='CollapseIcon ClearFix']/a[text()='${page}']";
    public static final String ELEMENT_SITEMAP_LINK = "//div[@class='CollapseIcon ClearFix']/..//div[@class='ChildrenContainer']//a[@class='NodeIcon DefaultPageIcon' and text()='${page}']";
	
    public static final String ELEMENT_CHANGE_SKIN_LINK = "//a[@class='ChangeSkinIcon']";
	
    public static final String ELEMENT_PROPERTIES_TAB = "//div[text()='Properties' and @class='MiddleTab']";
    
    public static final String ELEMENT_EDIT_LAYOUT_FROM_TABLE = "//td[@class='Content']/div[text()='${portalName}']/../../td[3]/a[@class='EditLayoutIcon']";
    public static final String ELEMENT_EDIT_LAYOUT_FROM_TABLE_FIRST = ELEMENT_EDIT_LAYOUT_FROM_TABLE.replace("${portalName}", "classic");
    
    public static final String BREADCRUMB_PORTLET_SELECTED_NODE = "//div[@id='UIBreadcumbsPortlet']//a[@class='Selected' and text()='${node_label}']";
    public static final String ELEMENT_SELECTED_BREDCRUMBS_INFO_BAR = "//a[@class='Selected' and text()='${pageName}']";
    public static final String LOGO_PORTLET = "//div[@id='UILogoPortlet']//div[text()='${text}']";
    
    public static int loopCount = 0;
    private static int seconds = 0;

    public static void checkCycling(Exception e, int loopCountAllowed) {
        System.err.println(e.getClass());
        if (loopCount > loopCountAllowed) {
            Assert.fail("Cycled: " + e.getMessage());
        }
        loopCount++;
    }

    public static List<WebElement> getElements(String xpath) {
        try {
            return webDriver.findElements(By.xpath(xpath));
        } catch (StaleElementReferenceException e) {
            checkCycling(e, 5);
            pause(1000);
            return getElements(xpath);
        } finally {
            loopCount = 0;
        }
    }
    
    public static WebElement getElement(String xpath) {
        pause(500);
        return webDriver.findElement(By.xpath(xpath));
    }
    
    public static WebElement waitForAndGetElement(String xpath) {
        WebElement element = null;
        for (int second = 0;; second++) {
            if (second >= timeoutSecInt) {
                Assert.fail("Timeout at waitForElementPresent: " + xpath);
            }
            try {
                element = webDriver.findElement(By.xpath(xpath));
                boolean isLoadingDisplayed = false;
                try {
                    WebElement loading = webDriver.findElement(By.xpath("//div[@id='AjaxLoadingMask']"));
                    isLoadingDisplayed = loading.isDisplayed();
                } catch (Exception e) {
                }
                if (element.isDisplayed() && !isLoadingDisplayed) {
                    break;
                }
            } catch (Exception e) {
            }
            pause(1000);
        }
        return element;
    }

    public static void waitForElementNotPresent(String xpath) {
        for (int second = 0;; second++) {
            if (second >= timeoutSecInt) {
                Assert.fail("Timeout at waitForElementNotPresent: " + xpath);
            }
            try {
                webDriver.findElement(By.xpath(xpath));
            } catch (NoSuchElementException e) {
                break;
            } catch (Exception e) {
            }
            pause(1000);
        }
    }

    public static String getText(String xpath) {
        WebElement element = null;
        try {
            element = waitForAndGetElement(xpath);
            return element.getText();
        } catch (StaleElementReferenceException e) {
            checkCycling(e, 5);
            pause(1000);
            return getText(xpath);
        } finally {
            loopCount = 0;
        }
    }

    public static boolean isTextPresent(String text) {
        pause(500);
        String allVisibleTexts = getText("//body");

        return allVisibleTexts.contains(text);
    }

    public static boolean isTextNotPresent(String text) {
        return !isTextPresent(text);
    }

    public static void waitForTextPresent(String text) {
        for (int second = 0;; second++) {
            if (second >= timeoutSecInt) {
                Assert.fail("Timeout at waitForTextPresent: " + text);
            }
            if (isTextPresent(text)) {
                break;
            }
            pause(500);
        }
    }

    public static void waitForTextNotPresent(String text) {
        for (int second = 0;; second++) {
            if (second >= timeoutSecInt) {
                Assert.fail("Timeout at waitForTextNotPresent: " + text);
            }
            if (isTextNotPresent(text)) {
                break;
            }
            pause(500);
        }
    }

    public static String getTextFromAlert() {
        try {
            Alert alert = webDriver.switchTo().alert();
            return alert.getText();
        } catch (NoAlertPresentException e) {
            return "";
        }
    }

    public static void waitForConfirmation(String confirmationText) {
        String message = getTextFromAlert();

        System.out.println("confirmation: " + message);

        if (message.isEmpty()) {
            if (loopCount > 5) {
                Assert.fail("Message is empty");
            }
            pause(500);
            loopCount++;
            waitForConfirmation(confirmationText);
            return;
        }

        for (int second = 0;; second++) {
            if (second >= timeoutSecInt) {
                Assert.fail("Timeout at waitForConfirmation: " + confirmationText);
            }
            if (message.equals(confirmationText)) {
                break;
            }
            pause(1000);
        }
        Alert alert = webDriver.switchTo().alert();
        alert.accept();
        pause(500);
    }

    public static boolean isElementPresent(String xpath) {
        if (ieFlag) {
            pause(1000);
        } else {
            pause(500);
        }
        try {
            webDriver.findElement(By.xpath(xpath));
            return true;
        } catch (NoSuchElementException e) {
            return false;
        }
    }

    public static boolean isElementNotPresent(String xpath) {
        return !isElementPresent(xpath);
    }

    public static void dradAndDropBy(String xpath, int xOffset, int yOffset) {
        try {
            WebElement element = waitForAndGetElement(xpath);
            actions.dragAndDropBy(element, xOffset, yOffset).build().perform();
        } catch (StaleElementReferenceException e) {
            checkCycling(e, 5);
            pause(1000);
            dradAndDropBy(xpath, xOffset, yOffset);
        } finally {
            loopCount = 0;
        }
    }

    public static void dragAndDropToObject(String xpathSource, String xpathTarget, String verification) {
        System.out.println("--Drag and drop to object--");
        try {
            WebElement source = waitForAndGetElement(xpathSource);
            WebElement target = waitForAndGetElement(xpathTarget);

            actions.dragAndDrop(source, target).build().perform();
        } catch (StaleElementReferenceException e) {
            checkCycling(e, 5);
            pause(500);
            dragAndDropToObject(xpathSource, xpathTarget, null);
        } finally {
            loopCount = 0;
        }

        if (verification != null) {
            verifyDragAndDrop(verification, xpathSource, xpathTarget);
        }
    }

    private static void verifyDragAndDrop(String xpath, String xpathSource, String xpathTarget) {
        for (; ieFlag && isElementNotPresent(xpath); seconds++) {
            if (seconds >= timeoutSecInt) {
                Assert.fail("Timeout at dragAndDropToObject");
            }
            pause(500);
            try {
                WebElement source = waitForAndGetElement(xpathSource);
                WebElement target = waitForAndGetElement(xpathTarget);

                actions.dragAndDrop(source, target).build().perform();
            } catch (StaleElementReferenceException e) {
                checkCycling(e, 5);
                verifyDragAndDrop(xpath, xpathSource, xpathTarget);
                break;
            } finally {
                loopCount = 0;
            }
        }
        seconds = 0;
        if (!ieFlag) {
            waitForAndGetElement(xpath);
        }
    }

    public static void contextMenuOnElement(String xpath) {
        pause(500);
        try {
            WebElement element = waitForAndGetElement(xpath);
            actions.contextClick(element).perform();
        } catch (StaleElementReferenceException e) {
            checkCycling(e, 5);
            pause(1000);
            contextMenuOnElement(xpath);
        } finally {
            loopCount = 0;
        }
    }

    public static void doubleClickOnElement(String xpath) {
        try {
            WebElement element = waitForAndGetElement(xpath);
            actions.doubleClick(element).perform();
        } catch (StaleElementReferenceException e) {
            checkCycling(e, 5);
            pause(1000);
            doubleClickOnElement(xpath);
        } finally {
            loopCount = 0;
        }
    }

    public static void typeAndConfirm(String xpath, String text) {
        try {
            WebElement element = waitForAndGetElement(xpath);

            element.clear();
            element.sendKeys(text, Keys.RETURN);
        } catch (StaleElementReferenceException e) {
            checkCycling(e, 5);
            pause(1000);
            typeAndConfirm(xpath, text);
        } finally {
            loopCount = 0;
        }
    }

    public static void click(String xpath) {
        try {
            WebElement element = waitForAndGetElement(xpath);
            actions.click(element).perform();
        } catch (StaleElementReferenceException e) {
            checkCycling(e, 5);
            pause(1000);
            click(xpath);
        } finally {
            loopCount = 0;
        }
    }

    public static void type(String xpath, String value, boolean validate) {
        try {
            for (int second = 0;; second++) {
                if (second >= timeoutSecInt) {
                    Assert.fail("Timeout at type: " + value + " into " + xpath);
                }
                WebElement element = waitForAndGetElement(xpath);
                element.clear();
                element.click();
                element.sendKeys(value);
                if (!validate || value.equals(getValue(xpath))) {
                    break;
                }
                pause(1000);
            }
        } catch (StaleElementReferenceException e) {
            checkCycling(e, 5);
            pause(1000);
            type(xpath, value, validate);
        } finally {
            loopCount = 0;
        }
    }

    public static void select(String xpath, String option) {
        try {
            for (int second = 0;; second++) {
                if (second >= timeoutSecInt) {
                    Assert.fail("Timeout at select: " + option + " into " + xpath);
                }
                Select select = new Select(waitForAndGetElement(xpath));
                select.selectByVisibleText(option);
                if (option.equals(select.getFirstSelectedOption().getText())) {
                    break;
                }
                pause(1000);
            }
        } catch (StaleElementReferenceException e) {
            checkCycling(e, 7);
            pause(1000);
            select(xpath, option);
        } finally {
            loopCount = 0;
        }
    }

    public static void check(String xpath) {
        try {
            WebElement element = waitForAndGetElement(xpath);

            if (!element.isSelected()) {
                actions.click(element).perform();
            } else {
                Assert.fail("Element " + xpath + " is already checked.");
            }
        } catch (StaleElementReferenceException e) {
            checkCycling(e, 5);
            pause(1000);
            check(xpath);
        } finally {
            loopCount = 0;
        }
    }

    public static boolean isSelected(String xpath) {
        try {
            WebElement element = waitForAndGetElement(xpath);
            return element.isSelected();
        } catch (StaleElementReferenceException e) {
            checkCycling(e, 5);
            pause(1000);
            return isSelected(xpath);
        } finally {
            loopCount = 0;
        }
    }

    public static void uncheck(String xpath) {
        try {
            WebElement element = waitForAndGetElement(xpath);

            if (element.isSelected()) {
                actions.click(element).perform();
            } else {
                Assert.fail("Element " + xpath + " is already unchecked.");
            }
        } catch (StaleElementReferenceException e) {
            checkCycling(e, 5);
            pause(1000);
            uncheck(xpath);
        } finally {
            loopCount = 0;
        }
    }

    /**
     * @param safeToSERE when true and StaleElementReferenceException occur mouseOver is rerun
     */
    public static void mouseOver(String xpath, boolean safeToSERE) {
        if (safeToSERE) {
            try {
                WebElement element = waitForAndGetElement(xpath);
                actions.moveToElement(element).perform();
            } catch (StaleElementReferenceException e) {
                checkCycling(e, 5);
                pause(1000);
                mouseOver(xpath, safeToSERE);
            } finally {
                loopCount = 0;
            }
        } else {
            WebElement element = waitForAndGetElement(xpath);
            actions.moveToElement(element).perform();
        }
    }

    public static void mouseOverAndClick(String xpath) {
        WebElement element;
        if (ieFlag) {
            element = getElement(xpath);
        } else {
            element = waitForAndGetElement(xpath);
        }
        actions.moveToElement(element).click(element).build().perform();
    }

    public static void resize(String xpath, int xOffset, int yOffset) {
        try {
            WebElement element = waitForAndGetElement(xpath);
            actions.clickAndHold(element).moveByOffset(xOffset, yOffset).release().build().perform();
        } catch (StaleElementReferenceException e) {
            checkCycling(e, 5);
            pause(1000);
            resize(xpath, xOffset, yOffset);
        } finally {
            loopCount = 0;
        }
    }

    public static void pause(long timeInMillis) {
        try {
            Thread.sleep(timeInMillis);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    public static String getValue(String xpath) {
        try {
            return waitForAndGetElement(xpath).getAttribute("value");
        } catch (StaleElementReferenceException e) {
            checkCycling(e, 5);
            pause(1000);
            return getValue(xpath);
        } finally {
            loopCount = 0;
        }
    }

    public static String getCountOfElements(String xpath) {
        try {
            return String.valueOf(getElements(xpath).size());
        } catch (StaleElementReferenceException e) {
            checkCycling(e, 5);
            pause(1000);
            return getCountOfElements(xpath);
        } finally {
            loopCount = 0;
        }
    }

    public static boolean isTextAtElementEqual(String xpathOfElement, String text) {
        try {
            return getText(xpathOfElement).equals(text);
        } catch (StaleElementReferenceException e) {
            checkCycling(e, 5);
            pause(1000);
            return isTextAtElementEqual(xpathOfElement, text);
        } finally {
            loopCount = 0;
        }
    }

    public static void verifyElementWidth(String xpath, String width) {
        Dimension size = waitForAndGetElement(xpath).getSize();
        Assert.assertEquals(new Integer(size.getWidth()), Integer.valueOf(width));
    }

    public static void verifyElementHeight(String xpath, String height) {
        Dimension size = waitForAndGetElement(xpath).getSize();
        Assert.assertEquals(new Integer(size.getHeight()), Integer.valueOf(height));
    }

    public static void deleteAllCookies() {
        setUp();

        webDriver.manage().deleteAllCookies();
    }

    public static void deleteCookieNamed(String cookieName) {
        setUp();

        webDriver.manage().deleteCookieNamed(cookieName);
    }
    
    public static Cookie getCookieNamed(String cookieName) {
        setUp();

        return webDriver.manage().getCookieNamed(cookieName);
    }

    public static void open(String location) {
        setUp();

        System.out.println("--Opening location " + location + " --");
        webDriver.get(location);
    }

    public static void openPortal(String newPortalPath, boolean publicMode) {
        setUp();
        
        String location = publicMode ? getPortalUrl() : getPortalUrl().concat("/private");

        if (newPortalPath != null) {
            location = location.replace(portalPath, newPortalPath);
        }

        open(location);
    }

    public static void openPortal(boolean publicMode) {
        openPortal(null, publicMode);
    }

    private static void setPortalUrl() {
        portalUrl = (httpsFlag ? "https" : "http") + "://" + host + ":" + hostPort + portalPath;
    }

    public static String getPortalUrl() {
        setUp();
        
        if (portalUrl == null) {
            setPortalUrl();
        }
        return portalUrl;
    }

    public static void save() {
        waitForAndGetElement(ELEMENT_SAVE_BUTTON);
        click(ELEMENT_SAVE_BUTTON);
    }

    public static void cancel() {
        waitForAndGetElement(ELEMENT_CANCEL_BUTTON);
        click(ELEMENT_CANCEL_BUTTON);
    }

    public static void close() {
        waitForAndGetElement(ELEMENT_CLOSE_BUTTON);
        click(ELEMENT_CLOSE_BUTTON);
    }

    public static void closeByX() {
        waitForAndGetElement(ELEMENT_X_BUTTON);
        click(ELEMENT_X_BUTTON);
    }

    public static void signInAsRoot() {
        signIn("root", "gtn");
    }

    public static void signInAsJohn() {
        signIn("john", "gtn");
    }

    public static void signInAsMary() {
        signIn("mary", "gtn");
    }

    public static void signInAsDemo() {
        signIn("demo", "gtn");
    }

    public static void signIn(String username, String password) {
        System.out.println("--Signing  in as " + username + "--");
        click(ELEMENT_SIGN_IN_LINK);
        type(ELEMENT_INPUT_USERNAME, username, true);
        type(ELEMENT_INPUT_PASSWORD, password, true);
        click(ELEMENT_SIGN_IN_CONFIRM_BUTTON);
        waitForElementNotPresent(ELEMENT_SIGN_IN_CONFIRM_BUTTON);
    }

    public static void signInWithRememberChecked(String username, String password) {
        System.out.println("--Signing  in as " + username + " with checked remember me--");
        click(ELEMENT_SIGN_IN_LINK);
        type(ELEMENT_INPUT_USERNAME, username, true);
        type(ELEMENT_INPUT_PASSWORD, password, true);
        System.out.println("--Check \"remember my login\"");
        check(ELEMENT_SIGN_IN_REMEMBERME_CHECKBOX);
        click(ELEMENT_SIGN_IN_CONFIRM_BUTTON);
        waitForElementNotPresent(ELEMENT_SIGN_IN_CONFIRM_BUTTON);
    }

    public static void signOut() {
        pause(500);
        goToPage(ELEMENT_SIGN_IN_LINK, ELEMENT_LINK_PORTAL_TOP_CONTAINER, ELEMENT_SIGN_OUT_LINK);
    }

    public static void goToApplicationRegistry() {
        System.out.println("--Go to App.registry--");
        goToPage(ApplicationRegistryHelper.ELEMENT_CATEGORY_ADD_ICON, ELEMENT_LINK_GROUP, ELEMENT_LINK_ADMINISTRATION, ELEMENT_LINK_APP_REGISTRY);
    }

    public static void goToPageManagement() {
        System.out.println("--Go to Page Management--");
        goToPage(PageHelper.ELEMENT_PAGE_MANAGEMENT_SEARCH_BUTTON, ELEMENT_LINK_GROUP, ELEMENT_LINK_ADMINISTRATION, ELEMENT_LINK_PAGE_MANAGEMENT);
    }

    public static void goToUsersAndGroupsManagement() {
        System.out.println("--Go to Users and groups management--");
        goToPage(UsersManagementHelper.ELEMENT_TAB_GROUP_MANAGEMENT, ELEMENT_LINK_GROUP, ELEMENT_LINK_ORGANIZATION, ELEMENT_LINK_USERS_MANAGEMENT);
    }

    public static void goToNewStaff() {
        System.out.println("--Go to New Staff--");
        goToPage(UsersManagementHelper.ELEMENT_SEARCH_ICON_REGISTER, ELEMENT_LINK_GROUP, ELEMENT_LINK_ORGANIZATION, ELEMENT_LINK_NEW_STAFF);
    }

    public static void goToSite() {
        System.out.println("--Go to Site Management--");
        goToPage(NavigationHelper.ELEMENT_EDIT_FIRST_NAVIGATION, ELEMENT_LINK_SITE);
    }

    public static void goToGroup() {
        System.out.println("--Go to Group Management--");
        goToPage(NavigationHelper.ELEMENT_EDIT_FIRST_NAVIGATION, ELEMENT_LINK_GROUP);
    }

    public static void goToDashboard() {
        System.out.println("--Go to Dashboard--");
        goToPage(DashboardHelper.ELEMENT_ADD_GADGETS_LINK, ELEMENT_LINK_DASHBOARD);
    }

    public static void goToSiteClassicHome() {
        System.out.println("--Go to Home page of classic portal--");
        goToPage(ELEMENT_TEST_USER_ADMIN, ELEMENT_LINK_SITE, ELEMENT_LINK_CLASSIC_PORTAL, ELEMENT_LINK_HOME);
    }

    public static void goToSiteMap() {
        System.out.println("--Go to SiteMap--");
        goToPage(ELEMENT_LINK_COLLAPSE_ALL, ELEMENT_LINK_SITE, ELEMENT_LINK_CLASSIC_PORTAL, ELEMENT_LINK_SITE_MAP);
    }

    public static void goToClassicPortal() {
        System.out.println("--Go to portal classic--");
        goToPage(ELEMENT_TEST_USER_ADMIN, ELEMENT_LINK_SITE, ELEMENT_LINK_CLASSIC_PORTAL);
    }

    public static void goToChangeSkin() {
        System.out.println("--Go to Change Skin--");
        goToPage(ELEMENT_APPLY_BUTTON, ELEMENT_LINK_PORTAL_TOP_CONTAINER, ELEMENT_CHANGE_SKIN_LINK);
    }

    public static void goToPage(String verification, String... navigation) {
        String page = makeLink(navigation[navigation.length - 1]);
        boolean needToBeVerified = true;

        List<String> navigationList = new ArrayList<String>();

        for (int i = 0; i < (navigation.length - 1); i++) {
            String node = navigation[i];
            node = makeLink(node);
            navigationList.add(node);
        }

        try {
            for (String node : navigationList) {
                if (ieFlag) {
                    actions.moveToElement(getElement(node));
                } else {
                    mouseOver(node, false);
                }
            }
            mouseOverAndClick(page);
        } catch (StaleElementReferenceException e) {
            checkCycling(e, 10);
            goToPage(verification, navigation);
            needToBeVerified = false;
        } finally {
            loopCount = 0;
        }

        if (verification != null && needToBeVerified) {
            pause(500);
            verifyLocation(verification, navigationList, page);
        }
    }

    private static String makeLink(String node) {
        if (!node.contains("//")) {
            String label = node;
            node = "//a[text()='" + label + "']";
        }
        return node;
    }

    private static void verifyLocation(String xpath, List<String> navigation, String page) {
        System.out.println("verifyLocation, element: " + xpath);
        if (isElementNotPresent(xpath)) {
            pause(5000);
        }
        for (; isElementNotPresent(xpath); seconds++) {
            if (seconds >= timeoutSecInt) {
                Assert.fail("Timeout at goToPage");
            }
            pause(500);
            try {
                for (String node : navigation) {
                    if (ieFlag) {
                        actions.moveToElement(getElement(xpath));
                    } else {
                        mouseOver(node, false);
                    }
                }
                mouseOverAndClick(page);
            } catch (StaleElementReferenceException e) {
                checkCycling(e, 10);
                verifyLocation(xpath, navigation, page);
                break;
            } finally {
                loopCount = 0;
            }
        }
        seconds = 0;
    }

    public static void closeMessageDialog() {
        System.out.println("--Closing message dialog--");
        if (ieFlag) {
            click(ELEMENT_MESSAGE_DIALOG_CLOSE_ICON_IE);
        } else {
            click(ELEMENT_MESSAGE_DIALOG_CLOSE_ICON);
        }
    }

    public static void waitForMessage(String message) {
        System.out.println("--Verify message: " + message);
        pause(500);
        waitForTextPresent(message);
    }

    public static void waitForPopupConfirmationAndConfirm(String message) {
        System.out.println("--Verify message in popup confirmation: " + message);
        waitForAndGetElement(ELEMENT_CONFIRMATION);
        waitForTextPresent(message);
        waitForAndGetElement(ELEMENT_CONFIRMATION_YES_OPTION);
        click(ELEMENT_CONFIRMATION_YES_OPTION);
        waitForTextNotPresent(message);
    }

    public static void usePaginator(String xpath, String exceptionMessage) {
        String page1 = ELEMENT_PAGINATOR_PAGE_LINK.replace("${number}", "1");

        click(page1);
        pause(500);
        int totalPages = isElementPresent(ELEMENT_PAGINATOR_TOTAL_NUMBER) ? Integer.valueOf(getText(ELEMENT_PAGINATOR_TOTAL_NUMBER)) : 1;
        int i = 1;
        while (isElementNotPresent(xpath)) {
            if (i == totalPages) {
                Assert.fail(exceptionMessage);
            }
            click(ELEMENT_PAGINATOR_NEXT_ICON);
            waitForAndGetElement(ELEMENT_PAGINATOR_SELECTED_PAGE.replace("${number}", String.valueOf((++i))));
            pause(500);
        }
    }
}
